gridUtilObj = {
    resizeGrid: () => {
      var startX,
           startWidth,
           $handle,
           $table,
           pressed = false;
      
      $(document).on({
          mousemove: function(event) {
              if (pressed) {
                  $handle.width(startWidth + (event.pageX - startX));
              }
          },
          mouseup: function() {
              if (pressed) {
                  $table.removeClass('resizing');
                  pressed = false;
              }
          }
      }).on('mousedown', '.table-resizable th', function(event) {
          $handle = $(this);
          pressed = true;
          startX = event.pageX;
          startWidth = $handle.width();
          
          $table = $handle.closest('.table-resizable').addClass('resizing');
      }).on('dblclick', '.table-resizable thead', function() {
          // Reset column sizes on double click
          $(this).find('th[style]').css('width', '');
      });
    }
  }
  
  