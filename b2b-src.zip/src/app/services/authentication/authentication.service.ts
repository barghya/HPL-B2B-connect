import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';
import Swal from 'sweetalert2';



@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }

  authenticate(body: any): Observable<any> {
    return this.http.post(ApiEndPoints.urls.loginUrl, body)
      .pipe(
        tap((user: any) => {
          if(user?.msg == 'Invalid login ID or password. Please try again.' && !user?.jwttoken){
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: user?.msg,
              showConfirmButton: true,
              allowEnterKey: false,
              allowOutsideClick: false
            }).then((result) => {
              // if (result.isConfirmed) {
              //   window.location.reload();
              // }
            })
          }
          if(user?.msg == 'Invalid user ID. Please provide a correct user ID.' && !user?.jwttoken){
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: user?.msg,
              showConfirmButton: true,
              allowEnterKey: false,
              allowOutsideClick: false
            }).then((result) => {
              // if (result.isConfirmed) {
              //   window.location.reload();
              // }
            })
          }
          if (user && user?.jwttoken) {
            sessionStorage.setItem('jwttoken', user.jwttoken);
            sessionStorage.setItem('user', JSON.stringify(user));
          }
          return user;
        }),

      )
  }


  resendResetPasswordMail(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.resendResetUrl, body)
  }

  sendResetPasswordMail(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.sendResetUrl, body)
  }

  validateCode(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.validateResetUrl, body)
  }

  resetPassword(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.resetPasswordUrl, body)
  }
  
}
