import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class ComplaintsManagementService {

  constructor(private http: HttpClient) { }

  // Logistical Complaints

  complaintsCountDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.complaintsCountDetailsUrl, body)
  }

  recentLogisticsComplaints(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.recentLogisticsComplaintsUrl, body)
  }

  complaintsDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.complaintsDetailsUrl, body)
  }

  avgResolvedTimeLogisticsComLineChartDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.avgResolvedTimeLogisticsComLineChartDetailsUrl, body)
  }

  downloadComplaint(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadComplaintUrl, body)
  }

  saveTechnicalComplaint(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.saveTechnicalComplaintUrl, body)
  }

  logisticComplaintAuditTrailDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.logisticComplaintAuditTrailDetailsUrl, body)
  }

  excelLogisticComplaintsTableData(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadExcelForLogisticComplaintsUrl, body);
  }

  downloadExcelForLogisticComplaints(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadExcelForLogisticComplaintsUrl, data, { responseType: 'blob' });
  }

  downloadTableDataLogisticComplaints(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadTableDataLogisticComplaintsUrl, data, { responseType: 'blob' });
  }


  // Technical Complaints

  technicalComplaintsCountDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.technicalComplaintsCountDetailsUrl, body)
  }

  avgResolvedTimeTechnicalComLineChartDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.avgResolvedTimeTechnicalComLineChartDetailsUrl, body)
  }

  recentTechnicalComplaints(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.recentTechnicalComplaintsUrl, body)
  }

  technicalComplaintsDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.technicalComplaintsDetailsUrl, body)
  }

  excelTechnicalComplaintsTableData(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadExcelTechnicalComplaintsUrl, body);
  }

  downloadExcelTechnicalComplaints(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadExcelTechnicalComplaintsUrl, data, { responseType: 'blob' });
  }

}
