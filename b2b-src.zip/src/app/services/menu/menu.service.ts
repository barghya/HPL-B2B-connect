import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  menuData : any = null;
  isMenuLoaded: any = null;
  
  constructor(private http: HttpClient) { }

  populateMenu(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.menuUrl, body)
  }

  custName(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.custNameUrl, body)
  }

}
