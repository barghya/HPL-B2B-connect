import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class MyTargetService {

  constructor(private http: HttpClient) { }

  customerByCSA(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.customerByCSAUrl, body)
  }

  targetUpload(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.targetUploadUrl, body)
  }

  targetDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.targetDetailsUrl, body)
  }

  processSalesTarget(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.processSalesTargetUrl, body)
  }

}
