import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }

  allCustomer(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.allCustomerUrl, body)
  }

  customerDetailsUrl(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.customerDetailsUrl, body)
  }

  raiseCustomerAmendment(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.raiseCustomerAmendmentUrl, body)
  }

  customerDetailsByIdUrl(url):Observable<any>{
    return this.http.get(url);
  }

  businessOfficerData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.businessOfficerDataUrl, body)
  }

  saveSOData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.saveSODataUrl, body)
  }

  saveOnboardingData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.saveOnboardingDataUrl, body)
  }

  uploadFileAmendment(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.uploadFileAmendmentUrl, body)
  }

  raiseAmendment(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.raiseAmendmentUrl, body)
  }

  searchAmendment(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.searchAmendmentUrl, body)
  }

  processAmendment(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.processAmendmentUrl, body)
  }

  custProfileData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.custProfileDataUrl, body)
  }

  previousAmendmentData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.previousAmendmentDataUrl, body)
  }

  customerAmendmentData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.customerAmendmentDataUrl, body)
  }

  sentMailToCustomer(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.sentMailToCustomerUrl, body)
  }

  
  downloadCustomerOnboarding(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadCustomerOnboardingUrl, data, { responseType: 'blob' });
  }

}
