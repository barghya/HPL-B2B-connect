import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class CommonApiService {

  constructor(private http: HttpClient) { }

  materialName():Observable<any>{
    return this.http.get(ApiEndPoints.urls.materialNameUrl)
  }

  roleMaster():Observable<any>{
    return this.http.get(ApiEndPoints.urls.roleMasterUrl)
  }

  regionMaster():Observable<any>{
    return this.http.get(ApiEndPoints.urls.regionMasterUrl)
  }

  viewAsValidation(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.viewAsValidationUrl, body)
  }

  viewAsCustCsa(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.viewAsCustCsaUrl, body)
  }

  customerType():Observable<any>{
    return this.http.get(ApiEndPoints.urls.customerTypeUrl)
  }

  generateHistoricalData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.generateHistoricalDataUrl, body)
  }

  downloadHistoricalDataList(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadHistoricalDataListUrl, body)
  }

}
