import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class AccountManagementService {

  constructor(private http: HttpClient) { }

  accountsCountDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.accountsCountDetailsUrl, body)
  }

  salesPurchaseTrendLineChart(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.salesPurchaseTrendLineChartUrl, body)
  }

  accountManagementDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.accountManagementDetailsUrl, body)
  }

  recentTransactions(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.recentTransactionsUrl, body)
  }

  accountsAgeingChartDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.accountsAgeingChartDetailsUrl, body)
  }

  excelDetailsPaymentOutstandingStatus(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadTableDataAccountManagementUrl, body);
  }

  downloadTableDataAccountManagement(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadTableDataAccountManagementUrl, data, { responseType: 'blob' });
  }


}
