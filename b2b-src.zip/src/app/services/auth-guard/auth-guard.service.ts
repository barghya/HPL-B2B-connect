import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, pipe, map, filter } from 'rxjs';
import { MenuService } from '../menu/menu.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuardService implements CanActivate {
  
  user: any;
  roleDetails: any;
  resp: any;
  resp1: any;
  mdmSubMenu: any


  constructor(private router: Router, private activRoute: ActivatedRoute, private menuService: MenuService) { }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    let res: boolean = true;
    const user = sessionStorage.getItem('jwttoken');
    if (this.menuService.isMenuLoaded && this.menuService.menuData) {

      if (this.user?.userRole[0]?.id == 11) {
        this.resp = this.checkAccess(this.menuService.menuData, '/uploadContribution');
      } else {
        this.resp = this.checkAccess(this.menuService.menuData, '/home');
      }

      if (user && this.resp) {
        res = true;
      } else {
        sessionStorage.clear();

        this.router.navigate(['/login']);
        res = false;
      }
      return res;
    }

    else {
      if (JSON.parse(sessionStorage.getItem('user'))) {
        this.getMenuData().subscribe((data) => {
          this.resp1 = this.checkAccess(data, state.url);
          
          if (user && this.resp1) {
            res = true;
           
          } else {
            sessionStorage.clear();
            this.router.navigate(['/login']);
            res = false;
          }
        });
        return res;
      }
      else {
        sessionStorage.clear();
        this.router.navigate(['/login']);
        res = false;
      }
    }

    return res;
  }

  getMenuData(): Observable<any> {
    this.user = JSON.parse(sessionStorage.getItem('user') || '');

    const body = {
      loggedinUserId: this.user.userId,
      loginFromApp: false
    };

    let response = this.menuService.populateMenu(body).pipe(
      map((result) => {
        return result;
      })
    );
    return response as Observable<any>;
  }


  getSubMenuFromMenu(data,menuName){
    let menuData = data.entries.filter(
      (n) => n.menuName === menuName
    );
    
    return menuData[0]?.subMenu;
  }

  checkAccess(data: any, page: string): boolean {

      if (this.user?.userRole[0]?.id == 6 && page == '/placeOrder') {
        this.router.navigate(['/home']);
      }
      
      if ((this.user?.userRole[0]?.id == 11 && (page != '/uploadContribution')) && (this.user?.userRole[0]?.id == 11 && (page != '/uploadCCS'))) {
        sessionStorage.clear();
        this.router.navigate(['/login']);
      }
      
      switch (page) {
        case '/home':
          return this.checkAccessToMenu(data, 'My Page');
          break;
        case '/customerOnboarding':
          return this.checkAccessToMenu(data, 'Customer Onboarding');
          break;
        case '/customerAmendment':
          return this.checkAccessToMenu(data, 'Customer Amendment');
          break;
        case '/amendmentReq':
          return this.user?.userTypeId == 2 ? this.checkAccessToMenu(data, 'Customer Amendment') : this.checkAccessToMenu(data, 'My Amendments');
          break;
        case '/salesOrderManagement':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Dashboard'), 'Sales Order Management');
          break;
        case '/dispatchManagement':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Dashboard'), 'Dispatch Management');
          break;
        case '/contributionCalculator':
          return this.checkAccessToMenu(data, 'Calculator');
          break;
        case '/placeOrder':
          return this.checkAccessToMenu(data, 'Place Order');
          break;
        case '/releaseOrder':
          return this.checkAccessToMenu(data, 'Release Blocked Orders');
          break;
        case '/complaintsManagement':
          return this.checkAccessToMenu(data, 'Complaints');
          break;
        case '/purchaseManagement':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Dashboard'), 'My Purchase');
          break;
        case '/accountManagement':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Dashboard'), 'My Account');
          break;
        case '/uploadCCS':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Master Data Management'), 'Upload CCS');
          break;
        case '/userDataManagement':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Master Data Management'), 'User Data Management');
          break;
        case '/reports':
          return this.checkAccessToMenu(data, 'Reports');
          break;
        case '/uploadContribution':
          return this.checkAccessToSubMenu(this.getSubMenuFromMenu(data, 'Master Data Management'), 'Upload Contribution');
          break;
        default:
          return true;
      }

  }

  checkAccessToMenu(data: any, menuName: string): boolean {
    let um = data?.entries.filter((n) => n?.menuName === menuName);
    if (um && um[0]) {
      return true;
    }
    return false;
  }

  checkAccessToSubMenu(data: any, subMenu: string): boolean {
    let um = data?.subMenu.filter((n) => n?.subMenuName === subMenu);
    if (um && um[0]) {
      return true;
    }
    return false;
  }
}
