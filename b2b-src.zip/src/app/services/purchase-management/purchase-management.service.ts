import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class PurchaseManagementService {

  constructor(private http: HttpClient) { }

  purchaseManagementCountDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.purchaseManagementCountDetailsUrl, body)
  }

  purchaseManagementDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.purchaseManagementDetailsUrl, body)
  }

  purchaseManagementLineBarChart(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.purchaseManagementLineBarChartUrl, body)
  }

  purchaseManagementValueQtyChart(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.purchaseManagementValueQtyChartUrl, body)
  }

  topCustomersSales(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.topCustomersSalesUrl, body)
  }

  targetRemaining(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.targetRemainingUrl, body)
  }

  gccGraph(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.gccGraphUrl, body)
  }

  topCustomerDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.topCustomerDetailsUrl, body)
  }

  excelDataForOverallSalesQty(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadPurchaseTrendValueQtyReportUrl, body);
  }

  excelDataForOverallSalesGcc(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadSalesComparisonGccWiseQtyValUrl, body);
  }

  excelAgeingChartData(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadAccAgeingChartDataUrl, body);
  }
  
  downloadTableDataPurchaseManagement(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadTableDataPurchaseManagementUrl, data, { responseType: 'blob' });
  }

  downloadPurchaseTrendValueQtyReport(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadPurchaseTrendValueQtyReportUrl, data, { responseType: 'blob' });
  }

  downloadSalesComparisonGccWiseQtyVal(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadSalesComparisonGccWiseQtyValUrl, data, { responseType: 'blob' });
  }

  downloadAccAgeingChartData(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadAccAgeingChartDataUrl, data, { responseType: 'blob' });
  }

}
