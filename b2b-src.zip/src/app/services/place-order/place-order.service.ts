import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class PlaceOrderService {

  constructor(private http: HttpClient) { }

  // fetchPlaceOrderDetails(body):Observable<any>{
  //   return this.http.post(ApiEndPoints.urls.fetchPlaceOrderDetailsUrl, body)
  // }

  savePlaceOrderDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.savePlaceOrderDetailsUrl, body)
  }

  productItems():Observable<any>{
    return this.http.get(ApiEndPoints.urls.productItemsUrl)
  }

  customerAddress(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.customerAddressUrl, body)
  }

  placeOrder(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.placeOrderUrl, body)
  }

  getEmailCSA(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.getEmailCSAUrl, body)
  }

}
