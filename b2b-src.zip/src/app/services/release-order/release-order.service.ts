import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';


@Injectable({
  providedIn: 'root'
})
export class ReleaseOrderService {

  constructor(private http: HttpClient) { }

  fetchReleaseOrderDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.fetchReleaseOrderDetailsUrl, body)
  }

  saveReleaseOrderDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.saveReleaseOrderDetailsUrl, body)
  }

}
