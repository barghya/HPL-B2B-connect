import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {

  constructor(private http: HttpClient) { }

  userList(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.userListUrl, body)
  }

  updateEmployeeActivation(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.updateEmployeeActivationUrl, body)
  }

  createUser(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.createUserUrl, body)
  }

  editUser(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.editUserUrl, body)
  }

}
