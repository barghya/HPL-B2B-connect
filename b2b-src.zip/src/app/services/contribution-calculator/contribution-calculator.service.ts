import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class ContributionCalculatorService {

  constructor(private http: HttpClient) { }

  uploadContributionCalculator(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.uploadContributionCalculatorUrl, body)
  }

  searchContributionDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.searchContributionDetailsUrl, body)
  }

  processContribution(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.processContributionUrl, body)
  }

  getChildShipToParty(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.getChildShipToPartyUrl, body)
  }

  getContributionData(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.getContributionDataUrl, body)
  }

  getGrade():Observable<any>{
    return this.http.get(ApiEndPoints.urls.getGradeUrl)
  }

  getGradebyProduct(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.getGradebyProductUrl, body)
  }

  getBillTpParty(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.billToPartyUrl, body)
  }

  getLocation():Observable<any>{
    return this.http.get(ApiEndPoints.urls.getLocationUrl)
  }

  sendEmail(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.sendEmailUrl, body)
  }

}
