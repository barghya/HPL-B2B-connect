import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class DispatchManagementService {

  constructor(private http: HttpClient) { }

  dispatchCountDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.dispatchCountDetailsUrl, body)
  }

  recentDeliveryDispatchDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.recentDeliveryDispatchDetailsUrl, body)
  }

  dispatchDetails(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.dispatchDetailsUrl, body)
  }

  individualTripDetails(url):Observable<any>{
    return this.http.get(url);
  }

  excelChartTableData(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadDispatchGraphReportUrl, body);
  }

  downloadDispatchGraphReport(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadDispatchGraphReportUrl, data, { responseType: 'blob' });
  }

  vehicleViewInMap(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.vehicleViewInMapUrl, body);
  }

  fetchAck():Observable<any>{
    return this.http.get(ApiEndPoints.urls.fetchAckUrl)
  }

  ackSave(body): Observable<any>{
    return this.http.post(ApiEndPoints.urls.ackSaveUrl, body);
  }

  downloadTableDataDispatch(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadTableDataDispatchUrl, data, { responseType: 'blob' });
  }

}
