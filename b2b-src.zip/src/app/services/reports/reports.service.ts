import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  constructor(private http: HttpClient) { }

  
  fetchAmendmentReport(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.fetchAmendmentReportUrl, body)
  }

  fetchCustomerOnboardedReport(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.fetchCustomerOnboardedReportUrl, body)
  }

  fetchNotOperatedCustomerReport(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.fetchNotOperatedCustomerReportUrl, body)
  }

  fetchPlaceOrderReport(body):Observable<any>{
    return this.http.post(ApiEndPoints.urls.fetchPlaceOrderReportUrl, body)
  }

  downloadAmendmentReport(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadAmendmentReportUrl, data, { responseType: 'blob' });
  }

  downloadCustomerOnboardedReport(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadCustomerOnboardedReportUrl, data, { responseType: 'blob' });
  }

  downloadNotOperatedCustomerReport(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadNotOperatedCustomerReportUrl, data, { responseType: 'blob' });
  }

  downloadPlaceOrderReport(data:any): Observable<any>{
    return this.http.post(ApiEndPoints.urls.downloadPlaceOrderReportUrl, data, { responseType: 'blob' });
  }


}
