import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './components/shareable-components/sidebar/sidebar.component';
import { SalesOrderManagementComponent } from './components/sales-order-management/sales-order-management.component';
import { AccountManagementComponent } from './components/account-management/account-management.component';
import { DispatchManagementComponent } from './components/dispatch-management/dispatch-management.component';
import { CustomersManagementComponent } from './components/customers-management/customers-management.component';
import { ComplaintsManagementComponent } from './components/complaints-management/complaints-management.component';
import { ContributionCalculatorComponent } from './components/contribution-calculator/contribution-calculator.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderComponent } from './components/loader/loader.component';
import { LoaderService } from './utils/loader-service';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { HttpRequestInterceptorService } from './interceptor/HTTP.interceptor';
import { HomePageComponent } from './components/home-page/home-page.component';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatDividerModule } from '@angular/material/divider';
import { MatDialogModule } from '@angular/material/dialog';
import { CustomerActivationPopupComponent } from './components/customer-activation-popup/customer-activation-popup.component';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { MatTabsModule } from '@angular/material/tabs';
import { ReleaseOrderComponent } from './components/release-order/release-order.component';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { NgxPaginationModule } from 'ngx-pagination';
import { PaginationComponent } from './components/pagination/pagination.component';
import { ReleaseOrderPopupComponent } from './components/release-order-popup/release-order-popup.component';
import { NgxEchartsModule } from 'ngx-echarts';
import { DeliveryInfoDetailsComponent } from './components/delivery-info-details/delivery-info-details.component';
import { DispatchStatusQtyDonutChartComponent } from './components/dispatch-status-qty-donut-chart/dispatch-status-qty-donut-chart.component';
import { DeliveryTimeDispatchDonutChartComponent } from './components/delivery-time-dispatch-donut-chart/delivery-time-dispatch-donut-chart.component';
import { AcknowledgementPopupComponent } from './components/acknowledgement-popup/acknowledgement-popup.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';
import { LogisticsComplaintsStatusDonutChartComponent } from './components/logistics-complaints-status-donut-chart/logistics-complaints-status-donut-chart.component';
import { AvgResolveTimeLogisticsComplaintLineChartComponent } from './components/avg-resolve-time-logistics-complaint-line-chart/avg-resolve-time-logistics-complaint-line-chart.component';
import { ComplaintsDownloadPopupComponent } from './components/complaints-download-popup/complaints-download-popup.component';
import { LogisticComplaintsAuditTrailDetailsComponent } from './components/logistic-complaints-audit-trail-details/logistic-complaints-audit-trail-details.component';
import { PurchaseManagementComponent } from './components/purchase-management/purchase-management.component';
import { TargetAchievementPurchaseValueDonutChartComponent } from './components/target-achievement-purchase-value-donut-chart/target-achievement-purchase-value-donut-chart.component';
import { OverallPuchaseTrendValueQtyChartComponent } from './components/overall-puchase-trend-value-qty-chart/overall-puchase-trend-value-qty-chart.component';
import { MyTargetComponent } from './components/my-target/my-target.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { SalesPurchaseTrendLineChartComponent } from './components/sales-purchase-trend-line-chart/sales-purchase-trend-line-chart.component';
import { PaymentStatusDonutChartComponent } from './components/payment-status-donut-chart/payment-status-donut-chart.component';
import { OutstandingStatusDonutChartComponent } from './components/outstanding-status-donut-chart/outstanding-status-donut-chart.component';
import { UserDataManagementDetailsComponent } from './components/user-data-management-details/user-data-management-details.component';
import { UserAddPopupComponent } from './components/user-add-popup/user-add-popup.component';
import { UserEditPopupComponent } from './components/user-edit-popup/user-edit-popup.component';
import { ReportsComponent } from './components/reports/reports.component';
import { UploadContributionComponent } from './components/upload-contribution/upload-contribution.component';
import { CustomerAmendmentComponent } from './components/customer-amendment/customer-amendment.component';
import { AmendmentActionPopupComponent } from './components/amendment-action-popup/amendment-action-popup.component';
import { MatBadgeModule } from '@angular/material/badge';
import { TechnicalComplaintsStatusDonutChartComponent } from './components/technical-complaints-status-donut-chart/technical-complaints-status-donut-chart.component';
import { AvgResolveTimeTechnicalCompLineChartComponent } from './components/avg-resolve-time-technical-comp-line-chart/avg-resolve-time-technical-comp-line-chart.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { CcMailPopupComponent } from './components/cc-mail-popup/cc-mail-popup.component';
import { MatStepperModule } from '@angular/material/stepper';
import { SalesComparisonGccWiseValueBarChartComponent } from './components/sales-comparison-gcc-wise-value-bar-chart/sales-comparison-gcc-wise-value-bar-chart.component';
import { SalesComparisonGccWiseQtyBarChartComponent } from './components/sales-comparison-gcc-wise-qty-bar-chart/sales-comparison-gcc-wise-qty-bar-chart.component';
import { TopCustomerExpandPopupComponent } from './components/top-customer-expand-popup/top-customer-expand-popup.component';
import { OverallSalesTrendValueComponent } from './components/overall-sales-trend-value/overall-sales-trend-value.component';
import { OverallSalesTrendQtyComponent } from './components/overall-sales-trend-qty/overall-sales-trend-qty.component';
import { AmendmentReqComponent } from './components/amendment-req/amendment-req.component';
import { PreviousAmendmentDetailsComponent } from './components/previous-amendment-details/previous-amendment-details.component';
import { ShortNumberPipe } from './short-number-pipe';
import {MatExpansionModule} from '@angular/material/expansion';
import { PurchaseActualTargetComboChartComponent } from './components/purchase-actual-target-combo-chart/purchase-actual-target-combo-chart.component';
import { AccountAgeingChartComponent } from './components/account-ageing-chart/account-ageing-chart.component';
import { SalesOrderChartDetailsPopupComponent } from './components/sales-order-chart-details-popup/sales-order-chart-details-popup.component';
import { AccountsChartDetailsPopupComponent } from './components/accounts-chart-details-popup/accounts-chart-details-popup.component';
import { ComplaintChartDetailsPopupComponent } from './components/complaint-chart-details-popup/complaint-chart-details-popup.component';
import { DispatchChartDetailsPopupComponent } from './components/dispatch-chart-details-popup/dispatch-chart-details-popup.component';
import { SortDirective } from './utils/sort.directive';
import { AuthGuardService } from './services/auth-guard/auth-guard.service';
import { ViewHistoricalPopupComponent } from './components/view-historical-popup/view-historical-popup.component';
import { SendEmailSoCustomerPopupComponent } from './components/send-email-so-customer-popup/send-email-so-customer-popup.component';
import { TechnicalComplaintDetailsPopupComponent } from './components/technical-complaint-details-popup/technical-complaint-details-popup.component';
import { DispatchDetailsPopupComponent } from './components/dispatch-details-popup/dispatch-details-popup.component';


export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD-MM-YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};


@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    SalesOrderManagementComponent,
    AccountManagementComponent,
    DispatchManagementComponent,
    CustomersManagementComponent,
    ComplaintsManagementComponent,
    ContributionCalculatorComponent,
    LoaderComponent,
    HomePageComponent,
    CustomerActivationPopupComponent,
    PlaceOrderComponent,
    ReleaseOrderComponent,
    PaginationComponent,
    ReleaseOrderPopupComponent,
    DeliveryInfoDetailsComponent,
    DispatchStatusQtyDonutChartComponent,
    DeliveryTimeDispatchDonutChartComponent,
    AcknowledgementPopupComponent,
    LogisticsComplaintsStatusDonutChartComponent,
    AvgResolveTimeLogisticsComplaintLineChartComponent,
    ComplaintsDownloadPopupComponent,
    LogisticComplaintsAuditTrailDetailsComponent,
    PurchaseManagementComponent,
    TargetAchievementPurchaseValueDonutChartComponent,
    OverallPuchaseTrendValueQtyChartComponent,
    MyTargetComponent,
    SalesPurchaseTrendLineChartComponent,
    PaymentStatusDonutChartComponent,
    OutstandingStatusDonutChartComponent,
    UserDataManagementDetailsComponent,
    UserAddPopupComponent,
    UserEditPopupComponent,
    ReportsComponent,
    UploadContributionComponent,
    CustomerAmendmentComponent,
    AmendmentActionPopupComponent,
    TechnicalComplaintsStatusDonutChartComponent,
    AvgResolveTimeTechnicalCompLineChartComponent,
    CcMailPopupComponent,
    SalesComparisonGccWiseValueBarChartComponent,
    SalesComparisonGccWiseQtyBarChartComponent,
    TopCustomerExpandPopupComponent,
    OverallSalesTrendValueComponent,
    OverallSalesTrendQtyComponent,
    AmendmentReqComponent,
    PreviousAmendmentDetailsComponent,
    ShortNumberPipe,
    SortDirective,
    PurchaseActualTargetComboChartComponent,
    AccountAgeingChartComponent,
    SalesOrderChartDetailsPopupComponent,
    AccountsChartDetailsPopupComponent,
    ComplaintChartDetailsPopupComponent,
    DispatchChartDetailsPopupComponent,
    ViewHistoricalPopupComponent,
    SendEmailSoCustomerPopupComponent,
    TechnicalComplaintDetailsPopupComponent,
    DispatchDetailsPopupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatButtonModule,
    MatSnackBarModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    MatMenuModule,
    MatTooltipModule,
    NgbModule,
    MatDividerModule,
    MatDialogModule,
    MatTabsModule,
    MatSelectModule,
    MatInputModule,
    NgxPaginationModule,
    MatDatepickerModule,
    MatRadioModule,
    MatBadgeModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatStepperModule,
    MatExpansionModule,
    NgxEchartsModule.forRoot({
      echarts: () => import('echarts')
    }),
  ],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    LoaderService,
    AuthGuardService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpRequestInterceptorService,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class AppModule { }
