import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { CaptchaModule } from './components/captcha/captcha.module';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { HomePageComponent } from './components/home-page/home-page.component';
import { SalesOrderManagementComponent } from './components/sales-order-management/sales-order-management.component';
import { AccountManagementComponent } from './components/account-management/account-management.component';
import { DispatchManagementComponent } from './components/dispatch-management/dispatch-management.component';
import { CustomersManagementComponent } from './components/customers-management/customers-management.component';
import { ContributionCalculatorComponent } from './components/contribution-calculator/contribution-calculator.component';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { ReleaseOrderComponent } from './components/release-order/release-order.component';
import { ComplaintsManagementComponent } from './components/complaints-management/complaints-management.component';
import { PurchaseManagementComponent } from './components/purchase-management/purchase-management.component';
import { MyTargetComponent } from './components/my-target/my-target.component';
import { UserDataManagementDetailsComponent } from './components/user-data-management-details/user-data-management-details.component';
import { ReportsComponent } from './components/reports/reports.component';
import { UploadContributionComponent } from './components/upload-contribution/upload-contribution.component';
import { CustomerAmendmentComponent } from './components/customer-amendment/customer-amendment.component';
import { AmendmentReqComponent } from './components/amendment-req/amendment-req.component';
import { AuthGuardService } from './services/auth-guard/auth-guard.service';


const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomePageComponent , canActivate: [AuthGuardService]},
  { path: 'salesOrderManagement', component: SalesOrderManagementComponent, canActivate: [AuthGuardService] },
  { path: 'accountManagement', component: AccountManagementComponent, canActivate: [AuthGuardService] },
  { path: 'dispatchManagement', component: DispatchManagementComponent, canActivate: [AuthGuardService] },
  { path: 'customerOnboarding', component: CustomersManagementComponent, canActivate: [AuthGuardService] },
  { path: 'contributionCalculator', component: ContributionCalculatorComponent, canActivate: [AuthGuardService] },
  { path: 'placeOrder', component: PlaceOrderComponent, canActivate: [AuthGuardService] },
  { path: 'releaseOrder', component: ReleaseOrderComponent, canActivate: [AuthGuardService] },
  { path: 'complaintsManagement', component: ComplaintsManagementComponent, canActivate: [AuthGuardService] },
  { path: 'purchaseManagement', component: PurchaseManagementComponent, canActivate: [AuthGuardService] },
  { path: 'uploadCCS', component: MyTargetComponent, canActivate: [AuthGuardService] },
  { path: 'userDataManagement', component: UserDataManagementDetailsComponent, canActivate: [AuthGuardService] },
  { path: 'reports', component: ReportsComponent, canActivate: [AuthGuardService] },
  { path: 'uploadContribution', component: UploadContributionComponent, canActivate: [AuthGuardService] },
  { path: 'customerAmendment', component: CustomerAmendmentComponent, canActivate: [AuthGuardService] },
  { path: 'amendmentReq', component: AmendmentReqComponent, canActivate: [AuthGuardService] },
  { path: 'contributionCalculator', component: ContributionCalculatorComponent, canActivate: [AuthGuardService] },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true }), CommonModule, BrowserModule, CaptchaModule],
  exports: [RouterModule],
  declarations: [LoginComponent]
})
export class AppRoutingModule { }
