import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { ReleaseOrderService } from 'src/app/services/release-order/release-order.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-release-order-popup',
  templateUrl: './release-order-popup.component.html',
  styleUrls: ['./release-order-popup.component.css']
})
export class ReleaseOrderPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  headerPopup: boolean = true;
  officersEmail: any;
  officersRemarks: any;


  constructor(private commonservice: CommonService, private releaseOrderService: ReleaseOrderService, private loaderService: LoaderService, private dialogRef: MatDialogRef<ReleaseOrderPopupComponent>, @Inject(MAT_DIALOG_DATA) public releaseOrderData: any) { }

  ngOnInit(): void {
    if (this.releaseOrderData.callFrom == 'Bulk Approve') {
      this.headerPopup = false;
    }

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  closePopup() {
    this.dialogRef.close();
  }

  releaseOrder() {

    let validEmail = this.commonservice.regexForEmail(this.officersEmail);

    if (!this.officersEmail) {
      Swal.fire(alertPopup.mailEmpty);
    } 
    else if(!validEmail){
      Swal.fire(alertPopup.validmail);
    }else {
      if (this.releaseOrderData.callFrom == 'Bulk Approve') {
        if (!this.officersEmail) {
          Swal.fire(alertPopup.mailEmpty);
        } else {

        }
        let payload = {
          id: this.releaseOrderData?.bulkDelvOrderNo,
          cumulOrderQty: this.releaseOrderData?.bulkCumulConfirmedQty,
          shipToParty: this.releaseOrderData?.bulkShipToParty,
          emailId: this.officersEmail,
          remarks: this.officersRemarks,
          userId: this.user.userId,
          loginFromApp: false
        }

        this.loaderService.show();
        this.releaseOrderService.saveReleaseOrderDetails(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            if (data?.status == 1) {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: data.message,
                showCancelButton: false,
                allowEnterKey: false,
                allowOutsideClick: false,
              }).then((result) => {
                if (result.isConfirmed) {
                  window.location.reload();
                }
              })
            } else {
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: data.message,
                showCancelButton: false,
                allowEnterKey: false,
                allowOutsideClick: false,
              }).then((result) => {
                if (result.isConfirmed) {
                  window.location.reload();
                }
              })
            }
          }
        })
      } else {
        let payload = {
          id: [this.releaseOrderData?.delvOrderNo],
          cumulOrderQty: [this.releaseOrderData?.cumulOrderQty],
          shipToParty: [this.releaseOrderData?.shipToParty],
          emailId: this.officersEmail,
          remarks: this.officersRemarks,
          userId: this.user.userId,
          loginFromApp: false
        }

        this.loaderService.show();
        this.releaseOrderService.saveReleaseOrderDetails(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            if (data?.status == 1) {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: data.message,
                showCancelButton: false,
                allowEnterKey: false,
                allowOutsideClick: false,
              }).then((result) => {
                if (result.isConfirmed) {
                  window.location.reload();
                }
              })
            } else {
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: data.message,
                showCancelButton: false,
                allowEnterKey: false,
                allowOutsideClick: false,
              }).then((result) => {
                if (result.isConfirmed) {
                  window.location.reload();
                }
              })
            }
          }
        })
      }
    }

  }


}
