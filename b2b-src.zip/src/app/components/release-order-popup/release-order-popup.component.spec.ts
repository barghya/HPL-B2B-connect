import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReleaseOrderPopupComponent } from './release-order-popup.component';

describe('ReleaseOrderPopupComponent', () => {
  let component: ReleaseOrderPopupComponent;
  let fixture: ComponentFixture<ReleaseOrderPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReleaseOrderPopupComponent]
    });
    fixture = TestBed.createComponent(ReleaseOrderPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
