import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousAmendmentDetailsComponent } from './previous-amendment-details.component';

describe('PreviousAmendmentDetailsComponent', () => {
  let component: PreviousAmendmentDetailsComponent;
  let fixture: ComponentFixture<PreviousAmendmentDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PreviousAmendmentDetailsComponent]
    });
    fixture = TestBed.createComponent(PreviousAmendmentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
