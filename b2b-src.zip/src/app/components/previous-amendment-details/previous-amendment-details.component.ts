import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { saveAs } from 'file-saver';
import { ReplaySubject, takeUntil } from 'rxjs';
import { DownloadService } from 'src/app/services/download/download.service';


@Component({
  selector: 'app-previous-amendment-details',
  templateUrl: './previous-amendment-details.component.html',
  styleUrls: ['./previous-amendment-details.component.css']
})
export class PreviousAmendmentDetailsComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  attachmentFile: any;
  attachmentFileName: any;


  constructor(private downloadService: DownloadService, private dialogRef: MatDialogRef<PreviousAmendmentDetailsComponent>, @Inject(MAT_DIALOG_DATA) public individualPreviousAmendmentData: any){}

  ngOnInit(): void {
    this.individualPreviousAmendmentData?.attachement.forEach(ele => {
      this.attachmentFile = ele?.filePath;
      this.attachmentFileName = ele?.name;
    })
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  closePopup(){
    this.dialogRef.close();
  }
  
  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }
  
}
