import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { ReportsService } from 'src/app/services/reports/reports.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';
import { PreviousAmendmentDetailsComponent } from '../previous-amendment-details/previous-amendment-details.component';
import { saveAs } from 'file-saver';
import { DownloadService } from 'src/app/services/download/download.service';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit , OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  startDateAmendment: any;
  endDateAmendment: any;
  startDateCustomerOnboarded: any;
  endDateCustomerOnboarded: any;
  startDateNotOperatedCustomer: any;
  endDateNotOperatedCustomer: any;
  startDatePlaceOrder: any;
  endDatePlaceOrder: any;
  todayDate = moment(new Date()).format('YYYY-MM-DD');
  amendmentReportData: any[] = [];
  customerOnboardedReportData: any[] = [];
  notOperatedCustomerReportData: any[] = [];
  placeOrderReportData: any[] = [];
  pageNoCustomerOnboardedReportData
  pageNoAmendmentReportData = 1;
  pageNoNotOperatedCustomerData = 1;
  pageNoPlaceOrderData = 1;
  isExcelAmendment: boolean = false;
  isExcelActiveCustomerOnboarded: boolean = false;
  isExcelActiveNotOperatedCustomer: boolean = false;
  isExcelActivePlaceOrder: boolean = false;
  selectedOption: any;
  selectedId: boolean;
  individualPreviousAmendmentData: any
  attachmentFile: any;
  attachmentFileName: any;

  constructor(private downloadService: DownloadService, private dialog: MatDialog, private customerService: CustomerService, private reportService: ReportsService, private loaderService: LoaderService, private commonservice: CommonService) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  dateChangeAmendment() {
    this.isExcelAmendment = false;
  }

  dateChangeCustomerOnboarded() {
    this.isExcelActiveCustomerOnboarded = false;
  }

  dateChangeNotOperatedCustomer() {
    this.isExcelActiveNotOperatedCustomer = false;
  }

  dateChangePlaceOrder() {
    this.isExcelActivePlaceOrder = false;
  }

  viewAmendmentReport() {
    this.profileDetails();
    
    if (!this.startDateAmendment) {
      Swal.fire(alertPopup.startDate);
    }
    else if (!this.endDateAmendment) {
      Swal.fire(alertPopup.endDate);
    }
    else if (this.startDateAmendment > this.todayDate) {
      Swal.fire(alertPopup.todayStartDateValidation);
    }
    else if (this.endDateAmendment > this.todayDate) {
      Swal.fire(alertPopup.todayendateValidation);
    }
    else if (this.startDateAmendment > this.endDateAmendment) {
      Swal.fire(alertPopup.dateValidation);
    } else {
      let payload = {
        startDate: this.commonservice.convertDateTimeISO(this.startDateAmendment, true),
        endDate: this.commonservice.convertDateTimeISO(this.endDateAmendment, true)
      }

      this.loaderService.show();
      this.reportService.fetchAmendmentReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data != null) {
          this.amendmentReportData = data;
          this.isExcelAmendment = true;
          this.pageNoAmendmentReportData = 1;
          this.amendmentReportData.map((ele) => {
            ele.checked = false;
          })
        }
      })
    }
  }

  viewCustomerOnboardedReport() {
    if (!this.startDateCustomerOnboarded) {
      Swal.fire(alertPopup.startDate);
    }
    else if (!this.endDateCustomerOnboarded) {
      Swal.fire(alertPopup.endDate);
    }
    else if (this.startDateCustomerOnboarded > this.todayDate) {
      Swal.fire(alertPopup.todayStartDateValidation);
    }
    else if (this.endDateCustomerOnboarded > this.todayDate) {
      Swal.fire(alertPopup.todayendateValidation);
    }
    else if (this.startDateCustomerOnboarded > this.endDateCustomerOnboarded) {
      Swal.fire(alertPopup.dateValidation);
    } else {
      let payload = {
        startDate: this.commonservice.convertDateTimeISO(this.startDateCustomerOnboarded, true),
        endDate: this.commonservice.convertDateTimeISO(this.endDateCustomerOnboarded, true)
      }

      this.loaderService.show();
      this.reportService.fetchCustomerOnboardedReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data != null) {
          this.customerOnboardedReportData = data;
          this.isExcelActiveCustomerOnboarded = true;
          this.pageNoCustomerOnboardedReportData = 1;
        }
      })
    }

  }

  viewDateNotOperatedCustomer() {
    if (!this.startDateNotOperatedCustomer) {
      Swal.fire(alertPopup.startDate);
    }
    else if (!this.endDateNotOperatedCustomer) {
      Swal.fire(alertPopup.endDate);
    }
    else if (this.startDateNotOperatedCustomer > this.todayDate) {
      Swal.fire(alertPopup.todayStartDateValidation);
    }
    else if (this.endDateNotOperatedCustomer > this.todayDate) {
      Swal.fire(alertPopup.todayendateValidation);
    }
    else if (this.startDateNotOperatedCustomer > this.endDateNotOperatedCustomer) {
      Swal.fire(alertPopup.dateValidation);
    } else {
      let payload = {
        startDate: this.commonservice.convertDateTimeISO(this.startDateNotOperatedCustomer, true),
        endDate: this.commonservice.convertDateTimeISO(this.endDateNotOperatedCustomer, true)
      }

      this.loaderService.show();
      this.reportService.fetchNotOperatedCustomerReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data != null) {
          this.notOperatedCustomerReportData = data;
          this.isExcelActiveNotOperatedCustomer = true;
          this.pageNoNotOperatedCustomerData = 1;
        }
      })
    }

  }

  viewPlaceOrder() {
    if (!this.startDatePlaceOrder) {
      Swal.fire(alertPopup.startDate);
    }
    else if (!this.endDatePlaceOrder) {
      Swal.fire(alertPopup.endDate);
    }
    else if (this.startDatePlaceOrder > this.todayDate) {
      Swal.fire(alertPopup.todayStartDateValidation);
    }
    else if (this.endDatePlaceOrder > this.todayDate) {
      Swal.fire(alertPopup.todayendateValidation);
    }
    else if (this.startDatePlaceOrder > this.endDatePlaceOrder) {
      Swal.fire(alertPopup.dateValidation);
    } else {
      let payload = {
        startDate: this.commonservice.convertDateTimeISO(this.startDatePlaceOrder, true),
        endDate: this.commonservice.convertDateTimeISO(this.endDatePlaceOrder, true)
      }

      this.loaderService.show();
      this.reportService.fetchPlaceOrderReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data != null) {
          this.placeOrderReportData = data;
          this.isExcelActivePlaceOrder = true;
          this.pageNoPlaceOrderData = 1;
        }
      })
    }

  }

  downloadAmendmentReport() {
    let payload = {
      startDate: this.commonservice.convertDateTimeISO(this.startDateAmendment, true),
      endDate: this.commonservice.convertDateTimeISO(this.endDateAmendment, true),
      userType: "BU",
    }

    this.loaderService.show();
    this.reportService.downloadAmendmentReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(data);
      link.download = "Amendment_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
      link.click();
    })
  }

  downloadCustomerOnboardedReport() {
    let payload = {
      startDate: this.commonservice.convertDateTimeISO(this.startDateCustomerOnboarded, true),
      endDate: this.commonservice.convertDateTimeISO(this.endDateCustomerOnboarded, true),
      userType: "BU",
    }

    this.loaderService.show();
    this.reportService.downloadCustomerOnboardedReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(data);
      link.download = "Customer_Onboarded_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
      link.click();
    })
  }

  downloadNotOperatedCustomer() {
    let payload = {
      startDate: this.commonservice.convertDateTimeISO(this.startDateNotOperatedCustomer, true),
      endDate: this.commonservice.convertDateTimeISO(this.endDateNotOperatedCustomer, true),
      userType: "BU",
    }

    this.loaderService.show();
    this.reportService.downloadNotOperatedCustomerReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(data);
      link.download = "Customer_Usage_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
      link.click();
    })
  }

  downloadPlaceOrder() {
    let payload = {
      startDate: this.commonservice.convertDateTimeISO(this.startDatePlaceOrder, true),
      endDate: this.commonservice.convertDateTimeISO(this.endDatePlaceOrder, true),
      userType: "BU",
    }

    this.loaderService.show();
    this.reportService.downloadPlaceOrderReport(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(data);
      link.download = "Place_Order_Details_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
      link.click();
    })
  }

  resetAmendmentReport() {
    window.location.reload();
  }

  resetCustomerOnboardedReport() {
    window.location.reload();
  }

  resetDateNotOperatedCustomer() {
    window.location.reload();
  }

  resetPlaceOrder() {
    window.location.reload();
  }

  viewDetailsForIndividualAmendment(evt: any, item: any) {

    this.selectedOption = item.id;
    this.amendmentReportData.map((ele) => {
      if (item.id == ele.id) {
        ele.checked = true;
      } else {
        ele.checked = false;
      }
    })

    let payload = {
      id: item?.id
    }

    this.loaderService.show();
    this.customerService.customerAmendmentData(payload).pipe(takeUntil(this.destroyed$)).subscribe(dataAmendment => {
      if (dataAmendment && dataAmendment != null) {
        this.individualPreviousAmendmentData = dataAmendment;
        this.individualPreviousAmendmentData?.attachement.forEach(ele => {
          this.attachmentFile = ele?.filePath;
          this.attachmentFileName = ele?.name;

        })
        //this.dialog.open(PreviousAmendmentDetailsComponent, { disableClose: true, width: '70%', height: '80%', data: dataAmendment });
      }
    })

    // let payload = {
    //   id: item?.id
    // }

    // this.loaderService.show();
    // this.customerService.customerAmendmentData(payload).pipe(takeUntil(this.destroyed$)).subscribe(dataAmendment => {
    //   if(dataAmendment && dataAmendment!= null){
    //     this.dialog.open(PreviousAmendmentDetailsComponent, { disableClose: true, width: '70%', height: '80%', data: dataAmendment });
    //   }
    // })

  }

  profileDetails(){
    this.amendmentReportData.map((ele) => {
      if(this.selectedOption == ele.id){
        ele.checked = false;
        this.selectedOption = null;
      }   
     })
  }

  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }


}
