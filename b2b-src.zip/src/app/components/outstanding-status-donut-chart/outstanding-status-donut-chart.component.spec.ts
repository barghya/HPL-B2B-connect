import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutstandingStatusDonutChartComponent } from './outstanding-status-donut-chart.component';

describe('OutstandingStatusDonutChartComponent', () => {
  let component: OutstandingStatusDonutChartComponent;
  let fixture: ComponentFixture<OutstandingStatusDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OutstandingStatusDonutChartComponent]
    });
    fixture = TestBed.createComponent(OutstandingStatusDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
