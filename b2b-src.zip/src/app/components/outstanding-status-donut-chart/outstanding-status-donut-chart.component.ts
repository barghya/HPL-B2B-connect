import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-outstanding-status-donut-chart',
  templateUrl: './outstanding-status-donut-chart.component.html',
  styleUrls: ['./outstanding-status-donut-chart.component.css']
})
export class OutstandingStatusDonutChartComponent implements OnInit {

  @Input() inputDataOutstandingStatus: any;
  user = JSON.parse(sessionStorage.getItem('user') || '');


  ngOnInit(): void {
    this.praparedOutstandingStatusData();
  }

  praparedOutstandingStatusData() {
    if (this.user?.userTypeId == 1) {
      // this.inputDataOutstandingStatus = {
      //   grid:{left:'10%', width:'67%', height:'62%'},
      //   legend: {},
      //   tooltip: {},
      //   dataset: {
      //     source: this.inputDataOutstandingStatus,
      //   },
      //   xAxis: {
      //     type: 'category', 
      //     axisTick: {
      //       alignWithLabel: true
      //     }
      //   },
      //   yAxis: [{
      //     // type: 'value',
      //     // axisLabel: {
      //     //   formatter: function (value) {
      //     //     if (value >= 0 && value < 1000) {
      //     //       value;
      //     //     }
      //     //     if (value >= 1000 && value < 100000) {
      //     //       value = value / 1000 + "K";
      //     //     }
      //     //     if (value >= 100000 && value < 1000000) {
      //     //       value = value / 1000000 + "M";
      //     //     }
      //     //     if (value >= 1000000) {
      //     //       value = value / 1000000000 + "B";
      //     //     }
      //     //     return value;
      //     //   }
      //     // }

      //     axisLabel: {
      //       inside: true,
      //       color: '#fff'
      //     },
      //     axisTick: {
      //       show: false
      //     },
      //     axisLine: {
      //       show: false
      //     },
      //   }],
      //   series: [{ type: 'bar', color: "red", barWidth: '10%'}, { type: 'bar', color: "green", barWidth: '10%'}]
      // }

      this.inputDataOutstandingStatus = {
        tooltip: {
          trigger: 'item',
          formatter: '{c} ({d}%)',
        },
        legend: {
          top: '15%',
          left: 'center'
        },
        series: [
          {
            type: 'pie',
            radius: ['50%', '30%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              show: false,
              position: 'center'
            },
            color: ['red','green'],
            emphasis: {
              label: {
                show: true,
                fontSize: 40,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: this.inputDataOutstandingStatus,
          }
        ]
      }

    } else {
      // this.inputDataOutstandingStatus = {
      //   grid:{left:'10%', width:'67%', height:'62%'},
      //   legend: {},
      //   tooltip: {},
      //   dataset: {
      //     source: this.inputDataOutstandingStatus,
      //   },
      //   xAxis: {
      //     type: 'category', 
      //     axisTick: {
      //       alignWithLabel: true
      //     }
      //   },
      //   yAxis: [{
      //     // type: 'value',
      //     // axisLabel: {
      //     //   formatter: function (value) {
      //     //     if (value >= 0 && value < 1000) {
      //     //       value;
      //     //     }
      //     //     if (value >= 1000 && value < 100000) {
      //     //       value = value / 1000 + "K";
      //     //     }
      //     //     if (value >= 100000 && value < 1000000) {
      //     //       value = value / 1000000 + "M";
      //     //     }
      //     //     if (value >= 1000000) {
      //     //       value = value / 1000000000 + "B";
      //     //     }
      //     //     return value;
      //     //   }
      //     // }
      //     axisLabel: {
      //       inside: true,
      //       color: '#fff'
      //     },
      //     axisTick: {
      //       show: false
      //     },
      //     axisLine: {
      //       show: false
      //     },
      //   }],
      //   series: [{ type: 'bar', color: "green", barWidth: '10%'}, { type: 'bar', color: "red", barWidth: '10%'}]
      // }

      this.inputDataOutstandingStatus = {
        tooltip: {
          trigger: 'item',
          formatter: '{c} ({d}%)',
        },
        legend: {
          top: '15%',
          left: 'center'
        },
        series: [
          {
            type: 'pie',
            radius: ['50%', '30%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              show: false,
              position: 'center'
            },
            color: ['green','red'],
            emphasis: {
              label: {
                show: true,
                fontSize: 40,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: this.inputDataOutstandingStatus,
          }
        ]
      }
    }

  }
}
