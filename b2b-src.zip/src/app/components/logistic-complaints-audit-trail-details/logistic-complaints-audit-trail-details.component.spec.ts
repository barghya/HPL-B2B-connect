import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogisticComplaintsAuditTrailDetailsComponent } from './logistic-complaints-audit-trail-details.component';

describe('LogisticComplaintsAuditTrailDetailsComponent', () => {
  let component: LogisticComplaintsAuditTrailDetailsComponent;
  let fixture: ComponentFixture<LogisticComplaintsAuditTrailDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LogisticComplaintsAuditTrailDetailsComponent]
    });
    fixture = TestBed.createComponent(LogisticComplaintsAuditTrailDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
