import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-logistic-complaints-audit-trail-details',
  templateUrl: './logistic-complaints-audit-trail-details.component.html',
  styleUrls: ['./logistic-complaints-audit-trail-details.component.css']
})
export class LogisticComplaintsAuditTrailDetailsComponent implements OnInit {

  pageNo = 1;

  constructor(private dialogRef: MatDialogRef<LogisticComplaintsAuditTrailDetailsComponent>, @Inject(MAT_DIALOG_DATA) public auditDataForLogisticComplaints: any){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  closePopup(){
    this.dialogRef.close();
  }

}
