import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';

@Component({
  selector: 'app-dispatch-chart-details-popup',
  templateUrl: './dispatch-chart-details-popup.component.html',
  styleUrls: ['./dispatch-chart-details-popup.component.css']
})
export class DispatchChartDetailsPopupComponent implements OnInit, OnDestroy  {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  pageNo = 1;
  tableSearchDispatch: any;
  payloadDownloadDispatchStatusQtyReport: any;
  timePeriod = sessionStorage.getItem('dispatchFilter');
  payloadDownloadDispatchDeliveryTimeReport: any;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');



  constructor(private loaderService: LoaderService,private dispatchService: DispatchManagementService, private dialogRef: MatDialogRef<DispatchChartDetailsPopupComponent>, @Inject(MAT_DIALOG_DATA) public excelChartData: any){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  searchtableDispatch(){

    if (this.excelChartData?.text == 'chart1'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } else {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } else {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } 
        else if(this.region){
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }else {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
  
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart2'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } else {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } else {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        } 
        else if(this.region){
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }else {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchDispatch
          }
        }
  
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
    }

  }

  closePopup() {
    this.dialogRef.close();
  }

}
