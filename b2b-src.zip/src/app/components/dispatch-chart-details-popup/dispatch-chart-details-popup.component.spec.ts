import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispatchChartDetailsPopupComponent } from './dispatch-chart-details-popup.component';

describe('DispatchChartDetailsPopupComponent', () => {
  let component: DispatchChartDetailsPopupComponent;
  let fixture: ComponentFixture<DispatchChartDetailsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DispatchChartDetailsPopupComponent]
    });
    fixture = TestBed.createComponent(DispatchChartDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
