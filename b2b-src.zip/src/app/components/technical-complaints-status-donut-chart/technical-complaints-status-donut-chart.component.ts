import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-technical-complaints-status-donut-chart',
  templateUrl: './technical-complaints-status-donut-chart.component.html',
  styleUrls: ['./technical-complaints-status-donut-chart.component.css']
})
export class TechnicalComplaintsStatusDonutChartComponent implements OnInit {

  @Input() inputTechnicalComplaintsStatus: any;

  constructor() {}

  ngOnInit(): void {
    this.praparedTechnicalComplaintsData();
  }

  praparedTechnicalComplaintsData(){
    this.inputTechnicalComplaintsStatus = {
      grid:{left:'20%', width:'67%', height:'80%', top:'10%'},
      tooltip: {
        trigger: 'item',
        formatter: 'Count {c} ({d}%)',
      },
      legend: {
        top: '15%',
        left: 'center'
      },
      series: [
        {
          type: 'pie',
          radius: ['50%', '30%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          color: ['#754827','#FFD2D2'],
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: this.inputTechnicalComplaintsStatus,
        }
      ]
    }
  }


}
