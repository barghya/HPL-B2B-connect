import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalComplaintsStatusDonutChartComponent } from './technical-complaints-status-donut-chart.component';

describe('TechnicalComplaintsStatusDonutChartComponent', () => {
  let component: TechnicalComplaintsStatusDonutChartComponent;
  let fixture: ComponentFixture<TechnicalComplaintsStatusDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TechnicalComplaintsStatusDonutChartComponent]
    });
    fixture = TestBed.createComponent(TechnicalComplaintsStatusDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
