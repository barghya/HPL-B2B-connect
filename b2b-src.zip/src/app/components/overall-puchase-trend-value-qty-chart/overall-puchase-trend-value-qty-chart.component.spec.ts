import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverallPuchaseTrendValueQtyChartComponent } from './overall-puchase-trend-value-qty-chart.component';

describe('OverallPuchaseTrendValueQtyChartComponent', () => {
  let component: OverallPuchaseTrendValueQtyChartComponent;
  let fixture: ComponentFixture<OverallPuchaseTrendValueQtyChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OverallPuchaseTrendValueQtyChartComponent]
    });
    fixture = TestBed.createComponent(OverallPuchaseTrendValueQtyChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
