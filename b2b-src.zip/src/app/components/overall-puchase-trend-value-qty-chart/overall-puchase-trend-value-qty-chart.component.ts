import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-overall-puchase-trend-value-qty-chart',
  templateUrl: './overall-puchase-trend-value-qty-chart.component.html',
  styleUrls: ['./overall-puchase-trend-value-qty-chart.component.css']
})
export class OverallPuchaseTrendValueQtyChartComponent implements OnInit {

  @Input() inputDataOverallPurchaseTrendValueQty: any;

  constructor() {}

  ngOnInit(): void {
    this.praparedOverallPurchaseTrendValueQtyChartData();
  }

  praparedOverallPurchaseTrendValueQtyChartData(){

    this.inputDataOverallPurchaseTrendValueQty = {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999'
          }
        }
      },
      xAxis: [
        {
          type: 'category',
          data: this.inputDataOverallPurchaseTrendValueQty?.chartXaxisData?.data,
          axisPointer: {
            type: 'shadow'
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: 'Value (₹)',
          // interval: 10,
        },
        {
          type: 'value',
          name: 'Qty (MT)',
          // interval: 5,
        }
      ],
      series: [
        {
          name: 'Value',
          type: 'bar',
          color: ['#BB8C6B'],
          barWidth: '20%',
          tooltip: {
            valueFormatter: function (value) {
              return value;
            }
          },
          data: this.inputDataOverallPurchaseTrendValueQty?.barChartSeriesData?.data,
        },
        {
          name: 'Qty',
          type: 'line',
          color: ['#EE756D'],
          yAxisIndex: 1,
          smooth: true,
          tooltip: {
            valueFormatter: function (value) {
              return value;
            }
          },
          triggerLineEvent: true,
          data: this.inputDataOverallPurchaseTrendValueQty?.lineChartSeriesData?.data,
        }
      ]
    };
    
  }

  

}
