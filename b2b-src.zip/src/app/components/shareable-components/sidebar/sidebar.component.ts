import { Component, ElementRef, OnDestroy, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MenuService } from 'src/app/services/menu/menu.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonApiService } from 'src/app/services/common/common-api.service';
import { Observable, ReplaySubject, map, startWith, takeUntil } from 'rxjs';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit, OnDestroy {

  @ViewChild('toggleButton') toggleButton: ElementRef;
  @ViewChild('menu') menu: ElementRef;

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  sidenavWidth: any;
  menuList: any;
  selected: any = {};
  user = JSON.parse(sessionStorage.getItem('user'));
  menuItem: any;
  inputCode: any;
  inputCodeGCC: any;
  custCsaName = new FormControl('');
  viewAs: any;
  userRegion: any;
  isViewAsPanel: boolean = true;
  custName: any;
  isActiveCustNamePanel: boolean = false;
  showExtraClass = true;
  isNotificationMenuOpen: boolean = false;
  custCSAList: Observable<any[]>;
  custCSAArr: any[] = [];
  selectedEvt: any;
  custCsaCode: any;
  getCustCSACode: any;
  custGccArr: any [] = [];



  constructor(private renderer: Renderer2, private common: CommonApiService, private location: Location, private router: Router, private menuService: MenuService, private loaderService: LoaderService) {

    // this.renderer.listen('window', 'click', (e: Event) => {
    //   if (e.target != this.toggleButton.nativeElement) {
    //     this.isNotificationMenuOpen = false;
    //   }
    //   else if (this.menu && e.target != this.menu.nativeElement) {
    //     this.isNotificationMenuOpen = true;
    //   }
    // });

  }


  ngOnInit(): void {
    this.sidenavWidth = 3;

    if (this.location.path() === '/home') {
      this.selected['main'] = (this.selected['main'] === 'My Page' ? null : 'My Page');
    }

    if (this.location.path() === '/customerOnboarding') {
      this.selected['main'] = (this.selected['main'] === 'Customer Onboarding' ? null : 'Customer Onboarding');
    }

    if (this.location.path() === '/contributionCalculator') {
      this.selected['main'] = (this.selected['main'] === 'Calculator' ? null : 'Calculator');
    }

    if (this.location.path() === '/releaseOrder') {
      this.selected['main'] = (this.selected['main'] === 'Release Blocked Orders' ? null : 'Release Blocked Orders');
    }

    if (this.location.path() === '/reports') {
      this.selected['main'] = (this.selected['main'] === 'Reports' ? null : 'Reports');
    }

    if (this.location.path() === '/customerAmendment' && this.user?.userTypeId == 1) {
      this.selected['main'] = (this.selected['main'] === 'Customer Amendment' ? null : 'Customer Amendment');
    }

    if (this.location.path() === '/amendmentReq') {
      this.selected['main'] = this.user?.userTypeId == 2 ? (this.selected['main'] === 'Customer Amendment' ? null : 'Customer Amendment') : (this.selected['main'] === 'My Amendments' ? null : 'My Amendments');
    }

    if (this.location.path() === '/placeOrder') {
      this.selected['main'] = (this.selected['main'] === 'Place Order' ? null : 'Place Order');
    }

    if (this.location.path() === '/salesOrderManagement') {
      this.selected['main'] = (this.selected['main'] === 'Dashboard' ? null : 'Dashboard');
    }

    if (this.location.path() === '/purchaseManagement') {
      this.selected['main'] = (this.selected['main'] === 'Dashboard' ? null : 'Dashboard');
    }

    if (this.location.path() === '/accountManagement') {
      this.selected['main'] = (this.selected['main'] === 'Dashboard' ? null : 'Dashboard');
    }

    if (this.location.path() === '/dispatchManagement') {
      this.selected['main'] = (this.selected['main'] === 'Dashboard' ? null : 'Dashboard');
    }

    if (this.location.path() === '/complaintsManagement') {
      this.selected['main'] = (this.selected['main'] === 'Complaints' ? null : 'Complaints');
    }

    if (this.location.path() === '/userDataManagement') {
      this.selected['main'] = (this.selected['main'] === 'Master Data Management' ? null : 'Master Data Management');
    }

    if (this.location.path() === '/uploadCCS') {
      this.selected['main'] = (this.selected['main'] === 'Master Data Management' ? null : 'Master Data Management');
    }

    if (this.location.path() === '/uploadContribution') {
      this.selected['main'] = (this.selected['main'] === 'Master Data Management' ? null : 'Master Data Management');
    }

    if (this.user) {
      this.populateMenuData();
    }
    this.menuNameChange();
    if (sessionStorage.getItem('filterCode')) {
      this.inputCode = sessionStorage.getItem('filterCode');
    }
    if (sessionStorage.getItem('filterCodeGCC') && this.user?.userTypeId != 3) {
      this.inputCode = sessionStorage.getItem('filterCodeGCC');
    }
    if (sessionStorage.getItem('filterCodeGCC')) {
      this.inputCodeGCC = sessionStorage.getItem('filterCodeGCC');
    }
    if (sessionStorage.getItem('viewAs')) {
      this.viewAs = sessionStorage.getItem('viewAs');
    }
    if (sessionStorage.getItem('codeName')) {
      this.custName = sessionStorage.getItem('codeName');
      this.isActiveCustNamePanel = true;
    }
    if (sessionStorage.getItem('region')) {
      this.userRegion = sessionStorage.getItem('region');
    }

    this.onloadViewAs();

    if(this.user?.userTypeId == 3){
      this.getCustGcc();
    }
    
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  private filterCustCSA(value: string): string[] {
    const filterValueCustCSA = value.toLowerCase();
    return this.custCSAArr.filter(option => option?.customerName?.toLowerCase().includes(filterValueCustCSA));
  }


  getCustCSADetails(evt) {
    sessionStorage.setItem('selectedViewFor', evt?.value);
  }

  getCustGcc(){
    let payload = {
      userId: this.user?.userId,
      loginFromApp: false,
      code: "",
    }

    // this.loaderService.show();
    this.common.viewAsCustCsa(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      // this.loaderService.hide();

      if (data && data?.getCustomerList) {
        this.custGccArr = data?.getCustomerList;
      }
    })

  }

  getCustCSA() {

    if(sessionStorage.getItem('selectedViewFor') == 'Self'){
      sessionStorage.removeItem('sliderGcc');
    }
    
    let payload = {
      viewFor: sessionStorage.getItem('selectedViewFor'),
      userId: this.user?.userId,
      loginFromApp: false,
      code: this.custCsaName.value
    }

    if (this.custCsaName.value) {
      if (this.custCsaName.value.length > 4) {
        // this.loaderService.show();
        this.common.viewAsCustCsa(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          // this.loaderService.hide();

          if (data && data?.getCustomerList) {
            data?.getCustomerList.forEach(ele => {
              if (this.custCsaName.value == ele?.customerName) {
                this.custCsaCode = ele?.customerCode;
              }
            })

            this.custCSAArr = data?.getCustomerList;
            this.custCSAList = this.custCsaName.valueChanges.pipe(
              startWith(''),
              map(value => this.filterCustCSA(value || '')),
            )
          }
        })
      } else {
        this.custCSAArr = [];
      }
    }


  }


  menuNameChange() {

    if (this.location.path() === '/home') {
      this.menuItem = Constants.normalText.myPage;
    }
    if (this.location.path() === '/dispatchManagement') {
      this.menuItem = Constants.normalText.dispatchMgmnt;
    }
    if (this.location.path() === '/complaintsManagement') {
      this.menuItem = Constants.normalText.comReg;
    }
    if (this.location.path() === '/salesOrderManagement') {
      this.menuItem = Constants.normalText.salesOrderMgmnt;
    }
    if (this.location.path() === '/purchaseManagement') {
      this.menuItem = Constants.normalText.purchaseMgmnt;
    }
    if (this.location.path() === '/accountManagement') {
      this.menuItem = Constants.normalText.accountMgmnt;
    }
    if (this.location.path() === '/uploadCCS') {
      this.menuItem = Constants.normalText.uploadCcs;
    }
    if (this.location.path() === '/uploadContribution') {
      this.menuItem = Constants.normalText.uploadContribution;
    }
    if (this.location.path() === '/customerOnboarding' && this.user?.userTypeId == 3) {
      this.menuItem = Constants.normalText.myProfile;
    }
    if (this.location.path() === '/customerAmendment') {
      this.menuItem = Constants.normalText.customerAmendment;
    }
    if (this.location.path() === '/contributionCalculator') {
      this.menuItem = Constants.normalText.projectedContributionCalculator;
    }
    if (this.location.path() === '/userDataManagement') {
      this.menuItem = Constants.normalText.userDataManagement;
    }
    if (this.location.path() === '/uploadCCS') {
      this.menuItem = Constants.normalText.uploadCcs;
    }
    if (this.location.path() === '/uploadContribution') {
      this.menuItem = Constants.normalText.uploadContribution;
    }
    if (this.location.path() === '/reports') {
      this.menuItem = Constants.normalText.reports;
    }
    if (this.location.path() === '/placeOrder') {
      this.menuItem = Constants.normalText.placeOrder;
    }
    if (this.location.path() === '/amendmentReq' && this.user?.userTypeId == 3) {
      this.menuItem = Constants.normalText.myAmendments;
    }
    if (this.location.path() === '/amendmentReq' && this.user?.userTypeId == 2) {
      this.menuItem = Constants.normalText.customerAmendment;
    }
    if (this.location.path() === '/releaseOrder') {
      this.menuItem = Constants.normalText.releaseOrder;
    }

  }

  viewAsPanel() {
    if (this.menuItem === 'Customer Onboarding' || this.menuItem === 'Customer Amendment' || this.menuItem === 'Dashboard' || this.menuItem === 'Upload CCS' || this.menuItem === 'Master Data Management' || this.menuItem === 'User Data Management' || this.menuItem === 'Reports' || this.menuItem === 'Upload Contribution' || this.menuItem === 'Calculator' || this.menuItem === 'Place Order' || this.menuItem === 'My Amendments') {
      this.isViewAsPanel = false;
    } else {
      this.isViewAsPanel = true;
    }
  }

  onloadViewAs() {
    if (this.location.path() === '/customerOnboarding' || this.location.path() === '/uploadCCS' || this.location.path() === '/userDataManagement' || this.location.path() === '/reports' || this.location.path() === '/uploadContribution' || this.location.path() === '/contributionCalculator' || this.location.path() === '/placeOrder' || this.location.path() === '/amendmentReq') {
      this.isViewAsPanel = false;
    } else {
      this.isViewAsPanel = true;
    }
  }

  populateMenuData() {
    let payload = {
      loggedinUserId: this.user.userId,
      loginFromApp: false
    }

    // this.loaderService.show();
    this.menuService.populateMenu(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      // this.loaderService.hide();
      if (data) {
        this.menuList = data?.entries;
      }
    })
  }

  select(type?, item?, $event?) {
    this.selected[type] = (this.selected[type] === item ? null : item);
    // $event ? $event.stopPropagation() : null;
    this.navigateToComponent(item);
    if (this.user?.userRole[0]?.id != 5 && this.user?.userRole[0]?.id != 6 && item != 'Dashboard' && item != 'Master Data Management') {
      this.menuItem = item;
    }

    this.viewAsPanel();
    sessionStorage.removeItem('dispatchFilter');
    sessionStorage.removeItem('complaintFilter');
    sessionStorage.removeItem('salesTimeinterval');
    sessionStorage.removeItem('tabIndex');
    sessionStorage.removeItem('sliderGcc');
  }

  navigateToComponent(data) {
    if (data == 'My Page') {
      this.router.navigate(['/home']).then((succeeded) => {
        window.location.reload();
      });
    }

    if (data == 'Customer Onboarding') {
      this.router.navigate(['/customerOnboarding']).then((succeeded) => {
        window.location.reload();
      });
    }

    // if (data == 'Customer Amendment') {
    //   this.router.navigate(['/customerOnboarding']);
    // }

    if (data == 'Customer Amendment' && this.user?.userTypeId == 1) {
      this.router.navigate(['/customerAmendment']).then((succeeded) => {
        window.location.reload();
      });
    }

    // if (data == 'Customer Amendment' && this.user?.userTypeId == 2) {
    //   this.router.navigate(['/amendmentReq']);
    // }

    if (data == 'My Amendments' && this.user?.userTypeId == 3) {
      this.router.navigate(['/amendmentReq']).then((succeeded) => {
        window.location.reload();
      });
    }


    if (data == 'Customer Amendment' && this.user?.userTypeId == 2) {
      this.router.navigate(['/amendmentReq']).then((succeeded) => {
        window.location.reload();
      });
    }

    if (data == 'Sales Order Management') {
      this.router.navigate(['/salesOrderManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'Account Management') {
      this.router.navigate(['/accountManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'Dispatch Management') {
      this.router.navigate(['/dispatchManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'Calculator') {
      this.router.navigate(['/contributionCalculator']).then((succeeded) => {
        window.location.reload();
      });
    }

    if (data == 'Place Order' && this.user?.userRole[0]?.id == 7) {
      this.router.navigate(['/placeOrder']).then((succeeded) => {
        window.location.reload();
      });
    }

    if (data == 'Place Order' && this.user?.userRole[0]?.id == 5 || data == 'Place Order' && this.user?.userRole[0]?.id == 6) {
      window.open(Constants.url.sapUrl, "_blank");
    }

    if (data == 'Release Blocked Orders') {
      this.router.navigate(['/releaseOrder']).then((succeeded) => {
        window.location.reload();
      });
    }

    if (data == 'Dispatches') {
      this.router.navigate(['/dispatchManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'Complaints') {
      this.router.navigate(['/complaintsManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'My Purchase') {
      this.router.navigate(['/purchaseManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'My Account') {
      this.router.navigate(['/accountManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'Upload CCS') {
      this.router.navigate(['/uploadCCS']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'User Data Management') {
      this.router.navigate(['/userDataManagement']).then((succeeded) => {
        window.location.reload()
      });
    }

    if (data == 'Reports') {
      this.router.navigate(['/reports']).then((succeeded) => {
        window.location.reload();
      });
    }

    if (data == 'Upload Contribution') {
      this.router.navigate(['/uploadContribution']).then((succeeded) => {
        window.location.reload()
      });
    }
    // if(data == 'Customer Amendment' && this.user?.userTypeId == 1){
    //   this.router.navigate(['/customerAmendment']);
    // }

  }

  isActive(type, item) {
    return this.selected[type] === item;
  }

  filterDataWithInput(evt, item) {

    sessionStorage.removeItem('callFromTileTotalPurchase');
    sessionStorage.removeItem('callFromTileConfirmPurchase');
    sessionStorage.removeItem('callFromTilePendingPurchase');
    sessionStorage.removeItem('callFromTileBlockedPurchase');

    sessionStorage.removeItem('callFromTileTotalSales');
    sessionStorage.removeItem('callFromTileTotalConfirmSales');
    sessionStorage.removeItem('callFromTileTotalPendingSales');
    sessionStorage.removeItem('callFromTileTotalBlockedSales');

    sessionStorage.removeItem('callFromTileTotalSalesAcc');
    sessionStorage.removeItem('callFromTileTotalPurAcc');
    sessionStorage.removeItem('callFromTileAccLedger');
    sessionStorage.removeItem('callFromTileAccPendingInvoice');
    sessionStorage.removeItem('callFromTileAccCrDr');

    sessionStorage.removeItem('callFromTileTotalDispatch');
    sessionStorage.removeItem('callFromTilePendingDispatch');
    sessionStorage.removeItem('callFromTileInTransitOrder');
    sessionStorage.removeItem('callFromTileTotalPodAck');
    sessionStorage.removeItem('callFromTilePodAck');

    sessionStorage.removeItem('callFromTileTechnicalCom');
    sessionStorage.removeItem('callFromTileOpenTechnicalCom');
    sessionStorage.removeItem('callFromTileLogisticalCom');
    sessionStorage.removeItem('callFromTileOpenLogisticalCom');

    this.getCustCSACode = item?.customerCode.encrypt();
    // if(!this.viewAs){
    //   Swal.fire(alertPopup.viewAs);
    // }
    // else if(!this.inputCode){
    //   Swal.fire(alertPopup.filterDataCode);
    // }else{

    if (sessionStorage.getItem('selectedViewFor') == 'CSA' && item?.customerCode) {
      sessionStorage.removeItem('sliderGcc');
    }

    
    if(sessionStorage.getItem('selectedViewFor') == 'Customer' || sessionStorage.getItem('selectedViewFor') == 'CSA'){
      sessionStorage.removeItem('filterCodeGCC');
      let payload = {
        code: item?.customerCode.encrypt(),
        userId: this.user?.userId,
        loginFromApp: false
      }
      // this.loaderService.show();
      this.common.viewAsValidation(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        // this.loaderService.hide();
  
        if (data && data?.status == 1) {
          sessionStorage.setItem('viewAs', this.viewAs);
          sessionStorage.setItem('filterCode', item?.customerCode);
          sessionStorage.setItem('gcc', JSON.stringify(data));
          sessionStorage.removeItem('region');
          this.getCustName();
        }
        // else {
        //   Swal.fire({
        //     position: 'center',
        //     icon: 'warning',
        //     title: "Unauthorized Access",
        //     showCancelButton: false,
        //     allowEnterKey: false,
        //     allowOutsideClick: false,
        //   })
        // }
      })
      // }
    }else{
      sessionStorage.setItem('viewAs', 'GCC');
      sessionStorage.removeItem('filterCode');
      sessionStorage.setItem('filterCodeGCC', item?.customerCode);
      this.getCustName();
    }
 
  }

  getCustName() {
    let payload = {
      customerCode: this.getCustCSACode,
      loginFromApp: false
    }

    // this.loaderService.show();
    this.menuService.custName(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      // this.loaderService.hide();
      if (data && data?.getCustomerName?.length != 0) {
        this.custName = data?.getCustomerName[0]?.name;
        sessionStorage.setItem('codeName', data?.getCustomerName[0]?.name);
        this.isActiveCustNamePanel = true;
        window.location.reload();
      }
    })
  }


  gccFilterDataCustomer(evt){
    
    sessionStorage.removeItem('callFromTileTotalPurchase');
    sessionStorage.removeItem('callFromTileConfirmPurchase');
    sessionStorage.removeItem('callFromTilePendingPurchase');
    sessionStorage.removeItem('callFromTileBlockedPurchase');

    sessionStorage.removeItem('callFromTileTotalSales');
    sessionStorage.removeItem('callFromTileTotalConfirmSales');
    sessionStorage.removeItem('callFromTileTotalPendingSales');
    sessionStorage.removeItem('callFromTileTotalBlockedSales');

    sessionStorage.removeItem('callFromTileTotalSalesAcc');
    sessionStorage.removeItem('callFromTileTotalPurAcc');
    sessionStorage.removeItem('callFromTileAccLedger');
    sessionStorage.removeItem('callFromTileAccPendingInvoice');
    sessionStorage.removeItem('callFromTileAccCrDr');

    sessionStorage.removeItem('callFromTileTotalDispatch');
    sessionStorage.removeItem('callFromTilePendingDispatch');
    sessionStorage.removeItem('callFromTileInTransitOrder');
    sessionStorage.removeItem('callFromTileTotalPodAck');
    sessionStorage.removeItem('callFromTilePodAck');

    sessionStorage.removeItem('callFromTileTechnicalCom');
    sessionStorage.removeItem('callFromTileOpenTechnicalCom');
    sessionStorage.removeItem('callFromTileLogisticalCom');
    sessionStorage.removeItem('callFromTileOpenLogisticalCom');


    if (evt == "Self") {
      sessionStorage.removeItem('viewAs');
      sessionStorage.removeItem('filterCode');
      sessionStorage.removeItem('codeName');
      sessionStorage.removeItem('region');
      sessionStorage.removeItem('gcc');
      sessionStorage.removeItem('filterCodeGCC');
      window.location.reload();
    } else {
      sessionStorage.setItem('viewAs', 'GCC');
      sessionStorage.setItem('filterCodeGCC', this.inputCodeGCC);

      let payload = {
        customerCode: evt?.encrypt(),
        loginFromApp: false
      }
  
      // this.loaderService.show();
      this.menuService.custName(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        // this.loaderService.hide();
        if (data && data?.getCustomerName?.length != 0) {
          this.custName = data?.getCustomerName[0]?.name;
          sessionStorage.setItem('codeName', data?.getCustomerName[0]?.name);
          this.isActiveCustNamePanel = true;
          window.location.reload();
        }
      })
     
    }
  }
  
  rsetFilterData(evt) {

    sessionStorage.removeItem('callFromTileTotalPurchase');
    sessionStorage.removeItem('callFromTileConfirmPurchase');
    sessionStorage.removeItem('callFromTilePendingPurchase');
    sessionStorage.removeItem('callFromTileBlockedPurchase');

    sessionStorage.removeItem('callFromTileTotalSales');
    sessionStorage.removeItem('callFromTileTotalConfirmSales');
    sessionStorage.removeItem('callFromTileTotalPendingSales');
    sessionStorage.removeItem('callFromTileTotalBlockedSales');

    sessionStorage.removeItem('callFromTileTotalSalesAcc');
    sessionStorage.removeItem('callFromTileTotalPurAcc');
    sessionStorage.removeItem('callFromTileAccLedger');
    sessionStorage.removeItem('callFromTileAccPendingInvoice');
    sessionStorage.removeItem('callFromTileAccCrDr');

    sessionStorage.removeItem('callFromTileTotalDispatch');
    sessionStorage.removeItem('callFromTilePendingDispatch');
    sessionStorage.removeItem('callFromTileInTransitOrder');
    sessionStorage.removeItem('callFromTileTotalPodAck');
    sessionStorage.removeItem('callFromTilePodAck');

    sessionStorage.removeItem('callFromTileTechnicalCom');
    sessionStorage.removeItem('callFromTileOpenTechnicalCom');
    sessionStorage.removeItem('callFromTileLogisticalCom');
    sessionStorage.removeItem('callFromTileOpenLogisticalCom');
    
    if (evt?.source?.value == "Self") {
      sessionStorage.removeItem('viewAs');
      sessionStorage.removeItem('filterCode');
      sessionStorage.removeItem('codeName');
      sessionStorage.removeItem('region');
      sessionStorage.removeItem('gcc');
      sessionStorage.removeItem('filterCodeGCC');
      window.location.reload();
    }
  }

  regionFilterData(evt) {

    sessionStorage.removeItem('callFromTileTotalPurchase');
    sessionStorage.removeItem('callFromTileConfirmPurchase');
    sessionStorage.removeItem('callFromTilePendingPurchase');
    sessionStorage.removeItem('callFromTileBlockedPurchase');

    sessionStorage.removeItem('callFromTileTotalSales');
    sessionStorage.removeItem('callFromTileTotalConfirmSales');
    sessionStorage.removeItem('callFromTileTotalPendingSales');
    sessionStorage.removeItem('callFromTileTotalBlockedSales');

    sessionStorage.removeItem('callFromTileTotalSalesAcc');
    sessionStorage.removeItem('callFromTileTotalPurAcc');
    sessionStorage.removeItem('callFromTileAccLedger');
    sessionStorage.removeItem('callFromTileAccPendingInvoice');
    sessionStorage.removeItem('callFromTileAccCrDr');

    sessionStorage.removeItem('callFromTileTotalDispatch');
    sessionStorage.removeItem('callFromTilePendingDispatch');
    sessionStorage.removeItem('callFromTileInTransitOrder');
    sessionStorage.removeItem('callFromTileTotalPodAck');
    sessionStorage.removeItem('callFromTilePodAck');

    sessionStorage.removeItem('callFromTileTechnicalCom');
    sessionStorage.removeItem('callFromTileOpenTechnicalCom');
    sessionStorage.removeItem('callFromTileLogisticalCom');
    sessionStorage.removeItem('callFromTileOpenLogisticalCom');


    if (evt?.source?.value == "All") {
      sessionStorage.removeItem('region');
      sessionStorage.removeItem('viewAs');
      sessionStorage.removeItem('filterCode');
      sessionStorage.removeItem('filterCodeGCC');
      sessionStorage.removeItem('codeName');
      sessionStorage.removeItem('gcc');
      window.location.reload();
    } else {
      sessionStorage.setItem('region', this.userRegion);
      sessionStorage.removeItem('viewAs');
      sessionStorage.removeItem('filterCode');
      sessionStorage.removeItem('filterCodeGCC');
      sessionStorage.removeItem('codeName');
      sessionStorage.removeItem('gcc');
      window.location.reload();
    }
  }


  logOut() {
    this.router.navigate(['/login']).then((succeeded) => {
      window.location.reload()
    });
    sessionStorage.clear();
    // this.SessionTimeoutService.counter = 0;
  }


  openNotificationsPopup() {
    this.isNotificationMenuOpen = !this.isNotificationMenuOpen;
  }

}