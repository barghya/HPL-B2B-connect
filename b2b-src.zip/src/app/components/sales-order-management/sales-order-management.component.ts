import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { TopCustomerExpandPopupComponent } from '../top-customer-expand-popup/top-customer-expand-popup.component';
import { SalesOrderChartDetailsPopupComponent } from '../sales-order-chart-details-popup/sales-order-chart-details-popup.component';
import { Router } from '@angular/router';
import { ViewHistoricalPopupComponent } from '../view-historical-popup/view-historical-popup.component';
import { ReplaySubject, takeUntil } from 'rxjs';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { DispatchDetailsPopupComponent } from '../dispatch-details-popup/dispatch-details-popup.component';

@Component({
  selector: 'app-sales-order-management',
  templateUrl: './sales-order-management.component.html',
  styleUrls: ['./sales-order-management.component.css']
})
export class SalesOrderManagementComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  gccValue = JSON.parse(sessionStorage.getItem('gcc'));
  selectedIndex: number;
  pageNo = 1;
  payloadPurchaseOrderManagementData: any;
  purchaseManagementCountDetails: any;
  purchaseManagementBarLineChartDetails: any;
  payloadLineBarChartData: any;
  payloadDownloadOverallPurchaseTrendValueQtyReport: any;
  topCustomersDetails: any[] = [];
  allSalesDetailsData: any;
  payloadAllSalesDetails: any;
  tabLabels = Constants.normalText.salesDetails;
  isTotalSalesTable: boolean = false;
  isConfirmOrderTable: boolean = false;
  isPendingOrderTable: boolean = false;
  isBlockedOrderTable: boolean = false;
  payloadDownloadIndividualTile: any;
  salesSearch: any;
  isCheckedSliderGcc: any;
  isCheckedSliderSales: any;
  isCheckedZDDPSliderSales: any;
  isCheckedZDOPSliderSales: any;
  gccChart: boolean = false;
  gccChartData: any;
  timePeriod = 0;
  // timePeriodList : any [] =[];
  timePeriodList = [    
    {id:1, label:'MTD', value: 0},
    {id:2, label:'YTD', value: 1},
    {id: 3, label: 'Prv Month', value: 2 },
  ]
  customerType:any = 'Customer';
  getTotalSalesDetails: any;
  getConfirmedSalesDetails: any;
  getPendingSalesDetails: any;
  getBlockedSalesDetails: any;
  gccSlider: any;
  userRoleId: any [] = [];
  payloadPurchaseTarget: any;
  currentMonth: any;
  currentFinancialYear: any;
  salesTargetRemainingDetails: any;
  payloadActualTargetChart: any;
  purchaseManagementActualTargetChartDetails: any;
  isPanelActive: boolean = true;
  payloadforCustomerView: any;
  isGradeEnabled: boolean = true;
  isZDDPEnabled: boolean = false;
  isZDOPEnabled: boolean = false;
  allDispatchDetailsData: any [] = [];
  payloadAllDispatchDetails: any;
  isZCDPZCOPTable: boolean = false;
  isColumnActive: boolean = false;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');
  


  constructor(private dispatchService: DispatchManagementService, private router: Router,private dialog: MatDialog, private loaderService: LoaderService, private purchaseService: PurchaseManagementService) { 
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalSales')) {
      this.getTotalSalesDetails = this.router.getCurrentNavigation().extras.state['dataTotalSales'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalConfirmSales')) {
      this.getConfirmedSalesDetails = this.router.getCurrentNavigation().extras.state['dataConfirmedSales'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalPendingSales')) {
      this.getPendingSalesDetails = this.router.getCurrentNavigation().extras.state['dataPendingSales'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalBlockedSales')) {
      this.getBlockedSalesDetails = this.router.getCurrentNavigation().extras.state['dataBlockedSales'];
    }
  }


  ngOnInit(): void {
    if(this.viewAsGCC){
      this.isCheckedSliderGcc = false;
      sessionStorage.removeItem('sliderGcc');
      sessionStorage.removeItem('gcc');
    }

    if(sessionStorage.getItem('sliderGcc') || this.viewAs == 'GCC'){
      
      this.isCheckedSliderGcc = 'on';
      this.gccSlider = sessionStorage.getItem('sliderGcc');
      this.gccChart = true;
      if(this.viewAs != 'GCC'){
        let payload = {
          gccDate: this.gccValue?.gccBillingDate,
          gccCode: this.gccValue?.gccCode.decrypt(),
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data != null){
            this.gccChartData = data;
          }
        })
      }else{
        let payload = {
          gccDate: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data != null){
            this.gccChartData = data;
          }
        })
      }
    

    }else{
      this.gccChart = false;
    }

    gridUtilObj.resizeGrid();
    this.getPurchaseOrderManagementData();
    this.getChartData();
    this.getTopCustomersData();
    this.fetchTableDetails();
    this.getCurrentMonth();
    this.getCurrentFinancialYear();
    this.getPurchaseTarget();

    if(this.getTotalSalesDetails == undefined && this.getConfirmedSalesDetails == undefined && this.getPendingSalesDetails == undefined && this.getBlockedSalesDetails == undefined){
      this.allSalesDetails();
    }

    // this.filterValidation();

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  fetchTableDetails(){
    if(this.getTotalSalesDetails?.state?.callFrom == "Total Sales"){
     this.totalSalesValue();
    }

    if(this.getConfirmedSalesDetails?.state?.callFrom == "Confirmed Sales"){
     this.confirmedSalesOrder();
    }

    if(this.getPendingSalesDetails?.state?.callFrom == "Pending Sales"){
     this.pendingSalesOrder();
    }

    if(this.getBlockedSalesDetails?.state?.callFrom == "Blocked Sales"){
     this.blockedSalesOrder();
    }

  }

  informationChange(event: any) {
    this.isCheckedSliderSales = false;
    this.isCheckedZDDPSliderSales = false;
    this.isCheckedZDOPSliderSales = false;
    this.isZCDPZCOPTable = false;
    this.selectedIndex = event;
    this.pageNo = 1;
  }

  getPurchaseOrderManagementData() {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
  
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } 
        else if(this.region){
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
    }else{
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } 
        else if(this.region){
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }  
    }
   
  }

  getChartDataForActualTarget(){
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }else{
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }    
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }else{
          this.payloadActualTargetChart = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }
        else if(this.region){
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }else{
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
    }else{
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }else{
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }    
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else{
          this.payloadActualTargetChart = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if(this.region){
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else{
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
    }
   
  }

  getChartData() {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }else{
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }else{
          this.payloadLineBarChartData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        
        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if(this.region){
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }else{
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        
        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
    }else{
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else{
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
      
        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else{
          this.payloadLineBarChartData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if(this.region){
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else{
          this.payloadLineBarChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
    }
 
  }


  getTopCustomersData() {
    this.topCustomersDetails = [];
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadLineBarChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLineBarChartData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.topCustomersSales(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getTopCustomers != null) {
          this.topCustomersDetails = data?.getTopCustomers;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadLineBarChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLineBarChartData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.topCustomersSales(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getTopCustomers != null) {
          this.topCustomersDetails = data?.getTopCustomers;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadLineBarChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadLineBarChartData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadLineBarChartData = {
          customerCodes: [],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [this.region],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadLineBarChartData = {
          customerCodes: [],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user.userRegion,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      this.loaderService.show();
      this.purchaseService.topCustomersSales(this.payloadLineBarChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getTopCustomers != null) {
          this.topCustomersDetails = data?.getTopCustomers;
        }
      })
    }

  }


  allSalesDetailsForIndividualTile(codeData, slidercode?) {
    this.allSalesDetailsData = null;
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            slidercode: slidercode,
            gccCode: this.gccValue?.gccCode.decrypt(),
            sliderEnabled : true,
            loginFromApp: false
          }
        } else {
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
            this.allSalesDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        } else {
          this.payloadAllSalesDetails = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.allSalesDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        } else if(this.region){
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [this.region],
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        }else {
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user.userRegion,
            text: this.salesSearch,
            gccCode: this.gccValue?.gccCode.decrypt(),
            slidercode: slidercode,
            sliderEnabled : true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.allSalesDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
    }
    
    else{
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            slidercode: slidercode,
            text: this.salesSearch,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
            this.allSalesDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadAllSalesDetails = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.allSalesDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else if(this.region){
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [this.region],
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else {
          this.payloadAllSalesDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user.userRegion,
            text: this.salesSearch,
            slidercode: slidercode,
            sliderEnabled : true,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.allSalesDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
    }
    

  }

  allSalesDetails() {
    this.isTotalSalesTable = true;
    let code = Constants.normalText.tp;
    this.allSalesDetailsForIndividualTile(code);
  }

  totalSalesValue() {
    this.allSalesDetailsData = null;
    this.salesSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.salesDetails;
    let code = Constants.normalText.tp;
    this.allSalesDetailsForIndividualTile(code);
    this.isTotalSalesTable = true;
    this.isConfirmOrderTable = false;
    this.isBlockedOrderTable = false;
    this.isPendingOrderTable = false;
    this.isGradeEnabled = true;
    this.isZDDPEnabled = false;
    this.isZDOPEnabled = false;
  }

  confirmedSalesOrder() {
    this.allSalesDetailsData = null;
    this.salesSearch = null;
    this.selectedIndex = 1;
    let code = Constants.normalText.co;
    let slidercode = Constants.normalText.zddp;
    if(this.viewAs != 'Customer' && this.viewAs != 'GCC'){
      this.tabLabels = Constants.normalText.confirmOrderDetails;
      this.allSalesDetailsForIndividualTile(code,slidercode);
    }else{
      this.tabLabels = Constants.normalText.confirmOrderDetailsPurchase;
      this.allSalesDetailsForIndividualTile(code);
    }
    this.isConfirmOrderTable = true;
    this.isTotalSalesTable = false;
    this.isBlockedOrderTable = false;
    this.isPendingOrderTable = false;
    this.isGradeEnabled = false;
    this.isZDDPEnabled = true;
    this.isZDOPEnabled = false;
    this.isColumnActive = true;
  }

  pendingSalesOrder() {
    this.allSalesDetailsData = null;
    this.salesSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.pendingOrderDetails;
    let code = Constants.normalText.po;
    let slidercode = Constants.normalText.zdop;
    if(this.viewAs != 'Customer' && this.viewAs != 'GCC'){
      this.allSalesDetailsForIndividualTile(code,slidercode);
    }else{
      this.allSalesDetailsForIndividualTile(code);
    }
    this.isPendingOrderTable = true;
    this.isTotalSalesTable = false;
    this.isConfirmOrderTable = false;
    this.isBlockedOrderTable = false;
    this.isGradeEnabled = false;
    this.isZDDPEnabled = false;
    this.isZDOPEnabled = true;
    this.isColumnActive = false;
  }

  blockedSalesOrder() {
    this.allSalesDetailsData = null;
    this.salesSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.blockedOrderDetails;
    let code = Constants.normalText.bo;
    this.allSalesDetailsForIndividualTile(code);
    this.isBlockedOrderTable = true;
    this.isTotalSalesTable = false;
    this.isConfirmOrderTable = false;
    this.isPendingOrderTable = false;
    this.isGradeEnabled = false;
    this.isZDDPEnabled = false;
    this.isZDOPEnabled = false;
  }

  downloadOverallSalesValueQtyReport() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Trend_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Trend_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      } else if(this.region){
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: [this.region],
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      }else {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode : this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Sales_Trend_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }

  openDetailsDataPopupForExcel(text){

    if(text == 'chart1'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        } else {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData} });
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        } else {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData} });
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        } else if(this.region){
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        }else {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData} });
          }
        })
      }
    }

    if(text == 'chart2'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.getChartExcelData} });
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.getChartExcelData} });
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [],
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: [],
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        } else if(this.region){
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: [this.region],
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode : this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.getChartExcelData} });
          }
        })
      }
    }
    
    if(text == 'chart3'){
      if(this.viewAs != 'GCC'){
        let payload = {
          gccDate: this.gccValue?.gccBillingDate,
          gccCode: this.gccValue?.gccCode,
          loginFromApp: false,
          type: 'details'
        }
    
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data, gccDate:this.gccValue?.gccBillingDate,  gccCode: this.gccValue?.gccCode}});
          }
        })
      }else{
        let payload = {
          gccDate: null,
          gccCode: this.viewAsGCC.encrypt(),
          loginFromApp: false,
          type: 'details'
        }
    
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data != null){
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data, gccDate:null,  gccCode: this.viewAsGCC.encrypt()}});
          }
        })
      }
      
    }

    if(text == 'chart4'){

      if(this.viewAs != 'GCC'){
        let payload = {
          gccDate: this.gccValue?.gccBillingDate,
          gccCode: this.gccValue?.gccCode,
          loginFromApp: false,
          type: 'details'
        }

        this.loaderService.show();
      this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
       if(data && data != null){
        this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data, gccDate:this.gccValue?.gccBillingDate,  gccCode: this.gccValue?.gccCode}});
      }
      })
      }else{
        let payload = {
          gccDate: null,
          gccCode: this.viewAsGCC.encrypt(),
          loginFromApp: false,
          type: 'details'
        }

        this.loaderService.show();
      this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
       if(data && data != null){
        this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data, gccDate:null,  gccCode: this.viewAsGCC.encrypt()}});
      }
      })
      }
     
  
      
    }

  }

  downloadForIndividualTile(codeData, fileName, slidercode?) {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            regions: [this.region],
            toggleCode: codeData,
            payer: [],
            monthInterval: this.timePeriod,
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
    }else{
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            regions: [this.region],
            toggleCode: codeData,
            payer: [],
            userType: "BU",
            monthInterval: this.timePeriod,
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            userType: "BU",
            regions: this.user?.userRegion,
            sliderEnabled : true,
            slidercode: slidercode,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
    }
    

  }

  downloadTableDataSales(){
    if(!this.isCheckedSliderSales){
      if (this.tabLabels == Constants.normalText.salesDetails) {
        this.downloadForIndividualTile(Constants.normalText.tp,'Total_Sales_');
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetails) {

        if(this.isCheckedZDDPSliderSales){
          this.downloadForIndividualTile(Constants.normalText.co,'Pending_Order(ZDDP/ZCDP)_', Constants.normalText.zcdp);
        }else{
          this.downloadForIndividualTile(Constants.normalText.co,'Pending_Order(ZDDP/ZCDP)_',  Constants.normalText.zddp);  
        }
       
        // this.downloadForIndividualTile(Constants.normalText.co,'Pending_Order(ZDDP)_');
      }

      else if (this.tabLabels == Constants.normalText.confirmOrderDetailsPurchase) {
          this.downloadForIndividualTile(Constants.normalText.co,'Pending_Order_');
      }

      else if (this.tabLabels == Constants.normalText.pendingOrderDetails && (this.viewAs != 'Customer' && this.viewAs != 'GCC')) {
        if(this.isCheckedZDOPSliderSales){
          this.downloadForIndividualTile(Constants.normalText.po,'Open_Order_', Constants.normalText.zcop);  
        }else{
          this.downloadForIndividualTile(Constants.normalText.po,'Open_Order_', Constants.normalText.zdop);  
        } 

        // this.downloadForIndividualTile(Constants.normalText.po,'Open_Order_', slidercode);
      }
      else if (this.tabLabels == Constants.normalText.pendingOrderDetails || (this.viewAs == 'Customer' || this.viewAs == 'GCC')) {
          this.downloadForIndividualTile(Constants.normalText.po,'Open_Order_');
      }
      else if (this.tabLabels == Constants.normalText.blockedOrderDetails) {
        this.downloadForIndividualTile(Constants.normalText.bo,'Blocked_Order_');
      }
    }
    else{
      if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Sales_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Sales_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          } else if(this.region){
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              regions: [this.region],
              toggleCode: Constants.normalText.tp,
              payer: [],
              monthInterval: this.timePeriod,
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          }else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              gccCode: this.gccValue?.gccCode.decrypt(),
              userType: "BU",
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Sales_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
      }else{
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Sales_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Sales_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else if(this.region){
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              regions: [this.region],
              toggleCode: Constants.normalText.tp,
              payer: [],
              userType: "BU",
              monthInterval: this.timePeriod,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              userType: "BU",
              regions: this.user?.userRegion,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Sales_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
      }
      
    }
  }

  searchSales(){
    if(!this.isCheckedSliderSales){
      if (this.tabLabels == Constants.normalText.salesDetails) {
        this.allSalesDetailsForIndividualTile(Constants.normalText.tp);
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetails) {
        if(this.isCheckedZDDPSliderSales){
          this.allSalesDetailsForIndividualTile(Constants.normalText.co,Constants.normalText.zcdp);
        }else{
          this.allSalesDetailsForIndividualTile(Constants.normalText.co,Constants.normalText.zddp);
        }
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetailsPurchase) {
          this.allSalesDetailsForIndividualTile(Constants.normalText.co);
      }
      else if (this.tabLabels == Constants.normalText.pendingOrderDetails && (this.viewAs != 'Customer' && this.viewAs != 'GCC')) {
        if(this.isCheckedZDOPSliderSales){
          this.allSalesDetailsForIndividualTile(Constants.normalText.po, Constants.normalText.zcop); 
        }else{
          this.allSalesDetailsForIndividualTile(Constants.normalText.po, Constants.normalText.zdop);  
        } 
      }
      else if (this.tabLabels == Constants.normalText.pendingOrderDetails || (this.viewAs == 'Customer' || this.viewAs == 'GCC')) {
          this.allSalesDetailsForIndividualTile(Constants.normalText.po);
      }
      else if (this.tabLabels == Constants.normalText.blockedOrderDetails) {
        this.allSalesDetailsForIndividualTile(Constants.normalText.bo);
      }
    }else{
      this.allSalesDetailsData = null;
      if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allSalesDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          } else if(this.region){
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [this.region],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user.userRegion,
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
      }
      
      else{
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allSalesDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else if(this.region){
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [this.region],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user.userRegion,
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
      }
    }
  }

  goBackToHome(){
    this.router.navigate(['/home']).then(success => {
      window.location.reload();
    });
    sessionStorage.removeItem('dispatchFilter');
    sessionStorage.removeItem('complaintFilter');
    sessionStorage.removeItem('salesTimeinterval');
    sessionStorage.removeItem('tabIndex');
    sessionStorage.removeItem('sliderGcc');
  }

  downloadSalesComparisonGccWiseValueReport() {
    if(this.viewAs != 'GCC'){
      let payload = {
        gccDate: this.gccValue?.gccBillingDate,
        gccCode: this.gccValue?.gccCode,
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Value_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }else{
      let payload = {
        gccDate: null,
        gccCode: this.viewAsGCC.encrypt(),
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Value_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
   
  }

  downloadSalesComparisonGccWiseQtyReport() {
    if(this.viewAs != 'GCC'){
      let payload = {
        gccDate: this.gccValue?.gccBillingDate,
        gccCode: this.gccValue?.gccCode,
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }else{
      let payload = {
        gccDate: null,
        gccCode: this.viewAsGCC.encrypt(),
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    
  }

  showGcc(evt){

    sessionStorage.removeItem('callFromTileTotalSales');
    sessionStorage.removeItem('callFromTileTotalConfirmSales');
    sessionStorage.removeItem('callFromTileTotalPendingSales');
    sessionStorage.removeItem('callFromTileTotalBlockedSales');

    if(this.getTotalSalesDetails?.state?.callFrom == "Total Sales"){
      this.getTotalSalesDetails.state.callFrom = null;
    }
   
    if(this.getConfirmedSalesDetails?.state?.callFrom == "Confirmed Sales"){
      this.getConfirmedSalesDetails.state.callFrom = null;
    }

    if(this.getPendingSalesDetails?.state?.callFrom == "Pending Sales"){
      this.getPendingSalesDetails.state.callFrom = null;
    }

    if(this.getBlockedSalesDetails?.state?.callFrom == "Blocked Sales"){
      this.getBlockedSalesDetails.state.callFrom = null;
    }

    if(!this.isCheckedSliderGcc){
      sessionStorage.setItem('sliderGcc', 'On GCC');
      this.gccChart = true;
      if(this.viewAs != 'GCC'){
        let payload = {
          gccDate: this.gccValue?.gccBillingDate,
          gccCode: this.gccValue?.gccCode.decrypt(),
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data != null){
            this.gccChartData = data;
          }
        })
  
        this.getPurchaseOrderManagementData();
        this.getPurchaseTarget();
        window.location.reload();
      }else{
        let payload = {
          gccDate: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data != null){
            this.gccChartData = data;
          }
        })
  
        this.getPurchaseOrderManagementData();
        this.getPurchaseTarget();
        window.location.reload();
      }
      
    }else{
      sessionStorage.removeItem('sliderGcc');
      this.gccChart = false;
      window.location.reload();
    }
  }


  openCustomerViewPopup(){
    if(this.region){
      this.payloadforCustomerView = {
        topOrBottom: "true",
        quantityOrValue: "true",
        regions: [this.region],
        gccCode : this.viewAsGCC,
        monthInterval: this.timePeriod,
      }
    }else{
      this.payloadforCustomerView = {
        topOrBottom: "true",
        quantityOrValue: "true",
        regions: this.user.userRegion,
        gccCode : this.viewAsGCC,
        monthInterval: this.timePeriod,
      }
    }
   

    this.loaderService.show();
    this.purchaseService.topCustomerDetails(this.payloadforCustomerView).pipe(takeUntil(this.destroyed$)).subscribe(dataCustomer => {
      this.loaderService.hide();
      if(dataCustomer && dataCustomer?.getTopCustomers){
        this.dialog.open(TopCustomerExpandPopupComponent, { disableClose: true, width: '60%', height: '89%', data: dataCustomer });
      }
    })
  }

  monthIntervalData(evt){

    sessionStorage.setItem('salesTimeinterval', evt);

    if(evt != 0){
      this.isPanelActive = false;
    }else{
      this.isPanelActive = true;
    }

    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
  
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: evt,
            regions: [],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } 
        else if(this.region){
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: [this.region],
            gccCode: this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            gccCode: this.gccValue?.gccCode.decrypt(),
            regions: this.user?.userRegion,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
  
      this.getTopCustomersData();
    }else{
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: evt,
            regions: [],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } 
        else if(this.region){
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: [this.region],
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }else {
          this.payloadPurchaseOrderManagementData = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
  
      this.getTopCustomersData();
    }
   
  }


  openPopupForHistoricalData(){
    this.dialog.open(ViewHistoricalPopupComponent, { disableClose: true, width: '60%', height: '70%'});
  }

  getCurrentMonth() {
    const d = new Date();
    this.currentMonth = d.getMonth();
  }

  getCurrentFinancialYear() {
    let today = new Date();
    if ((today.getMonth() + 1) <= 3) {
      this.currentFinancialYear = today.getFullYear();
    }
    else {
      this.currentFinancialYear = (today.getFullYear() + 1);
    }
  }


  getPurchaseTarget() {

    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
      this.user?.userRole.forEach(ele => {
        this.userRoleId.push(ele?.id);
      })

      let gccArr =  [this.gccValue?.gccCode];
  
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: [5]
          }
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        }
  
        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        }
  
  
        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: [5]
          }
        } 
        else if(this.region){
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        }else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        }
  
        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
    }else{
      this.user?.userRole.forEach(ele => {
        this.userRoleId.push(ele?.id);
      })
  
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: [5]
          }
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        }
  
        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        }
  
  
        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: [5]
          }
        } 
        else if(this.region){
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        }
        else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        }
  
        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
    }
   
  }

  changeGradeYesNo(){
    if(this.isCheckedSliderSales){
      let code = Constants.normalText.tp;
      this.allSalesDetailsForIndividualTile(code);   
    }else{
      this.allSalesDetailsData = null;
      if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC'){
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allSalesDetailsData = data;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          } else if(this.region){
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [this.region],
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user.userRegion,
              text: this.salesSearch,
              gccCode: this.gccValue?.gccCode.decrypt(),
              sliderEnabled : false,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
            }
          })
        }
      }
      
      else{
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allSalesDetailsData = data;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadAllSalesDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else if(this.region){
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [this.region],
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }else {
            this.payloadAllSalesDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user.userRegion,
              text: this.salesSearch,
              sliderEnabled : false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
    
          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllSalesDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allSalesDetailsData = data;
            }
          })
        }
      }
    }
  }

  changeZDDPToZCDP(){
    if(this.isCheckedZDDPSliderSales){
      let code = Constants.normalText.co;
      let slidercode = Constants.normalText.zddp;
      this.allSalesDetailsForIndividualTile(code, slidercode);
      this.isConfirmOrderTable = true;
      this.isZCDPZCOPTable = false;
    }else{
      let code = Constants.normalText.co;
      let slidercode = Constants.normalText.zcdp;
      this.allSalesDetailsForIndividualTile(code, slidercode);
      this.isConfirmOrderTable = false;
      this.isZCDPZCOPTable = true;
    }
  }

  changeZDOPToZCOP(){
    if(this.isCheckedZDOPSliderSales){
      let code = Constants.normalText.po;
      let slidercode = Constants.normalText.zdop;
      this.allSalesDetailsForIndividualTile(code, slidercode);
      this.isZCDPZCOPTable = false;
      this.isPendingOrderTable = true;
    }else{
      let code = Constants.normalText.po;
      let slidercode = Constants.normalText.zcop;
      this.allSalesDetailsForIndividualTile(code, slidercode);  
      this.isZCDPZCOPTable = true;
      this.isPendingOrderTable = false;
    }
  }

  openDispatchDetailsPopup(itemDdata){
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsData = data?.entries;
          this.dialog.open(DispatchDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {searchData: this.allDispatchDetailsData, zddpSalesDocNo: itemDdata?.zddpSalesDocNo} });
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsData = data?.entries;
          this.dialog.open(DispatchDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {searchData: this.allDispatchDetailsData, zddpSalesDocNo: itemDdata?.zddpSalesDocNo} });
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsData = data?.entries;
          this.dialog.open(DispatchDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {searchData: this.allDispatchDetailsData, zddpSalesDocNo: itemDdata?.zddpSalesDocNo} });
        }
      })
    }

  }

}
