import { Injectable } from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class CaptchaService {
  
  captchSource = new BehaviorSubject(null);
  isLogout = new BehaviorSubject(null);
  logoutStatus = this.isLogout.asObservable(); 
  captchStatus = this.captchSource.asObservable(); 
  
  constructor() { }

  setCaptchaStatus(code) {
    this.captchSource.next(code);
  }

  setLogoutStatus(code) {
    this.isLogout.next(code);
  }

}