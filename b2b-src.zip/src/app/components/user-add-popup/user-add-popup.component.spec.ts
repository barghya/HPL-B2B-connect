import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddPopupComponent } from './user-add-popup.component';

describe('UserAddPopupComponent', () => {
  let component: UserAddPopupComponent;
  let fixture: ComponentFixture<UserAddPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserAddPopupComponent]
    });
    fixture = TestBed.createComponent(UserAddPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
