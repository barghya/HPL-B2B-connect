import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { CommonApiService } from 'src/app/services/common/common-api.service';
import { UserManagementService } from 'src/app/services/user-management/user-management.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-add-popup',
  templateUrl: './user-add-popup.component.html',
  styleUrls: ['./user-add-popup.component.css']
})
export class UserAddPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  userFirstName: any;
  userLastName: any;
  userEmpCode: any;
  userEmailId: any;
  userContactNo: any;
  userAddress: any;
  userRegion: any;
  userRole: any;
  regionArr: any[] = [];
  roleArr: any[] = [];



  constructor(private common: CommonApiService, private commonservice: CommonService, private userService: UserManagementService, private loaderService: LoaderService, private dialogRef: MatDialogRef<UserAddPopupComponent>){}

  ngOnInit(): void {
    this.getRegion();
    this.getRole();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  getRegion(){
    this.loaderService.show();
    this.common.regionMaster().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data){
        this.regionArr = data;
      }
    })
  }

  getRole(){
    this.loaderService.show();
    this.common.roleMaster().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data){
        data?.forEach(element => {
          if(element?.id == 3 || element?.id == 4){
            this.roleArr.push(element);
          }
        })
      }
    })
  }

  createUser(){

    let validEmail = this.commonservice.regexForEmail(this.userEmailId);
    let validContact = this.commonservice.regexForNumericandDecimalNumber(this.userContactNo);

    if(!this.userFirstName){
      Swal.fire(alertPopup.firstNameEmpty);
    }
    else if(!this.userLastName){
      Swal.fire(alertPopup.lastNameEmpty);
    }
    else if(!this.userEmpCode){
      Swal.fire(alertPopup.empCodeEmpty);
    }
    else if(!this.userEmailId){
      Swal.fire(alertPopup.mailEmpty);
    }
    else if(!validEmail){
      Swal.fire(alertPopup.validmail);
    }
    else if(!this.userContactNo){
      Swal.fire(alertPopup.contactNoEmpty);
    }
    else if(validContact){
      Swal.fire(alertPopup.validContact);
    }
    else if(!this.userAddress){
      Swal.fire(alertPopup.addressEmpty);
    } 
    else if(!this.userRegion){
      Swal.fire(alertPopup.regionEmpty);
    }
    else if(!this.userRole){
      Swal.fire(alertPopup.roleEmpty);
    } else{
      let payload = {
        firstName: this.userFirstName,
        lastName: this.userLastName,
        empCode: this.userEmpCode,
        emaiId: this.userEmailId,
        contact: this.userContactNo,
        address: this.userAddress,
        hierarchyLevelId: null,
        userTypeId: 1,
        regionId: [+this.userRegion],
        roleId: +this.userRole,
        loggedInUserId: this.user?.id
    }
    this.loaderService.show();
    this.userService.createUser(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data.status == 1) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: data.message,
          showCancelButton: false,
          allowEnterKey: false,
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: data.message,
          showCancelButton: false,
          allowEnterKey: false,
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        })
      }
    })
  }
  }

  closePopup(){
    this.dialogRef.close();
  }

}
