import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerActivationPopupComponent } from './customer-activation-popup.component';

describe('CustomerActivationPopupComponent', () => {
  let component: CustomerActivationPopupComponent;
  let fixture: ComponentFixture<CustomerActivationPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CustomerActivationPopupComponent]
    });
    fixture = TestBed.createComponent(CustomerActivationPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
