import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-activation-popup',
  templateUrl: './customer-activation-popup.component.html',
  styleUrls: ['./customer-activation-popup.component.css']
})
export class CustomerActivationPopupComponent {

}
