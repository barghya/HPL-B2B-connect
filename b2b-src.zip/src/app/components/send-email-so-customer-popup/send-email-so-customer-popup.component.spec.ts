import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendEmailSoCustomerPopupComponent } from './send-email-so-customer-popup.component';

describe('SendEmailSoCustomerPopupComponent', () => {
  let component: SendEmailSoCustomerPopupComponent;
  let fixture: ComponentFixture<SendEmailSoCustomerPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SendEmailSoCustomerPopupComponent]
    });
    fixture = TestBed.createComponent(SendEmailSoCustomerPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
