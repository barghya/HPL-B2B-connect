import { Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-send-email-so-customer-popup',
  templateUrl: './send-email-so-customer-popup.component.html',
  styleUrls: ['./send-email-so-customer-popup.component.css']
})
export class SendEmailSoCustomerPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  customerEmailId: any;
  respondToEmailId: any;
  sendMailRemarks: any;
  isFileUploaded: any;
  fileAdded: boolean;
  file: File = null;
  @ViewChild('myInputFile')
  myInputVariable: ElementRef;
  fileArr: any[] = [];


  constructor(private customerService: CustomerService, private commonservice: CommonService, private loaderService: LoaderService, private dialogRef: MatDialogRef<SendEmailSoCustomerPopupComponent>, @Inject(MAT_DIALOG_DATA) public customerData: any) { }

  ngOnInit(): void {

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  onFileChangeSendEmail(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    this.fileArr = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  removeFile() {
    this.fileArr = [];
    this.myInputVariable.nativeElement.value = "";
  }

  sendMail() {

    let validEmail = this.commonservice.regexForEmail(this.respondToEmailId);

    if (!this.respondToEmailId) {
      Swal.fire(alertPopup.mailEmpty);
    }
    else if (!validEmail) {
      Swal.fire(alertPopup.validmail);
    }
    else if (!this.sendMailRemarks) {
      Swal.fire(alertPopup.remarks);
    }
    // else if (this.fileArr.length == 0) {
    //   Swal.fire(alertPopup.uploadFile);
    // } 
    else {

      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('file', this.file, this.file.name);
      }

      let sendMailToCustomer = {
        customerMailId: this.customerData?.emailId,
        respondToMailId: this.respondToEmailId,
        remarks: this.sendMailRemarks,
        customerName: this.customerData?.customerName,
        userId: this.user?.userId,
        loginFromApp: false
      }

      Object.entries(sendMailToCustomer).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.sentMailToCustomer(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              this.dialogRef.close();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              this.dialogRef.close();
            }
          })
        }
      })

    }

  }

  closePopup() {
    this.dialogRef.close();
  }


}
