import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-ageing-chart',
  templateUrl: './account-ageing-chart.component.html',
  styleUrls: ['./account-ageing-chart.component.css']
})
export class AccountAgeingChartComponent implements OnInit {

  @Input() inputDataAgeingChartValue: any;

  constructor() { }

  ngOnInit(): void {
    this.praparedAgeingChartData();
  }

  praparedAgeingChartData() {
    this.inputDataAgeingChartValue = {
      color: ['#BB8C6B'],
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid:{left:'20%', width:'67%', height:'70%', top:'20%'},
      xAxis: {
        // type: 'value',
        // boundaryGap: [0, 0.01],
        // axisLabel: {
        //   rotate: 30,
        //   formatter: function (value) {
        //     if (value >= 0 && value < 1000) {
        //       value;
        //     }
        //     if (value >= 1000 && value < 100000) {
        //       value = value / 1000 + "K";
        //     }
        //     if (value >= 100000 && value < 1000000) {
        //       value = value / 1000000 + "M";
        //     }
        //     if (value >= 1000000) {
        //       value = value / 1000000000 + "B";
        //     }
        //     return value;
        //   }
        // }
        splitLine: {
          show: false
        },
        axisLabel: {
          inside: true,
          color: '#fff'
        },
        axisTick: {
          show: false
        },
        axisLine: {
          show: false
        },
      },
      yAxis: {
        type: 'category',
        name: 'Days',
        data: this.inputDataAgeingChartValue?.chartXaxisData?.data
      },
      series: [
        {
          // name: 'Direct',
          type: 'bar',
          // barWidth: '20%',
          data: this.inputDataAgeingChartValue?.barChartSeriesData?.data,
        }
      ]
    }
  }

}
