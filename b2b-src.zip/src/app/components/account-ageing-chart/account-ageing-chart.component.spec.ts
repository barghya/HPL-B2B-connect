import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountAgeingChartComponent } from './account-ageing-chart.component';

describe('AccountAgeingChartComponent', () => {
  let component: AccountAgeingChartComponent;
  let fixture: ComponentFixture<AccountAgeingChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AccountAgeingChartComponent]
    });
    fixture = TestBed.createComponent(AccountAgeingChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
