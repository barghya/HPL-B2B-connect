import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-amendment-action-popup',
  templateUrl: './amendment-action-popup.component.html',
  styleUrls: ['./amendment-action-popup.component.css']
})
export class AmendmentActionPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  amendmentAction: any;
  amendmentRemarks: any;


  constructor(private customerService: CustomerService, private loaderService: LoaderService, private dialogRef: MatDialogRef<AmendmentActionPopupComponent>, @Inject(MAT_DIALOG_DATA) public amendmentActionData: any) { }

  ngOnInit(): void {

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  saveAmendmentAction() {
    if (!this.amendmentAction) {
      Swal.fire(alertPopup.emptyAmendmentAction);
    }
    else if (!this.amendmentRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.amendmentActionData?.id,
        prvStatusId: this.amendmentActionData?.status?.id,
        selectedStatusId: this.amendmentAction,
        remarks: this.amendmentRemarks,
        loggedInUserId: this.user?.id
      }
      
      this.loaderService.show();
      this.customerService.processAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data?.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        }
      })
    }

  }

  closePopup() {
    this.dialogRef.close();
  }

}
