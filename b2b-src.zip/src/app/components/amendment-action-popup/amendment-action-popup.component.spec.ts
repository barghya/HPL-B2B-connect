import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AmendmentActionPopupComponent } from './amendment-action-popup.component';

describe('AmendmentActionPopupComponent', () => {
  let component: AmendmentActionPopupComponent;
  let fixture: ComponentFixture<AmendmentActionPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AmendmentActionPopupComponent]
    });
    fixture = TestBed.createComponent(AmendmentActionPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
