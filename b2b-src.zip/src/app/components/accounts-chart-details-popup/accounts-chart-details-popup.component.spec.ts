import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountsChartDetailsPopupComponent } from './accounts-chart-details-popup.component';

describe('AccountsChartDetailsPopupComponent', () => {
  let component: AccountsChartDetailsPopupComponent;
  let fixture: ComponentFixture<AccountsChartDetailsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AccountsChartDetailsPopupComponent]
    });
    fixture = TestBed.createComponent(AccountsChartDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
