import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { AccountManagementService } from 'src/app/services/accounts-management/account-management.service';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';

@Component({
  selector: 'app-accounts-chart-details-popup',
  templateUrl: './accounts-chart-details-popup.component.html',
  styleUrls: ['./accounts-chart-details-popup.component.css']
})
export class AccountsChartDetailsPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  pageNo = 1;
  tableSearchAccounts: any;
  payloadDownloadIndividualTile: any;
  payloadDownloadAgeingChart: any;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');



  constructor(private purchaseService: PurchaseManagementService, private loaderService: LoaderService, private accountService: AccountManagementService, private dialogRef: MatDialogRef<AccountsChartDetailsPopupComponent>, @Inject(MAT_DIALOG_DATA) public excelChartData: any){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }


  searchtableAccounts(){

    if (this.excelChartData?.text == 'chart1' && this.user?.userTypeId == 1) {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.excelChartData.chartData = data?.getChartExcelData;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.excelChartData.chartData = data?.getChartExcelData;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: [this.region],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.excelChartData.chartData = data?.getChartExcelData;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart1'  && (this.user?.userTypeId == 2 || this.user?.userTypeId == 3)) {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.excelChartData.chartData = data?.getChartExcelData;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.excelChartData.chartData = data?.getChartExcelData;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }  else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: [this.region],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.excelChartData.chartData = data?.getChartExcelData;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart2') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [this.region],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart3') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }  else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [this.region],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.excelChartData.chartData = data?.entries;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart4'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.ageingChartDetails != null){
            this.excelChartData.chartData = data?.ageingChartDetails;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.ageingChartDetails != null){
            this.excelChartData.chartData = data?.ageingChartDetails;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        } else if(this.region){
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: [this.region],
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }else {
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchAccounts
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.ageingChartDetails != null){
            this.excelChartData.chartData = data?.ageingChartDetails;
          }
        })
      }

    }

  }

  closePopup() {
    this.dialogRef.close();
  }

}
