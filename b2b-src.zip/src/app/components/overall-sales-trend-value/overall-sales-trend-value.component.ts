import { Component, Input, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-overall-sales-trend-value',
  templateUrl: './overall-sales-trend-value.component.html',
  styleUrls: ['./overall-sales-trend-value.component.css']
})
export class OverallSalesTrendValueComponent implements OnInit {

  @Input() inputDataOverallPurchaseTrendValue: any;

  constructor(private location: Location) { }

  ngOnInit(): void {
    this.praparedOverallPurchaseTrendValueChartData();
  }

  praparedOverallPurchaseTrendValueChartData() {
    if (this.location.path() === '/salesOrderManagement') {
      this.inputDataOverallPurchaseTrendValue = {

        color: ['#BB8C6B'],
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          },
          textStyle: {
            fontSize: 12,
          },
          appendToBody: true
        },
        grid: { left: '20%', width: '67%', height: '59%', top: '10%' },
        xAxis: [
          {
            axisLabel: {
              rotate: 70,
              // fontSize: 10,
            },
            type: 'category',
            // data: ["Oct 23","Nov 23","Dec 23","Jan 24","Feb 24","Mar 24"],
            data: this.inputDataOverallPurchaseTrendValue?.chartXaxisData?.data,
            axisTick: {
              alignWithLabel: true
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              show: false
            },
            axisLabel: {
              formatter: function (value) {
                // if (value >= 0 && value < 1000) {
                //   value;
                // }
                // if (value >= 1000 && value < 100000) {
                //   value = value / 1000 + "K";
                // }
                // if (value >= 100000 && value < 1000000) {
                //   value = value / 1000000 + "M";
                // }
                // if (value >= 1000000) {
                //   value = value / 1000000000 + "B";
                // }
                // return value;

                if (value >= 0 && value < 1000) {
                  value;
                }
                if (value >= 100000 && value < 10000000) {
                  value = value / 100000 + "L";
                }
                if (value >= 10000000) {
                  value = value / 10000000 + "Cr";
                }
                return value;
              }
            }
          }
        ],
        series: [
          {
            // name: 'Direct',
            type: 'bar',
            barWidth: '20%',
            data: this.inputDataOverallPurchaseTrendValue?.lineChartSeriesData?.data,
          }
        ]
      };
    } else {
      this.inputDataOverallPurchaseTrendValue = {
        color: ['#BB8C6B'],
        tooltip: {
          trigger: 'axis',
          // formatter: function (value) {
          //   if (value >= 0 && value < 1000) {
          //     value;
          //   }
          //   if (value >= 1000 && value < 100000) {
          //     value = value / 1000 + "K";
          //   }
          //   if (value >= 100000 && value < 1000000) {
          //     value = value / 1000000 + "M";
          //   }
          //   if (value >= 1000000) {
          //     value = value / 1000000000 + "B";
          //   }
          //   return value;
          // }
        },
        grid: { left: '20%', width: '67%', height: '59%', top: '10%' },
        xAxis: {
          axisLabel: {
            rotate: 70,
          },
          type: 'category',
          data: this.inputDataOverallPurchaseTrendValue?.chartXaxisData?.data,
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: function (value) {
              if (value >= 0 && value < 1000) {
                value;
              }
              if (value >= 100000 && value < 10000000) {
                value = value / 100000 + "L";
              }
              if (value >= 10000000) {
                value = value / 10000000 + "Cr";
              }
              return value;
            }
          }
        },
        series: [
          {
            data: this.inputDataOverallPurchaseTrendValue?.barChartSeriesData?.data,
            type: 'line',
            smooth: true
          }
        ]
      }
    }

  }

}
