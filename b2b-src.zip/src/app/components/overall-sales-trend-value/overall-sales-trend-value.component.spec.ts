import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverallSalesTrendValueComponent } from './overall-sales-trend-value.component';

describe('OverallSalesTrendValueComponent', () => {
  let component: OverallSalesTrendValueComponent;
  let fixture: ComponentFixture<OverallSalesTrendValueComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OverallSalesTrendValueComponent]
    });
    fixture = TestBed.createComponent(OverallSalesTrendValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
