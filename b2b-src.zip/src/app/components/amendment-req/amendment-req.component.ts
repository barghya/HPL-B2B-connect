import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Observable, ReplaySubject, map, startWith, takeUntil } from 'rxjs';
import { CommonApiService } from 'src/app/services/common/common-api.service';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { MyTargetService } from 'src/app/services/my-target/my-target.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';
import { CommonService } from 'src/app/utils/common-service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';
import { PreviousAmendmentDetailsComponent } from '../previous-amendment-details/previous-amendment-details.component';

@Component({
  selector: 'app-amendment-req',
  templateUrl: './amendment-req.component.html',
  styleUrls: ['./amendment-req.component.css']
})
export class AmendmentReqComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  selected: any = {};
  subMenuList = ['All', 'Approval Pending', 'Rejected'];
  ammendUserList = ['Basic Details', 'Other Details', 'Files'];
  allSection: boolean = true;
  approvedSection: boolean = false;
  approvalPendingSection: boolean = false;
  activationPendingSection: boolean = false;
  rejectedSection: boolean = false;
  basicDetailsSection: boolean = true;
  otherDetailsSection: boolean = false;
  fileSection: boolean = false;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  allCustomerData: any[] = [];
  allApprovedCustomerData: any[] = [];
  allApprovalPendingCustomerData: any[] = [];
  allActivationPendingCustomerData: any[] = [];
  allRejectedCustomerData: any[] = [];
  custDetails: boolean = true;
  amendmentDetails: boolean = false;
  allViewForOfficer: boolean = true;
  officersView: boolean = false;
  individualCustomerData: any;
  companyNameCustomerAmendment: any;
  phoneCustomerAmendment: any;
  emailCustomerAmendment: any;
  addressCustomerAmendment: any;
  countryCustomerAmendment: any;
  faxCustomerAmendment: any;
  payloadDetailIndividualCustomer: any;
  payloadAllCustomer: any;
  salesOfficerRemarks: any;
  isFileUploaded: any;
  fileAdded: boolean;
  file: File = null;
  regionalMarketingRemarks: any;
  headMarketingRemarks: any;
  individualBusinessOfiicerData: any;
  onboardingCustCode: any;
  onboardingRegion: any;
  onboardingCustType: any;
  regionArr: any[] = [];
  custType: any[] = [];
  individualCustomer: any;
  phoneNoCustAmendment: any;
  emailIdCustAmendment: any;
  descriptionCustAmendment: any;
  mainOfficersData: boolean = false;
  custCodeArr: any[] = [];
  filteredCustCode: Observable<any[]>;
  customerCodeControl = new FormControl('');
  customerCode: any;
  uploadDataRes: any;
  selectedItem: any;
  rejectedPanelSO: boolean = false;
  rejectedPanelRM: boolean = false;
  rejectedPanelPH: boolean = false;
  subCustAmendment: any;
  salesOfficerAmendment: any;
  custProfilePayload: any;
  custPreviousAmendmentPayload: any;
  custProfileData: any;
  selectedSoEle: any;
  previousAmendmentData: any[] =[];
  firstPanel: boolean = false;
  custCode: boolean = false;
  step = 0;
  @ViewChild('myInputFile')
  myInputVariable: ElementRef;
  fileArr: any[] = [];
  


  constructor(private commonApiService: CommonApiService, private commonservice: CommonService,  private targetService: MyTargetService, private common: CommonApiService, private commonService: CommonService, private dialog: MatDialog, private customerService: CustomerService, private loaderService: LoaderService){}


  ngOnInit(): void {
    // this.user.id = this.user?.id?.toString().encrypt();
    
    if(this.user?.userTypeId == 3){
      this.getCustomerProfile();
      this.getPreviousAmendment();
    }
    if(this.user?.userTypeId == 2){
      this.getPreviousAmendment();
    }
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  getCustomerProfile(){
    if(this.user?.userTypeId == 3){
      this.custProfilePayload = {
        customerCode: this.user?.userId.decrypt()
      }
      this.loaderService.show();
      this.customerService.custProfileData(this.custProfilePayload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        if(data && data != null){
          this.custProfileData = data;
        }
      })
    }   
  }

  private _filterCustCode(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.custCodeArr.filter(option => option?.customerName?.toLowerCase().includes(filterValue));
  }

  getCustomerByCSA() {
    let payload = {
      viewFor: 'Customer',
      userId: this.user?.userId,
      loginFromApp: false,
      code: this.customerCodeControl.value
    }

    if(this.customerCodeControl.value.length > 4){
      this.loaderService.show();
      this.commonApiService.viewAsCustCsa(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getCustomerList) {
          this.custCodeArr = data?.getCustomerList;
          this.filteredCustCode = this.customerCodeControl.valueChanges.pipe(
            startWith(''),
            map(value => this._filterCustCode(value || '')),
          );
        }
      })
    }else{
      this.custCodeArr = [];
    }

   
  }

  getPreviousAmendment(){
      this.custPreviousAmendmentPayload = {
        customerCode: this.user?.id,
        loggedInUserId: this.user?.id,
        // loggedInUserId: this.user?.id?.toString()?.encrypt(),
        loginFromApp: false
      }
      this.loaderService.show();
      this.customerService.previousAmendmentData(this.custPreviousAmendmentPayload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        if(data && data != null){
          this.previousAmendmentData = data;
        }
      })
  }

  soSelection(evt){
    this.custProfileData?.soDetails.forEach(ele => {
      if(evt?.target.value == ele?.id){
        this.selectedSoEle = ele;
      }
    })
  }

  viewDetailsForIndividualAmendment(item){
    let payload = {
      id: item?.id
    }

    this.loaderService.show();
    this.customerService.customerAmendmentData(payload).pipe(takeUntil(this.destroyed$)).subscribe(dataAmendment => {
      if(dataAmendment && dataAmendment!= null){
        this.dialog.open(PreviousAmendmentDetailsComponent, { disableClose: true, width: '70%', height: '86%', data: dataAmendment });
      }
    })
    
  }
  
  onFileChange(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  
  selectedCustCode(item) {
    
    this.customerCode = item?.customerCode;
    this.selectedItem = item;
    this.firstPanel = true;
    this.custCode = true;
    this.custProfilePayload = {
      customerCode: this.customerCode
    }
    this.loaderService.show();
    this.customerService.custProfileData(this.custProfilePayload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      if(data && data != null){
        this.custProfileData = data;
      }
    })
  }

  getDetailIndividualCustomer() {
    if (this.filterCode) {
      this.payloadDetailIndividualCustomer = {
        userId: this.filterCode.encrypt(),
        loginFromApp: false
      }
    } else {
      this.payloadDetailIndividualCustomer = {
        userId: this.user.userId,
        loginFromApp: false
      }
    }

    this.loaderService.show();
    this.customerService.customerDetailsUrl(this.payloadDetailIndividualCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

  }

  select(type?, item?, $event?) {
    this.selected[type] = (this.selected[type] === item ? null : item);
    $event ? $event.stopPropagation() : null;
    this.customerNavigationFromSubMenu(item);
  }

  customerNavigationFromSubMenu(data) {
    if (data == Constants.normalText.all) {
      this.allSection = true;
      this.approvedSection = false;
      this.approvalPendingSection = false;
      this.activationPendingSection = false;
      this.rejectedSection = false;
      // if(this.allCustomerData.length == 0){
      //   this.getAllCustomer();
      // }
    }
    if (data == Constants.normalText.approved) {
      this.approvedSection = true;
      this.allSection = false;
      this.approvalPendingSection = false;
      this.activationPendingSection = false;
      this.rejectedSection = false;
      if (this.allApprovedCustomerData.length == 0) {
        this.approvedCustomer();
      }
    }
    // if (data == Constants.normalText.approvalPending) {
    //   this.approvalPendingSection = true;
    //   this.approvedSection = false;
    //   this.allSection = false;
    //   this.activationPendingSection = false;
    //   this.rejectedSection = false;
    //   if (this.allApprovalPendingCustomerData.length == 0) {
    //     this.approvalPendingCustomer();
    //   }
    // }
    if (data == Constants.normalText.activationPending) {
      this.activationPendingSection = true;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSection = false;
      this.rejectedSection = false;
      if (this.allActivationPendingCustomerData.length == 0) {
        this.activationPendingCustomer();
      }
    }
    if (data == Constants.normalText.rejected) {
      this.rejectedSection = true;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSection = false;
      this.activationPendingSection = false;
      if (this.allRejectedCustomerData.length == 0) {
        this.rejectedCustomer();
      }
    }
  }

  isActive(type, item) {
    return this.selected[type] === item;
  }

  selectAmendMenu(type?, item?, $event?) {
    this.selected[type] = (this.selected[type] === item ? null : item);
    $event ? $event.stopPropagation() : null;
    this.customerNavigationFromSubMenuAmendment(item);
  }

  isActiveAmend(type, item) {
    return this.selected[type] === item;
  }

  customerNavigationFromSubMenuAmendment(data) {
    if (data == Constants.normalText.basicDetails) {
      this.basicDetailsSection = true;
      this.otherDetailsSection = false;
      this.fileSection = false;
    }
    if (data == Constants.normalText.otherDetails) {
      this.otherDetailsSection = true;
      this.basicDetailsSection = false;
      this.fileSection = false;
    }
    if (data == Constants.normalText.files) {
      this.otherDetailsSection = true;
      this.basicDetailsSection = false;
      this.fileSection = false;
    }

  }

  getAllCustomer() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode?.encrypt(),
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allCustomerData = data?.custMaster;
      }
    })
  }

  approvedCustomer() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'Y',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        apprStatus: 'Y',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovedCustomerData = data?.custMaster;
      }
    })
  }

  approvalPendingCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'N',
        activStatus: 'N',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    } else {
      if(this.user?.userRole[0]?.id == 2){
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'Y',
          activStatus: 'N',
          roleId: this.user?.userRole[0]?.id,
          loginFromApp: false
        }
      }else{
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'N',
          activStatus: 'N',
          roleId: this.user?.userRole[0]?.id,
          loginFromApp: false
        }
      }
      
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovalPendingCustomerData = data?.custMaster;
      }
    })
  }

  activationPendingCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'Y',
        activStatus: 'N',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        apprStatus: 'Y',
        activStatus: 'N',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allActivationPendingCustomerData = data?.custMaster;
      }
    })
  }

  rejectedCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        activStatus: 'N',
        apprStatus: 'R',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        activStatus: 'N',
        apprStatus: 'R',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allRejectedCustomerData = data?.custMaster;
      }
    })
  }

  raiseAmendmentInitiation() {
    if(this.user?.userTypeId == 3){
      // let validContact = this.commonservice.regexForNumericandDecimalNumber(this.phoneNoCustAmendment);
      // let validEmail = this.commonservice.regexForEmail(this.emailIdCustAmendment);
      if(!this.salesOfficerAmendment){
        Swal.fire(alertPopup.salesOfficerEmpty);
      } 
      else if(!this.subCustAmendment){
        Swal.fire(alertPopup.subjectEmpty);
      }
      else if(!this.descriptionCustAmendment){
        Swal.fire(alertPopup.emptyDescription);
      }
      
      else{
        let payload = {
          customerName: this.custProfileData?.soldToPartyUserName,
          regionId: this.custProfileData?.soldToPartyRegionId,
          soEmail:  this.selectedSoEle?.emailId,
          soPhoneNo: this.selectedSoEle?.contact,
          subject: this.subCustAmendment,
          description: this.descriptionCustAmendment,
          customerAddress: this.custProfileData?.soldToPartyAddress,
          customerEmail: this.custProfileData?.soldToPartyEmail,
          customerPhone: this.custProfileData?.soldToPartyPhone,
          customerRegion: this.custProfileData?.soldToPartyRegion,
          soName: this.selectedSoEle?.soName,
          soAddress: this.selectedSoEle?.address,
          soRegion: this.custProfileData?.soldToPartyRegion,
          shipToPartyCode: null,
          shipToPartyName: null,
          shipToPartyEmail: null,
          shipToPartyPhone: null,
          shipToPartyAddress: null,
          shipToPartyRegion: null,
          customerCode: this.customerCode?.encrypt() ? this.customerCode.encrypt(): this.user?.userId,
          salesOfficerCode: this.user?.userId,
          loggedInUserId: this.user?.id,
          uploadFileIds: [this.uploadDataRes?.id],
          loginFromApp: false
        }
    
        this.loaderService.show();
        this.customerService.raiseAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
    }
   
    if(this.user?.userTypeId == 2){
      // let validContact = this.commonservice.regexForNumericandDecimalNumber(this.phoneNoCustAmendment);
      // let validEmail = this.commonservice.regexForEmail(this.emailIdCustAmendment);
      
      if(!this.salesOfficerAmendment){
        Swal.fire(alertPopup.salesOfficerEmpty);
      }
      else if(!this.customerCodeControl.value){
        Swal.fire(alertPopup.custCodeEmpty);
      }
      else if(!this.subCustAmendment){
        Swal.fire(alertPopup.subjectEmpty);
      }
      else if(!this.descriptionCustAmendment){
        Swal.fire(alertPopup.emptyDescription);
      }
      else{
        let payload = {
          customerName: this.custProfileData?.soldToPartyUserName,
          regionId: this.custProfileData?.soldToPartyRegionId,
          soEmail:  this.selectedSoEle?.emailId,
          soPhoneNo: this.selectedSoEle?.contact,
          subject: this.subCustAmendment,
          description: this.descriptionCustAmendment,
          customerAddress: this.custProfileData?.soldToPartyAddress,
          customerEmail: this.custProfileData?.soldToPartyEmail,
          customerPhone: this.custProfileData?.soldToPartyPhone,
          customerRegion: this.custProfileData?.soldToPartyRegion,
          soName: this.selectedSoEle?.soName,
          soAddress: this.selectedSoEle?.address,
          soRegion: this.custProfileData?.soldToPartyRegion,
          shipToPartyCode: null,
          shipToPartyName: null,
          shipToPartyEmail: null,
          shipToPartyPhone: null,
          shipToPartyAddress: null,
          shipToPartyRegion: null,
          customerCode: this.customerCode?.encrypt() ? this.customerCode.encrypt(): this.user?.userId,
          salesOfficerCode: this.user?.userId,
          loggedInUserId: this.user?.id,
          uploadFileIds: [this.uploadDataRes?.id],
          loginFromApp: false
        }
    
        this.loaderService.show();
        this.customerService.raiseAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
    }

  }

  backToAmendment(){
    window.location.reload();
  }

  fileUploadAmendment() {
    if (!this.file) {
      Swal.fire(alertPopup.uploadFile);
    } else {
      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('file', this.file, this.file.name);
      }

      let fileUploadReq = {
        loggedInUserId: this.user?.userId
      }

      Object.entries(fileUploadReq).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.uploadFileAmendment(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data?.status == 1) {
          this.uploadDataRes = data;
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  discard() {
    this.custDetails = true;
    this.amendmentDetails = false;
  }

  raiseNowAmendmentForCustomer() {

    let validEmail = this.commonService.regexForEmail(this.emailCustomerAmendment);

    if (!validEmail) {
      Swal.fire(alertPopup.validmail);
    } else {
      let payload = {
        oldCompanyName: this.individualCustomerData?.organizationName,
        newCompanyName: this.companyNameCustomerAmendment,
        oldPhoneNo: this.individualCustomerData?.contact,
        newPhoneNo: this.phoneCustomerAmendment,
        oldEmail: this.individualCustomerData?.emailId,
        newEmail: this.emailCustomerAmendment,
        oldContactAddress: this.individualCustomerData?.address,
        newContactAddress: this.addressCustomerAmendment,
        oldCountry: this.individualCustomerData?.country,
        newCountry: this.countryCustomerAmendment,
        oldFaxNo: this.individualCustomerData?.fax,
        newFaxNo: this.faxCustomerAmendment,
        loggedinUserId: this.user.userId,
        loginFromApp: false
      }

      this.loaderService.show();
      this.customerService.raiseCustomerAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data) {
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            })
            this.custDetails = true;
            this.amendmentDetails = false;
            this.getDetailIndividualCustomer();
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            })
          }
        }
      })

    }

  }

  viewDetails(item) {
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    this.rejectedPanelSO = false;
    this.rejectedPanelRM = false;
    this.rejectedPanelPH = false;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })


    if (this.user?.userRole[0]?.id != 4) {
      this.getBusinessOfficerData(item?.id.toString().encrypt());
    }

    if (this.regionArr.length == 0) {
      this.getRegion();
    }

    if (this.custType.length == 0) {
      this.getCustomerType()
    }
  }

  viewDetailsRejected(item){
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    this.rejectedPanelSO = true;
    this.rejectedPanelRM = true;
    this.rejectedPanelPH = true;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());
  }

  getBusinessOfficerData(custId) {
    let payload = {
      id: custId,
      userId: this.user.userId,
      loginFromApp: false
    }

    this.loaderService.show();
    this.customerService.businessOfficerData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.onboardingData[0] != null) {
        this.individualBusinessOfiicerData = data?.onboardingData[0];
      }
    })

  }

  getRegion() {
    this.loaderService.show();
    this.common.regionMaster().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.regionArr = data;
      }
    })
  }

  getCustomerType() {
    this.loaderService.show();
    this.common.customerType().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.userType != null) {
        data?.userType.forEach(eleCustType => {
          if (eleCustType?.id == 2 || eleCustType?.id == 3) {
            this.custType.push(eleCustType);
          }
        })
      }
    })
  }

  goBackOfficersData() {
    this.allViewForOfficer = true;
    this.officersView = false;
  }
  
  amendForOfficers() {
    this.mainOfficersData = true;
  }

  goBackPrevious() {
    this.mainOfficersData = false;
  }

  activateCustomer() {
    // this.dialog.open(CustomerActivationPopupComponent, { disableClose: true, width: '30%', height: '33%' });
  }

  sendForApproval() {
    if (!this.onboardingCustType) {
      Swal.fire(alertPopup.custType);
    }
    else if (!this.onboardingRegion) {
      Swal.fire(alertPopup.region);
    }
    else if (!this.onboardingCustCode) {
      Swal.fire(alertPopup.customerCode);
    }
    else if (!this.salesOfficerRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('file', this.file, this.file.name);
      }

      let sendForApprovalSO = {
        id: this.individualCustomer?.id,
        soRemarks: this.salesOfficerRemarks,
        userId: this.user?.userId,
        customerTypeId: this.onboardingCustType,
        customerCode: this.onboardingCustCode,
        regionId: this.onboardingRegion,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      Object.entries(sendForApprovalSO).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.saveSOData(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }

  }

  rejectRegionalSo(){
    if (!this.salesOfficerRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {

      let formData = new FormData();

      let sendForApprovalSO = {
        id: this.individualCustomer?.id,
        soRemarks: this.salesOfficerRemarks,
        userId: this.user?.userId,
        // customerTypeId: this.onboardingCustType,
        // customerCode: this.onboardingCustCode,
        // regionId: this.onboardingRegion,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: false
      }

      Object.entries(sendForApprovalSO).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.saveSOData(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data?.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }


  approvalRM() {
  if (!this.regionalMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        rmRemarks: this.regionalMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  rejectRM() {
    if (!this.regionalMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        rmRemarks: this.regionalMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: false
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  approvalHM() {
    if (!this.headMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        customerCode: this.individualCustomer?.customerCode?.encrypt(),
        regionId: this.individualBusinessOfiicerData?.regionId,
        faRemarks: this.headMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  rejectHM() {
    if (!this.headMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        customerCode: this.individualCustomer?.customerCode?.encrypt(),
        regionId: this.individualBusinessOfiicerData?.regionId,
        faRemarks: this.headMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: false
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  onFileChangeTarget(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    this.fileArr = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  removeFile(){
    this.fileArr = [];
    this.myInputVariable.nativeElement.value = "";
  }


}
