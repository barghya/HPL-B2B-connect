import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AmendmentReqComponent } from './amendment-req.component';

describe('AmendmentReqComponent', () => {
  let component: AmendmentReqComponent;
  let fixture: ComponentFixture<AmendmentReqComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AmendmentReqComponent]
    });
    fixture = TestBed.createComponent(AmendmentReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
