import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerAmendmentComponent } from './customer-amendment.component';

describe('CustomerAmendmentComponent', () => {
  let component: CustomerAmendmentComponent;
  let fixture: ComponentFixture<CustomerAmendmentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CustomerAmendmentComponent]
    });
    fixture = TestBed.createComponent(CustomerAmendmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
