import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { LoaderService } from 'src/app/utils/loader-service';
import { AmendmentActionPopupComponent } from '../amendment-action-popup/amendment-action-popup.component';
import { PreviousAmendmentDetailsComponent } from '../previous-amendment-details/previous-amendment-details.component';
import { DownloadService } from 'src/app/services/download/download.service';
import { saveAs } from 'file-saver';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-customer-amendment',
  templateUrl: './customer-amendment.component.html',
  styleUrls: ['./customer-amendment.component.css']
})
export class CustomerAmendmentComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  searchAmendmentData: any[] = [];
  attachmentFile: any;
  attachmentFileName: any;
  pageNo = 1;

  timePeriod = 0;
  timePeriodList : any [] = [];

  statusSelected = 'All';
  statusList = [    
    {id:1, value:'completed', label:'Completed'},
    {id:2, value:'initiated', label:'Initiated'},
    {id:3, value:'rejected', label:'Rejected'},
    {id:4, value:'submitted', label:'Submitted'},
    {id:5, value:'inprogress', label:'In Progress'},
  ]
  actionTakenBy = 'All';
  actionList = [    
    {id:1, value:'loremipsum1', label:'Lorem Ipsum 1'},
    {id:2, value:'loremipsum2', label:'Lorem Ipsum 2'},
    {id:3, value:'loremipsum3', label:'Lorem Ipsum 3'},
  ]


  constructor(private downloadService: DownloadService, private dialog: MatDialog, private loaderService: LoaderService, private customerService: CustomerService){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.getAmendmentData();
    this.filterValidation();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }
  
  getAmendmentData(){
    let payload = {
      startDate: null,
      endDate: null,
      customerCode: null,
      statusId: null,
      regionIds: this.user?.regionId,
      loggedInUserId: this.user?.id
    }

    this.loaderService.show();
    this.customerService.searchAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data!= null){
        this.searchAmendmentData = data;
        // this.searchAmendmentData.forEach(element => {
        //   if(element?.attachement){
        //     element?.attachement.forEach(eleFile => {
        //         this.attachmentFile = eleFile?.filePath;
        //     })
        //   }
        // })
      }
    })

  }

  downloadItem(item){
    this.attachmentFile = item?.attachement[0]?.filePath;
    this.attachmentFileName = item?.attachement[0]?.name;
  }

  actionForAmendment(item){
    this.dialog.open(AmendmentActionPopupComponent, { disableClose: true, width: '50%', height: '70%', data: item });
  }

  viewDetailsForIndividualAmendment(item){
    let payload = {
      id: item?.id
    }

    this.loaderService.show();
    this.customerService.customerAmendmentData(payload).pipe(takeUntil(this.destroyed$)).subscribe(dataAmendment => {
      if(dataAmendment && dataAmendment!= null){
        this.dialog.open(PreviousAmendmentDetailsComponent, { disableClose: true, width: '70%', height: '80%', data: dataAmendment });
      }
    })
  }
  
  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }


}
