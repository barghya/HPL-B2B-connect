import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-status-donut-chart',
  templateUrl: './payment-status-donut-chart.component.html',
  styleUrls: ['./payment-status-donut-chart.component.css']
})
export class PaymentStatusDonutChartComponent implements OnInit {

  @Input() inputDataPaymentStatus: any;


  ngOnInit(): void {
    this.praparedPaymentStatusData();
  }

  praparedPaymentStatusData(){
    this.inputDataPaymentStatus = {
      tooltip: {
        trigger: 'item',
        formatter: '{c} ({d}%)',
      },
      legend: {
        top: '15%',
        left: 'center'
      },
      series: [
        {
          type: 'pie',
          radius: ['50%', '30%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          color: ['#754827','#EE756D','#FFD2D2','#E05F3B'],
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: this.inputDataPaymentStatus,
        }
      ]
    }
  }


}
