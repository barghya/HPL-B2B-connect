import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentStatusDonutChartComponent } from './payment-status-donut-chart.component';

describe('PaymentStatusDonutChartComponent', () => {
  let component: PaymentStatusDonutChartComponent;
  let fixture: ComponentFixture<PaymentStatusDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentStatusDonutChartComponent]
    });
    fixture = TestBed.createComponent(PaymentStatusDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
