import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { UserManagementService } from 'src/app/services/user-management/user-management.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-edit-popup',
  templateUrl: './user-edit-popup.component.html',
  styleUrls: ['./user-edit-popup.component.css']
})
export class UserEditPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  userFirstName: any;
  userLastName: any;
  userEmpCode: any;
  userEmailId: any;
  userContactNo: any;
  userAddress: any;
  userRegion: any;
  userRole: any;

  

  constructor(private commonservice: CommonService, private userService: UserManagementService, private loaderService: LoaderService, private dialogRef: MatDialogRef<UserEditPopupComponent>, @Inject(MAT_DIALOG_DATA) public userData: any){}

  ngOnInit(): void {
    this.setUserData();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  setUserData(){
    this.userFirstName = this.userData?.firstName,
    this.userLastName = this.userData?.lastName,
    this.userEmpCode = this.userData?.empCode,
    this.userEmailId = this.userData?.emaiId,
    this.userContactNo = this.userData?.contact,
    this.userAddress = this.userData?.address
    this.userRegion = this.userData?.region,
    this.userRole = this.userData?.role
  }

  editUser(){

    let validEmail = this.commonservice.regexForEmail(this.userEmailId);
    let validContact = this.commonservice.regexForNumericandDecimalNumber(this.userContactNo);

   if(!this.userEmailId){
      Swal.fire(alertPopup.mailEmpty);
    }
    else if(!validEmail){
      Swal.fire(alertPopup.validmail);
    }
    else if(!this.userContactNo){
      Swal.fire(alertPopup.contactNoEmpty);
    }
    else if(validContact){
      Swal.fire(alertPopup.validContact);
    }
    else if(!this.userAddress){
      Swal.fire(alertPopup.addressEmpty);
    }else{
      let payload = {
        userId: this.userData?.user.id,
        employeeId: this.userData?.employeeId,
        emaiId: this.userEmailId,
        contact: this.userContactNo,
        address: this.userAddress,
        userTypeId: 1,
        loggedInUserId: this.user?.id
    }
    this.loaderService.show();
    this.userService.editUser(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data.status == 1) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: data.message,
          showCancelButton: false,
          allowEnterKey: false,
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: data.message,
          showCancelButton: false,
          allowEnterKey: false,
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        })
      }
    })
  }
  }

  closePopup(){
    this.dialogRef.close();
  }


}
