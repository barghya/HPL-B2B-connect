import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserEditPopupComponent } from './user-edit-popup.component';

describe('UserEditPopupComponent', () => {
  let component: UserEditPopupComponent;
  let fixture: ComponentFixture<UserEditPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserEditPopupComponent]
    });
    fixture = TestBed.createComponent(UserEditPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
