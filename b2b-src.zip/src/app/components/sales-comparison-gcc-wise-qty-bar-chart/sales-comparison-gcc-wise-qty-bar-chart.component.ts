import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-comparison-gcc-wise-qty-bar-chart',
  templateUrl: './sales-comparison-gcc-wise-qty-bar-chart.component.html',
  styleUrls: ['./sales-comparison-gcc-wise-qty-bar-chart.component.css']
})
export class SalesComparisonGccWiseQtyBarChartComponent implements OnInit {

  @Input() inputDataSalesComparisonGccWiseQty: any;

  ngOnInit(): void {
    this.praparedinputDataSalesComparisonGccWiseQty();
  }

  praparedinputDataSalesComparisonGccWiseQty(){
    this.inputDataSalesComparisonGccWiseQty = {
      grid:{left:'20%', width:'67%', height:'55%', top:'10%'},
      // legend: {
      //   top: 'bottom',
      // },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        textStyle: {
          fontSize: 12,
        },
        appendToBody: true
        // position: {right: 80, bottom: 20}
      },
      dataset: {
        source: this.inputDataSalesComparisonGccWiseQty?.data
      },
      xAxis: { 
        axisLabel: {
          rotate: 70,
        },
        type: 'category' },
      yAxis: {
        splitLine: {
          show: false
        },
        axisLabel: {
          formatter: function (value) {
            // if (value >= 0 && value < 1000) {
            //   value;
            // }
            // if (value >= 1000 && value < 100000) {
            //   value = value / 1000 + "K";
            // }
            // if (value >= 100000 && value < 1000000) {
            //   value = value / 1000000 + "M";
            // }
            // if (value >= 1000000) {
            //   value = value / 1000000000 + "B";
            // }
            if (value >= 0 && value < 1000) {
              value;
            }
            if (value >= 100000 && value < 10000000) {
              value = value / 100000 + "L";
            }
            if (value >= 10000000) {
              value = value / 10000000 + "Cr";
            }
            return value;
          }
        }
      },
      series: this.inputDataSalesComparisonGccWiseQty?.color
    };
    
  }

}
