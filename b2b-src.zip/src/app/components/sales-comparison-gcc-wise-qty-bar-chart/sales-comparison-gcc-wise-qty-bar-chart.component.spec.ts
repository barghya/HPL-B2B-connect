import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesComparisonGccWiseQtyBarChartComponent } from './sales-comparison-gcc-wise-qty-bar-chart.component';

describe('SalesComparisonGccWiseQtyBarChartComponent', () => {
  let component: SalesComparisonGccWiseQtyBarChartComponent;
  let fixture: ComponentFixture<SalesComparisonGccWiseQtyBarChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SalesComparisonGccWiseQtyBarChartComponent]
    });
    fixture = TestBed.createComponent(SalesComparisonGccWiseQtyBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
