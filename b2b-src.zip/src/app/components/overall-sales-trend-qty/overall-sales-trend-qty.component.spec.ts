import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverallSalesTrendQtyComponent } from './overall-sales-trend-qty.component';

describe('OverallSalesTrendQtyComponent', () => {
  let component: OverallSalesTrendQtyComponent;
  let fixture: ComponentFixture<OverallSalesTrendQtyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OverallSalesTrendQtyComponent]
    });
    fixture = TestBed.createComponent(OverallSalesTrendQtyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
