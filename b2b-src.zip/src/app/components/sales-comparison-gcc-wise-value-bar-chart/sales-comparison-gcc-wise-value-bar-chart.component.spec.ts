import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesComparisonGccWiseValueBarChartComponent } from './sales-comparison-gcc-wise-value-bar-chart.component';

describe('SalesComparisonGccWiseValueBarChartComponent', () => {
  let component: SalesComparisonGccWiseValueBarChartComponent;
  let fixture: ComponentFixture<SalesComparisonGccWiseValueBarChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SalesComparisonGccWiseValueBarChartComponent]
    });
    fixture = TestBed.createComponent(SalesComparisonGccWiseValueBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
