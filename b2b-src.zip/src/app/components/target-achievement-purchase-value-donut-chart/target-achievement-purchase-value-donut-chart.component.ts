import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-target-achievement-purchase-value-donut-chart',
  templateUrl: './target-achievement-purchase-value-donut-chart.component.html',
  styleUrls: ['./target-achievement-purchase-value-donut-chart.component.css']
})
export class TargetAchievementPurchaseValueDonutChartComponent implements OnInit {

  @Input() inputDatapurchaseManagementCountDetails: any;

  constructor() {}

  ngOnInit(): void {
    this.praparedtargetAchvPurValueDonutChartData();
  }

  praparedtargetAchvPurValueDonutChartData(){
    this.inputDatapurchaseManagementCountDetails = {
      tooltip: {
        trigger: 'item',
        formatter: '{d}'
      },
      legend: {
        top: '15%',
        left: 'center'
      },
      series: [
        {
          type: 'pie',
          radius: ['50%', '30%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          color: ['#754827','#EE756D','#FFD2D2', '#BB8C6B'],
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: this.inputDatapurchaseManagementCountDetails?.salesChart,
        }
      ]
    }

  }


}
