import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TargetAchievementPurchaseValueDonutChartComponent } from './target-achievement-purchase-value-donut-chart.component';

describe('TargetAchievementPurchaseValueDonutChartComponent', () => {
  let component: TargetAchievementPurchaseValueDonutChartComponent;
  let fixture: ComponentFixture<TargetAchievementPurchaseValueDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TargetAchievementPurchaseValueDonutChartComponent]
    });
    fixture = TestBed.createComponent(TargetAchievementPurchaseValueDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
