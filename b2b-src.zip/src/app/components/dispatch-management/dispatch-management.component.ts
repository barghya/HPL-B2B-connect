import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeliveryInfoDetailsComponent } from '../delivery-info-details/delivery-info-details.component';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { CommonService } from 'src/app/utils/common-service';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';
import * as moment from 'moment';
import { AcknowledgementPopupComponent } from '../acknowledgement-popup/acknowledgement-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { DispatchChartDetailsPopupComponent } from '../dispatch-chart-details-popup/dispatch-chart-details-popup.component';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { DownloadService } from 'src/app/services/download/download.service';
import { ViewHistoricalPopupComponent } from '../view-historical-popup/view-historical-popup.component';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-dispatch-management',
  templateUrl: './dispatch-management.component.html',
  styleUrls: ['./dispatch-management.component.css']
})
export class DispatchManagementComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  tabLabels = Constants.normalText.dispatchDetails;
  selectedIndex: number;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  dispatchDetails: any;
  dispatchRecentDelivery: any;
  allDispatchDetailsData: any[] = [];
  pageNo = 1;
  urlsafe: SafeResourceUrl;
  payloadDispatch: any;
  payloadRecentDelivery: any;
  payloadAllDispatchDetails: any;
  payloadDownloadDispatchStatusQtyReport: any;
  payloadDownloadDispatchDeliveryTimeReport: any;
  payloadDownloadTableData: any;
  dispatchSearch: any;
  timePeriod = 0;
  // timePeriodList : any [] = [];
  timePeriodList = [    
    {id:1, label:'MTD', value: 0},
    {id:2, label:'YTD', value: 1},
    {id: 3, label: 'Prv Month', value: 2 },
  ]
  customerType:any = 'Customer';
  getTotalDispatchDetails: any;
  getPendingDispatchDetails: any;
  getInTransitDetails: any;
  getTotalPODAckDetails: any;
  getPODAckDetails: any;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');



  constructor(private downloadService: DownloadService, private router: Router, private modalService: NgbModal, private commonService: CommonService, private dialog: MatDialog, private loaderService: LoaderService, private dispatchService: DispatchManagementService, private sanitizer: DomSanitizer) { 
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalDispatch')) {
      this.getTotalDispatchDetails = this.router.getCurrentNavigation().extras.state['dataTotalDispatch'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTilePendingDispatch')) {
      this.getPendingDispatchDetails = this.router.getCurrentNavigation().extras.state['dataPendingDispatch'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileInTransitOrder')) {
      this.getInTransitDetails = this.router.getCurrentNavigation().extras.state['dataInTransit'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalPodAck')) {
      this.getTotalPODAckDetails = this.router.getCurrentNavigation().extras.state['dataTotalPODAck'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTilePodAck')) {
      this.getPODAckDetails = this.router.getCurrentNavigation().extras.state['dataPODAck'];
    }
  }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.getDispatchData();
    this.getRecentDelivery();
    this.fetchTableDetails();

    if(sessionStorage.getItem('dispatchFilter')){
      this.timePeriod = JSON.parse(sessionStorage.getItem('dispatchFilter'));
    }

    if(this.getTotalDispatchDetails == undefined && this.getPendingDispatchDetails == undefined && this.getInTransitDetails == undefined && this.getTotalPODAckDetails == undefined && this.getPODAckDetails == undefined){
      this.allDispatchDetails();
    }

    // this.filterValidation();

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  fetchTableDetails(){
    if(this.getTotalDispatchDetails?.state?.callFrom == "Total Dispatch"){
     this.totalDispatchOrder();
    }

    if(this.getPendingDispatchDetails?.state?.callFrom == "Pending Dispatch"){
     this.toBeDispatchOrder();
    }

    if(this.getInTransitDetails?.state?.callFrom == "In Transit"){
      this.inTransitDispatchOrder();
    }

    if(this.getTotalPODAckDetails?.state?.callFrom == "Total POD ACK"){
      this.podAckTotalDispatchOrder();
    }

    if(this.getPODAckDetails?.state?.callFrom == "POD ACK"){
      this.podAckPendingDispatchOrder();
    }

  }


  getDispatchData() {
    if(sessionStorage.getItem('dispatchFilter')){
      this.timePeriod = JSON.parse(sessionStorage.getItem('dispatchFilter'));
    }else{
      this.timePeriod;
    }
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDispatch = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchCountDetails(this.payloadDispatch).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data.dispatchOrders != null) {
          this.dispatchDetails = data?.dispatchOrders[0]?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDispatch = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchCountDetails(this.payloadDispatch).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data.dispatchOrders != null) {
          this.dispatchDetails = data?.dispatchOrders[0]?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadDispatch = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDispatch = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchCountDetails(this.payloadDispatch).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data.dispatchOrders != null) {
          this.dispatchDetails = data?.dispatchOrders[0]?.entries[0];
        }
      })
    }
  }

  searchDispatch(){
   
    if (this.tabLabels == Constants.normalText.totalDispatchOrder) {
      this.allDispatchDetailsForIndividualTile(Constants.normalText.tdo);
    }
    else if (this.tabLabels == Constants.normalText.toBeDispatchedOrder) {
      this.allDispatchDetailsForIndividualTile(Constants.normalText.tbdo);
    }
    else if (this.tabLabels == Constants.normalText.inTransitOrder) {
      this.allDispatchDetailsForIndividualTile(Constants.normalText.ito);
    }
    else if (this.tabLabels == Constants.normalText.podAckTotalOrder) {
      this.allDispatchDetailsForIndividualTile(Constants.normalText.pat);
    }
    else if (this.tabLabels == Constants.normalText.podAckPendingOrder) {
      this.allDispatchDetailsForIndividualTile(Constants.normalText.pap);
    }
  }

  getRecentDelivery() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadRecentDelivery = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadRecentDelivery = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.recentDeliveryDispatchDetails(this.payloadRecentDelivery).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.dispatchRecentDelivery = data?.entries;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadRecentDelivery = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadRecentDelivery = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.recentDeliveryDispatchDetails(this.payloadRecentDelivery).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.dispatchRecentDelivery = data?.entries;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadRecentDelivery = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadRecentDelivery = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadRecentDelivery = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadRecentDelivery = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: 2,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.recentDeliveryDispatchDetails(this.payloadRecentDelivery).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.dispatchRecentDelivery = data?.entries;
        }
      })
    }
  }


  viewDeliveryInfoDetails(item) {
    let url = this.commonService.appendUrl(ApiEndPoints.urls.individualTripDetailsUrl, item.tripId);
    this.loaderService.show();
    this.dispatchService.individualTripDetails(url).pipe(takeUntil(this.destroyed$)).subscribe(dataIndividualTripDetails => {
      if (dataIndividualTripDetails && dataIndividualTripDetails.entries[0]) {
        this.dialog.open(DeliveryInfoDetailsComponent, { disableClose: true, width: '50%', height: '87%', data: dataIndividualTripDetails.entries[0] });
      }
    })

  }

  allDispatchDetails() {
    let code = Constants.normalText.tdo;
    this.allDispatchDetailsForIndividualTile(code);
  }

  allDispatchDetailsForIndividualTile(codeData) {
    this.allDispatchDetailsData = [];
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.allDispatchDetailsData = data?.entries;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.allDispatchDetailsData = data?.entries;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          text: this.dispatchSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.allDispatchDetailsData = data?.entries;
        }
      })
    }

  }

  informationChange(event: any) {
    this.selectedIndex = event;
    this.pageNo = 1;
  }

  totalDispatchOrder() {
    this.selectedIndex = 1;
    this.dispatchSearch = null;
    this.tabLabels = Constants.normalText.totalDispatchOrder;
    let code = Constants.normalText.tdo;
    this.allDispatchDetailsForIndividualTile(code);
  }

  toBeDispatchOrder() {
    this.selectedIndex = 1;
    this.dispatchSearch = null;
    this.tabLabels = Constants.normalText.toBeDispatchedOrder;
    let code = Constants.normalText.tbdo;
    this.allDispatchDetailsForIndividualTile(code);
  }

  inTransitDispatchOrder() {
    this.selectedIndex = 1;
    this.dispatchSearch = null;
    this.tabLabels = Constants.normalText.inTransitOrder;
    let code = Constants.normalText.ito;
    this.allDispatchDetailsForIndividualTile(code);
  }

  podAckTotalDispatchOrder() {
    this.selectedIndex = 1;
    this.dispatchSearch = null;
    this.tabLabels = Constants.normalText.podAckTotalOrder;
    let code = Constants.normalText.pat;
    this.allDispatchDetailsForIndividualTile(code);
  }

  podAckPendingDispatchOrder() {
    this.selectedIndex = 1;
    this.dispatchSearch = null;
    this.tabLabels = Constants.normalText.podAckPendingOrder;
    let code = Constants.normalText.pap;
    this.allDispatchDetailsForIndividualTile(code);
  }

  downloadDispatchStatusQtyReport() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.downloadDispatchGraphReport(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Dispatch_Status_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.downloadDispatchGraphReport(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Dispatch_Status_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDownloadDispatchStatusQtyReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DQ",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.downloadDispatchGraphReport(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Dispatch_Status_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }


  downloadDispatchDeliveryTimeReport() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.downloadDispatchGraphReport(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Dispatch_Delivery_Time_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.downloadDispatchGraphReport(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Dispatch_Delivery_Time_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDownloadDispatchDeliveryTimeReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          toggleCode: "DT",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.downloadDispatchGraphReport(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Dispatch_Delivery_Time_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  acknowledge(item) {
    this.dialog.open(AcknowledgementPopupComponent, { disableClose: true, width: '50%', height: '96%', data: item });
  }

  viewHistory(content: any, item) {
    let payload = {
      trip_id: item.tripId,
      feed_unique_id: "",
      tracking_only: true
    }
    this.loaderService.show();
    this.dispatchService.vehicleViewInMap(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.urlsafe = this.sanitizer.bypassSecurityTrustResourceUrl(data?.link);
        this.modalService.open(content, {
          windowClass: 'modal-holder',
          backdrop: 'static',
          size: 'editchart-popup',
          keyboard: false
        });

      }
    })
  }

  dismissGradModal(modal: any) {
    modal.dismiss('Cross click');
  }

  downloadDataForIndividualTile(codeData, fileName) {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.downloadTableDataDispatch(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.downloadTableDataDispatch(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }  
      else if(this.region){
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: codeData,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.downloadTableDataDispatch(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadTableDataDispatch() {
    if (this.tabLabels == Constants.normalText.totalDispatchOrder) {
      this.downloadDataForIndividualTile(Constants.normalText.tdo, "Total_Dispatch_Order_");
    }
    else if (this.tabLabels == Constants.normalText.toBeDispatchedOrder) {
      this.downloadDataForIndividualTile(Constants.normalText.tbdo, "To_be_Dispatch_Order_");
    }
    else if (this.tabLabels == Constants.normalText.inTransitOrder) {
      this.downloadDataForIndividualTile(Constants.normalText.ito, "In_Transit_Order_");
    }
    else if (this.tabLabels == Constants.normalText.podAckTotalOrder) {
      this.downloadDataForIndividualTile(Constants.normalText.pat, "Total_POD_Acknowledged_");
    }
    else if (this.tabLabels == Constants.normalText.podAckPendingOrder) {
      this.downloadDataForIndividualTile(Constants.normalText.pap, "POD_Acknowledgement_Pending_");
    }
  }

  monthIntervalData(evt){
    sessionStorage.setItem('dispatchFilter', evt);

    sessionStorage.removeItem('callFromTileTotalDispatch');
    sessionStorage.removeItem('callFromTilePendingDispatch');
    sessionStorage.removeItem('callFromTileInTransitOrder');
    sessionStorage.removeItem('callFromTileTotalPodAck');
    sessionStorage.removeItem('callFromTilePodAck');

    this.timePeriod = JSON.parse(sessionStorage.getItem('dispatchFilter'));
    this.getDispatchData();
    window.location.reload();
  }

  openDetailsDataPopupForExcel(text){
    if(text == 'chart1'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(DispatchChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.entries }});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(DispatchChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.entries }});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } 
        else if(this.region){
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadDispatchStatusQtyReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DQ",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchStatusQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(DispatchChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.entries }});
          }
        })
      }
    }

    if(text == 'chart2'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(DispatchChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.entries }});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(DispatchChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.entries }});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } 
        else if(this.region){
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadDispatchDeliveryTimeReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: "DT",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
  
        this.loaderService.show();
        this.dispatchService.excelChartTableData(this.payloadDownloadDispatchDeliveryTimeReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(DispatchChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.entries }});
          }
        })
      }
    }
  }

  goBackToHome(){
    this.router.navigate(['/home']).then(success => {
      window.location.reload();
    });
    sessionStorage.removeItem('dispatchFilter');
    sessionStorage.removeItem('complaintFilter');
    sessionStorage.removeItem('salesTimeinterval');
    sessionStorage.removeItem('tabIndex');
    sessionStorage.removeItem('sliderGcc');
  }

  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  openPopupForHistoricalData(){
    this.dialog.open(ViewHistoricalPopupComponent, { disableClose: true, width: '60%', height: '70%'});
  }

}

