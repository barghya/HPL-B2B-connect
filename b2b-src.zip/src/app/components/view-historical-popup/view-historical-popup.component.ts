import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { alertPopup } from 'src/app/utils/alert-popup';
import * as moment from 'moment';
import { CommonApiService } from 'src/app/services/common/common-api.service';
import { LoaderService } from 'src/app/utils/loader-service';
import { Constants } from 'src/app/utils/constants';
import { DownloadService } from 'src/app/services/download/download.service';
import { saveAs } from 'file-saver';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-view-historical-popup',
  templateUrl: './view-historical-popup.component.html',
  styleUrls: ['./view-historical-popup.component.css']
})
export class ViewHistoricalPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  toggleCodeType: any;
  startDateHistorical: any;
  endDateHistorical: any;
  reportTypeList: any[] = [];
  todayDate = moment(new Date()).format('YYYY-MM-DD');
  payloadHistoricalData: any;
  historicalDataList: any[] = [];



  constructor(private downloadService: DownloadService, private loaderService: LoaderService, private commonmService: CommonApiService, private location: Location, private dialogRef: MatDialogRef<ViewHistoricalPopupComponent>) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.reportType();
    if (this.historicalDataList) {
      this.getHistoricalData();
    }
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }


  reportType() {
    if (this.location.path() === '/purchaseManagement') {
      this.reportTypeList = [
        { id: 1, label: 'Total Purchase', value: 'TP' },
        { id: 2, label: 'Confirmed Order', value: 'CO' },
        { id: 3, label: 'Pending Order', value: 'PO' },
      ];
    }

    if (this.location.path() === '/salesOrderManagement') {
      this.reportTypeList = [
        { id: 1, label: 'Total Sales', value: 'TP' },
        // { id: 2, label: 'Confirmed Sales Order', value: 'CO' },
        // { id: 3, label: 'Pending Sales Order', value: 'PO' },
      ];
    }

    if (this.location.path() === '/dispatchManagement' && (this?.user.userTypeId == 2 || this?.user.userTypeId == 3)) {
      this.reportTypeList = [
        { id: 1, label: 'Total Dispatch Orders', value: 'TDO' },
        { id: 2, label: 'Pending Dispatch', value: 'TBDO' },
        { id: 3, label: 'In Transit Orders', value: 'ITO' },
        { id: 3, label: 'POD Ack (Pending)', value: 'PAP' },
      ];
    }

    if (this.location.path() === '/dispatchManagement' && this?.user.userTypeId == 1) {
      this.reportTypeList = [
        { id: 1, label: 'Total Dispatch Orders', value: 'TDO' },
        { id: 2, label: 'Pending Dispatch', value: 'TBDO' },
        { id: 3, label: 'In Transit Orders', value: 'ITO' },
        { id: 3, label: 'Total POD Acknowledged', value: 'PAT' },
      ];
    }

  }

  closePopup() {
    this.dialogRef.close();
  }

  generateHistoricalData() {
    if (!this.toggleCodeType) {
      Swal.fire(alertPopup.toggleCodeTypeSelect);
    }
    if (!this.startDateHistorical) {
      Swal.fire(alertPopup.startDate);
    }
    else if (!this.endDateHistorical) {
      Swal.fire(alertPopup.endDate);
    }
    else if (this.startDateHistorical > this.todayDate) {
      Swal.fire(alertPopup.todayStartDateValidation);
    }
    else if (this.endDateHistorical > this.todayDate) {
      Swal.fire(alertPopup.todayendateValidation);
    }
    else if (this.startDateHistorical > this.endDateHistorical) {
      Swal.fire(alertPopup.dateValidation);
    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadHistoricalData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: [],
            gccCode : this.viewAsGCC,
            userId: this.user?.userId,
            loginFromApp: false,
          }
        } else {
          this.payloadHistoricalData = {
            customerCodes: [],
            payer: [this.user.userId],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            userId: this.user?.userId,
            loginFromApp: false,
          }
        }

        this.loaderService.show();
        this.commonmService.generateHistoricalData(this.payloadHistoricalData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadHistoricalData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: [],
            gccCode : this.viewAsGCC,
            userId: this.user?.userId,
            loginFromApp: false,
          }
        } else {
          this.payloadHistoricalData = {
            customerCodes: [this.user.userId],
            payer: [],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            userId: this.user?.userId,
            loginFromApp: false,
          }
        }

        this.loaderService.show();
        this.commonmService.generateHistoricalData(this.payloadHistoricalData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadHistoricalData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: [],
            userId: this.user?.userId,
            gccCode : this.viewAsGCC,
            userType: "BU",
            loginFromApp: false,
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadHistoricalData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: [],
            userId: this.user?.userId,
            gccCode : this.viewAsGCC,
            userType: "BU",
            loginFromApp: false,
          }
        } else if (this.region) {
          this.payloadHistoricalData = {
            customerCodes: [],
            payer: [],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: [this.region],
            userId: this.user?.userId,
            gccCode : this.viewAsGCC,
            userType: "BU",
            loginFromApp: false
          }
        } else {
          this.payloadHistoricalData = {
            customerCodes: [],
            payer: [],
            toggleCode: this.toggleCodeType,
            startDate: this.startDateHistorical,
            endDate: this.endDateHistorical,
            regions: this.user?.userRegion,
            userId: this.user?.userId,
            gccCode : this.viewAsGCC,
            userType: "BU",
            loginFromApp: false,
          }
        }

        this.loaderService.show();
        this.commonmService.generateHistoricalData(this.payloadHistoricalData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
    }
  }

  getHistoricalData() {
    let payload = {
      userId: this.user?.userId,
      loginFromApp: false,
    }

    this.loaderService.show();
    this.commonmService.downloadHistoricalDataList(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      if (data && data != null) {
        this.loaderService.hide();
        this.historicalDataList = data;
      }
    })
  }

  downloadFile(url, name) {
    this.downloadService.download(url).pipe(takeUntil(this.destroyed$))
      .subscribe(blob => saveAs(blob, name))
  }


}
