import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewHistoricalPopupComponent } from './view-historical-popup.component';

describe('ViewHistoricalPopupComponent', () => {
  let component: ViewHistoricalPopupComponent;
  let fixture: ComponentFixture<ViewHistoricalPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewHistoricalPopupComponent]
    });
    fixture = TestBed.createComponent(ViewHistoricalPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
