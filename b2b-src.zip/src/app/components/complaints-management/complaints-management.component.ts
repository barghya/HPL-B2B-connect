import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ComplaintsManagementService } from 'src/app/services/complaints-management/complaints-management.service';
import { PlaceOrderService } from 'src/app/services/place-order/place-order.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { ComplaintsDownloadPopupComponent } from '../complaints-download-popup/complaints-download-popup.component';
import Swal from 'sweetalert2';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LogisticComplaintsAuditTrailDetailsComponent } from '../logistic-complaints-audit-trail-details/logistic-complaints-audit-trail-details.component';
import * as moment from 'moment';
import { ComplaintChartDetailsPopupComponent } from '../complaint-chart-details-popup/complaint-chart-details-popup.component';
import { Router } from '@angular/router';
import { ReplaySubject, takeUntil } from 'rxjs';
import { TechnicalComplaintDetailsPopupComponent } from '../technical-complaint-details-popup/technical-complaint-details-popup.component';

@Component({
  selector: 'app-complaints-management',
  templateUrl: './complaints-management.component.html',
  styleUrls: ['./complaints-management.component.css']
})
export class ComplaintsManagementComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  selectedIndex: number;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  pageNo = 1;
  isFileUploaded: any;
  fileAdded: boolean;
  file: File = null;
  comSalesAgentEmail: any;
  comSelectedProduct: any;
  productItemsList: any;
  comRemarks: any;
  technicalComplaints: boolean = true;
  logisticsComplaints: boolean = false;
  tabLabels = Constants.normalText.complaintsDetails;
  logisticComplaintsCountDetails: any;
  recentComplaints: any[] = [];
  allLogisticComplaintsDetailsData: any[] = [];
  lineChartDataForAvgResolveTimeLogisticCom: any;
  payloadLineChart: any;
  payloadLogisticsComplaintData: any;
  payloadRecentLogisticComplaints: any;
  payloadAllComplaintsDetailsForIndividualTile: any;
  payloadDownloadAvgResolveTimeLogicalComReport: any;
  payloadDownloadComplaintStatusLogisticsReport: any;
  payloadTechnicalComplaint: any;
  technicalComplaintsDetails: any;
  payloadTechnicalComplaintsLineChart: any;
  technicalComplaintsLineChartDetails: any;
  isCheckedSlider: boolean = false;
  recentTechnicalComSection: boolean = true;
  recentLogisticalComSection: boolean = false;
  payloadRecentTechnicalComplaints: any;
  recentComplaintsTechnical: any [] = [];
  payloadTechnicalComplaintDetails: any;
  technicalComplaintsDetailsTable: any[] = [];
  logisticalComTable: boolean = false;
  technicalComTable: boolean = false;
  payloadAllComplaintsExcelDownload: any;
  technicalComplaintsSearch: any;
  logisticalComplaintsSearch: any;
  timePeriod = 0;
  // timePeriodList : any [] = [];
  //   timePeriodList = [    
  //   {id:1, label:'MTD', value: 0},
  //   {id:2, label:'Last 3 months', value: 3},
  //   {id:3, label:'Last 6 months', value: 6},
  //   {id:4, label:'Last 1 year', value: 12},
  //   {id:4, label:'Last 3 year', value: 36},
  // ]
  timePeriodList = [    
    {id:1, label:'MTD', value: 0},
    {id:2, label:'YTD', value: 1},
    {id: 3, label: 'Prv Month', value: 2 },
  ]
  @ViewChild('myInputFile')
  myInputVariable: ElementRef;
  fileArr: any[] = [];
  getTotalTechCom: any;
  getOpenTechCom: any;
  getLogisticCom: any;
  getOpenLogisticCom: any;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');



  constructor(private router: Router, private commonservice: CommonService, private dialog: MatDialog, private complaintService: ComplaintsManagementService, private loaderService: LoaderService, private placeOrderService: PlaceOrderService) { 
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTechnicalCom')) {
      this.getTotalTechCom = this.router.getCurrentNavigation().extras.state['dataTechnicalCom'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileOpenTechnicalCom')) {
      this.getOpenTechCom = this.router.getCurrentNavigation().extras.state['dataOpenTechnical'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileLogisticalCom')) {
      this.getLogisticCom = this.router.getCurrentNavigation().extras.state['dataLogisticCom'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileOpenLogisticalCom')) {
      this.getOpenLogisticCom = this.router.getCurrentNavigation().extras.state['dataOpenLogistic'];
    }
  }

  ngOnInit(): void {
    this.recentLogisticalComSection = true;
    this.recentTechnicalComSection = false;
    this.isCheckedSlider = true;
    

    if(sessionStorage.getItem('tabIndex') && this.user?.userTypeId == 3){
      this.selectedIndex = 1;
    }
    if(this.user?.userTypeId == 3){
      this.selectedIndex = 1;
    }

    gridUtilObj.resizeGrid();
    if (this.user?.userTypeId == 3) {
      this.fetchProductItems();
    }
    this.logisticComplaintsData();
    this.getTechnicalComplaintData();
    this.getRecentLogisticComplaints();
    this.getRecentTechnicalComplaints();
    this.getLineChartDataForAvgResolveTimeLogisticsCom();
    this.getLineChartDataForAvgResolveTimeTechnicalCom();
    this.fetchTableDetails();

    if(sessionStorage.getItem('complaintFilter')){
      this.timePeriod = JSON.parse(sessionStorage.getItem('complaintFilter'));
    }

    if(this.getTotalTechCom == undefined && this.getOpenTechCom == undefined && this.getLogisticCom == undefined && this.getOpenLogisticCom == undefined){
      this.allTechnicalComplaintsDetails();
      this.allComplaintsDetails();
    }

    // this.filterValidation();

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  fetchTableDetails(){
    if(this.getTotalTechCom?.state?.callFrom == "Technical Com"){
     this.totalTechnicalComplaints();
    }

    if(this.getOpenTechCom?.state?.callFrom == "Open Technical"){
     this.newComplaintsTechnical();
    }

    if(this.getLogisticCom?.state?.callFrom == "Logistic Com"){
      this.totalLogisticsComplaints();
    }

    if(this.getOpenLogisticCom?.state?.callFrom == "Open Logistic"){
      this.newComplaints();
    }

  }

  getRecentLogisticComplaints() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.recentLogisticsComplaints(this.payloadRecentLogisticComplaints).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.recentLogisticsComplaints[0]?.entries != null) {
          this.recentComplaints = data?.recentLogisticsComplaints[0]?.entries;  
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.recentLogisticsComplaints(this.payloadRecentLogisticComplaints).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.recentLogisticsComplaints[0]?.entries != null) {
          this.recentComplaints = data?.recentLogisticsComplaints[0]?.entries;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if(this.region){
        this.payloadRecentLogisticComplaints = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadRecentLogisticComplaints = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: null,
          statusIds: [1, 2, 3],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.recentLogisticsComplaints(this.payloadRecentLogisticComplaints).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.recentLogisticsComplaints[0]?.entries != null) {
          this.recentComplaints = data?.recentLogisticsComplaints[0]?.entries;
        }
      })
    }
  }

  getRecentTechnicalComplaints(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.recentTechnicalComplaints(this.payloadRecentTechnicalComplaints).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.result != null) {
          this.recentComplaintsTechnical = data?.result;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.recentTechnicalComplaints(this.payloadRecentTechnicalComplaints).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.result != null) {
          this.recentComplaintsTechnical = data?.result;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if(this.region){
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: [this.region],
          customerId: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadRecentTechnicalComplaints = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.recentTechnicalComplaints(this.payloadRecentTechnicalComplaints).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.result != null) {
          this.recentComplaintsTechnical = data?.result;
        }
      })
    }
  }

  getLineChartDataForAvgResolveTimeLogisticsCom() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadLineChart = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLineChart = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.avgResolvedTimeLogisticsComLineChartDetails(this.payloadLineChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintLineChartData[0].entries[0] != null) {
          this.lineChartDataForAvgResolveTimeLogisticCom = data?.getLogisticsComplaintLineChartData[0].entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadLineChart = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLineChart = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.avgResolvedTimeLogisticsComLineChartDetails(this.payloadLineChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintLineChartData[0].entries[0] != null) {
          this.lineChartDataForAvgResolveTimeLogisticCom = data?.getLogisticsComplaintLineChartData[0].entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadLineChart = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadLineChart = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadLineChart = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadLineChart = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.avgResolvedTimeLogisticsComLineChartDetails(this.payloadLineChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintLineChartData[0].entries[0] != null) {
          this.lineChartDataForAvgResolveTimeLogisticCom = data?.getLogisticsComplaintLineChartData[0].entries[0];
        }
      })
    }
  }

  getLineChartDataForAvgResolveTimeTechnicalCom() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.avgResolvedTimeTechnicalComLineChartDetails(this.payloadTechnicalComplaintsLineChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintLineChartData[0]?.entries[0] != null) {
          this.technicalComplaintsLineChartDetails = data?.getLogisticsComplaintLineChartData[0]?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.avgResolvedTimeTechnicalComLineChartDetails(this.payloadTechnicalComplaintsLineChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintLineChartData[0]?.entries[0] != null) {
          this.technicalComplaintsLineChartDetails = data?.getLogisticsComplaintLineChartData[0]?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: [this.region],
          customerId: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadTechnicalComplaintsLineChart = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.avgResolvedTimeTechnicalComLineChartDetails(this.payloadTechnicalComplaintsLineChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintLineChartData[0]?.entries[0] != null) {
          this.technicalComplaintsLineChartDetails = data?.getLogisticsComplaintLineChartData[0]?.entries[0];
        }
      })
    }

  }


  logisticComplaintsData() {
    if(sessionStorage.getItem('complaintFilter')){
      this.timePeriod = JSON.parse(sessionStorage.getItem('complaintFilter'));
    }else{
      this.timePeriod;
    }
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadLogisticsComplaintData = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLogisticsComplaintData = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsCountDetails(this.payloadLogisticsComplaintData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintInfo[0]?.entries[0] != null) {
          this.logisticComplaintsCountDetails = data?.getLogisticsComplaintInfo[0]?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadLogisticsComplaintData = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLogisticsComplaintData = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsCountDetails(this.payloadLogisticsComplaintData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintInfo[0]?.entries[0] != null) {
          this.logisticComplaintsCountDetails = data?.getLogisticsComplaintInfo[0]?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadLogisticsComplaintData = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadLogisticsComplaintData = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadLogisticsComplaintData = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadLogisticsComplaintData = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsCountDetails(this.payloadLogisticsComplaintData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintInfo[0]?.entries[0] != null) {
          this.logisticComplaintsCountDetails = data?.getLogisticsComplaintInfo[0]?.entries[0];
        }
      })
    }

  }

  getTechnicalComplaintData(){

    if(sessionStorage.getItem('complaintFilter')){
      this.timePeriod = JSON.parse(sessionStorage.getItem('complaintFilter'));
    }else{
      this.timePeriod;
    }

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.technicalComplaintsCountDetails(this.payloadTechnicalComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.technicalComplaintsDetails = data?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.technicalComplaintsCountDetails(this.payloadTechnicalComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.technicalComplaintsDetails = data?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: [this.region],
          customerId: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadTechnicalComplaint = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.technicalComplaintsCountDetails(this.payloadTechnicalComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.technicalComplaintsDetails = data?.entries[0];
        }
      })
    }

  }
  

  technicalComplaintsData(code){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.technicalComplaintsDetails(this.payloadTechnicalComplaintDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.result != null) {
          this.technicalComplaintsDetailsTable = data?.result;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.technicalComplaintsDetails(this.payloadTechnicalComplaintDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.result != null) {
          this.technicalComplaintsDetailsTable = data?.result;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: [this.region],
          customerId: null,
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadTechnicalComplaintDetails = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          code: code,
          text: this.technicalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.technicalComplaintsDetails(this.payloadTechnicalComplaintDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.result != null) {
          this.technicalComplaintsDetailsTable = data?.result;
        }
      })
    }
  }

 

  technicalClick() {
    this.technicalComplaints = true;
    this.logisticsComplaints = false;
  }

  logisticsClick() {
    this.logisticsComplaints = true;
    this.technicalComplaints = false;
  }

  fetchProductItems() {
    this.loaderService.show();
    this.placeOrderService.productItems().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.productItemsList = data.productList;
      }
    })
  }

  informationChange(event: any) {
    this.selectedIndex = event;
    this.pageNo = 1;
    this.technicalComplaintsSearch = null;
    this.logisticalComplaintsSearch = null;
  }

  onFileChange(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    this.fileArr = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  raiseTechnicalComplaints() {
    let formData = new FormData();
    let validEmail = this.commonservice.regexForEmail(this.comSalesAgentEmail);


    if (this.fileAdded || this.isFileUploaded) {
      formData = new FormData();
      formData.append('fileData', this.file, this.file.name);
    }

    let fileUploadRequest = {
      emailId: this.comSalesAgentEmail,
      product: this.comSelectedProduct,
      remarks: this.comRemarks,
      loggedinUserId: this.user.userId,
      loginFromApp: false
    }

    Object.entries(fileUploadRequest).forEach(([key, value]) => {
      formData.append(key, value);
    });

    if (!this.comSalesAgentEmail) {
      Swal.fire(alertPopup.mailEmpty);
    }
    else if (!validEmail) {
      Swal.fire(alertPopup.validmail);
    }
    else if (!this.comSelectedProduct) {
      Swal.fire(alertPopup.productEmpty);
    } else {
      this.loaderService.show();
      this.complaintService.saveTechnicalComplaint(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data) {
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        }
      })
    }

  }

  raiseLogisticsComplaints() {
    window.open(Constants.url.epodUrl, "_blank");
  }

  allComplaintsDetails() {
    let statusCode = [1, 2, 3];
    let timeCalculation = false;
    this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
  }

  allTechnicalComplaintsDetails() {
    this.logisticalComTable = false;
    this.technicalComTable = true;
    let statusCode = Constants.normalText.technicalComplaints;
    this.technicalComplaintsData(statusCode);
  }

  allComplaintsDetailsForIndividualTile(statusCode, timeCalculation) {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsDetails(this.payloadAllComplaintsDetailsForIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticComplaintDetails[0]?.entries != null) {
          this.allLogisticComplaintsDetailsData = data?.getLogisticComplaintDetails[0]?.entries;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsDetails(this.payloadAllComplaintsDetailsForIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticComplaintDetails[0]?.entries != null) {
          this.allLogisticComplaintsDetailsData = data?.getLogisticComplaintDetails[0]?.entries;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          text: this.logisticalComplaintsSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsDetails(this.payloadAllComplaintsDetailsForIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticComplaintDetails[0]?.entries) {
          this.allLogisticComplaintsDetailsData = data?.getLogisticComplaintDetails[0]?.entries;
        }
      })
    }

  }

  totalTechnicalComplaints() {
    if (this.user?.userTypeId == 3) {
      this.selectedIndex = 2;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = true;
      this.logisticalComTable = false;
      this.tabLabels = Constants.normalText.totalTechnicalComplaints;
      let statusCode = Constants.normalText.technicalComplaints;
      this.technicalComplaintsData(statusCode);
    } else {
      this.selectedIndex = 1;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = true;
      this.logisticalComTable = false;
      this.tabLabels = Constants.normalText.totalTechnicalComplaints;
      let statusCode = Constants.normalText.technicalComplaints;
      this.technicalComplaintsData(statusCode);
    }
  }

  newComplaintsTechnical(){
    if (this.user?.userTypeId == 3) {
      this.selectedIndex = 2;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = true;
      this.logisticalComTable = false;
      this.tabLabels = Constants.normalText.newTechnicalComplaints;
      let statusCode = Constants.normalText.openTechCom;
      this.technicalComplaintsData(statusCode);
    } else {
      this.selectedIndex = 1;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = true;
      this.logisticalComTable = false;
      this.tabLabels = Constants.normalText.newTechnicalComplaints;
      let statusCode = Constants.normalText.openTechCom;
      this.technicalComplaintsData(statusCode);
    }
  }

  totalLogisticsComplaints() {
    if (this.user?.userTypeId == 3) {
      this.selectedIndex = 2;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = false;
      this.logisticalComTable = true;
      this.tabLabels = Constants.normalText.totalLogisticsComplaints;
      let statusCode = [1, 2, 3];
      let timeCalculation = false;
      this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
    } else {
      this.selectedIndex = 1;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = false;
      this.logisticalComTable = true;
      this.tabLabels = Constants.normalText.totalLogisticsComplaints;
      let statusCode = [1, 2, 3];
      let timeCalculation = false;
      this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
    }
  }

  newComplaints() {
    if (this.user?.userTypeId == 3) {
      this.selectedIndex = 2;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = false;
      this.logisticalComTable = true;
      this.tabLabels = Constants.normalText.newComplaints;
      let statusCode = [1, 2];
      let timeCalculation = true;
      this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
    } else {
      this.selectedIndex = 1;
      this.technicalComplaintsDetailsTable = [];
      this.allLogisticComplaintsDetailsData = [];
      this.technicalComTable = false;
      this.logisticalComTable = true;
      this.tabLabels = Constants.normalText.newComplaints;
      let statusCode = [1, 2];
      let timeCalculation = true;
      this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
    }
  }

  resolveComplaints() {
    if (this.user?.userTypeId == 3) {
      this.selectedIndex = 2;
      this.tabLabels = Constants.normalText.resolvedComplaints;
      let statusCode = [3];
      let timeCalculation = true;
      this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
    } else {
      this.selectedIndex = 1;
      this.tabLabels = Constants.normalText.resolvedComplaints;
      let statusCode = [3];
      let timeCalculation = true;
      this.allComplaintsDetailsForIndividualTile(statusCode, timeCalculation);
    }
  }

  viewDownLoadComplaintData(item) {
    let payload = {
      complaintId: item.complaintNo
    }
    this.loaderService.show();
    this.complaintService.downloadComplaint(payload).pipe(takeUntil(this.destroyed$)).subscribe(dataDownload => {
      this.loaderService.hide();
      if (dataDownload && dataDownload?.entries != null) {
        this.dialog.open(ComplaintsDownloadPopupComponent, { disableClose: true, width: '38%', height: '50%', data: dataDownload?.entries });
      }
    })
  }

  viewAuditDetailsLogisticCom(item) {
    let payload = {
      complaintId: item.complaintNo
    }
    this.loaderService.show();
    this.complaintService.logisticComplaintAuditTrailDetails(payload).pipe(takeUntil(this.destroyed$)).subscribe(dataAuditTrail => {
      this.loaderService.hide();
      if (dataAuditTrail && dataAuditTrail?.getComplaintAuditDetails[0]?.entries != null) {
        this.dialog.open(LogisticComplaintsAuditTrailDetailsComponent, { disableClose: true, width: '38%', height: '50%', data: dataAuditTrail?.getComplaintAuditDetails[0]?.entries });
      }
    })
  }

  downloadAvgResolveTimeTechnicalComReport() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Turnaround_Time_Technical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Turnaround_Time_Technical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.region,
          customerId: null,
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          code: "C1",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Turnaround_Time_Technical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }

  downloadAvgResolveTimeLogicalComReport() {

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelForLogisticComplaints(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Turnaround_Time_Logistical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelForLogisticComplaints(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Turnaround_Time_Logistical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } 
      else if(this.region){
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }else {
        this.payloadDownloadAvgResolveTimeLogicalComReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'ART',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelForLogisticComplaints(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Turnaround_Time_Logistical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadComplaintStatusTechnicalReport() {

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Complaint_Status_Technical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Complaint_Status_Technical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: [this.region],
          customerId: null,
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          code: "C2",
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Complaint_Status_Technical_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadComplaintStatusLogisticsReport() {

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelForLogisticComplaints(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Complaint_Status_Logistic_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelForLogisticComplaints(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Complaint_Status_Logistic_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } 
      else if(this.region){
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }else {
        this.payloadDownloadComplaintStatusLogisticsReport = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: [],
          toggleCode: 'CS',
          is24Hour: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelForLogisticComplaints(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Complaint_Status_Logistic_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadForIndividualTile(statusCode, timeCalculation, fileName) {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadTableDataLogisticComplaints(this.payloadAllComplaintsDetailsForIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadTableDataLogisticComplaints(this.payloadAllComplaintsDetailsForIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllComplaintsDetailsForIndividualTile = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          statusIds: statusCode,
          is24Hour: timeCalculation,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadTableDataLogisticComplaints(this.payloadAllComplaintsDetailsForIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadTechnicalCom(statusCode, fileName){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: null,
          customerId: this.filterCode?.encrypt(),
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: [this.region],
          customerId: null,
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllComplaintsExcelDownload = {
          monthInterval: this.timePeriod,
          region: this.user?.userRegion,
          customerId: null,
          code: statusCode,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.downloadExcelTechnicalComplaints(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadTableDataComplaints(){
    if (this.tabLabels == Constants.normalText.totalTechnicalComplaints) {
      this.downloadTechnicalCom(Constants.normalText.technicalComplaints, 'Technical_Complaints_');
    }
    if (this.tabLabels == Constants.normalText.newTechnicalComplaints) {
      this.downloadTechnicalCom(Constants.normalText.openTechCom, 'Open_Technical_complaints');
    }
    else if (this.tabLabels == Constants.normalText.totalLogisticsComplaints) {
      this.downloadForIndividualTile([1, 2, 3],false,'Logistic_Complaints_');
    }
    else if (this.tabLabels == Constants.normalText.newComplaints) {
      this.downloadForIndividualTile([1, 2],true,'Open_Logistical_Complaints_');
    }
  }

  searchTechnicalComplaints(){
    if (this.tabLabels == Constants.normalText.totalTechnicalComplaints) {
      this.technicalComplaintsData(Constants.normalText.technicalComplaints);
    }
    else if (this.tabLabels == Constants.normalText.newTechnicalComplaints) {
      this.technicalComplaintsData(Constants.normalText.openTechCom);
    }
  }

  searchLogisticalComplaints(){
    if (this.tabLabels == Constants.normalText.totalLogisticsComplaints) {
      this.allComplaintsDetailsForIndividualTile([1, 2, 3], false);
    }
    else if (this.tabLabels == Constants.normalText.newComplaints) {
      this.allComplaintsDetailsForIndividualTile([1, 2], true);
    }
  }

  changeRecentComplaints(){
    if(this.isCheckedSlider){
      this.recentTechnicalComSection = true;
      this.recentLogisticalComSection = false;
    }else{
      this.recentTechnicalComSection = false;
      this.recentLogisticalComSection = true;
    }
  }

  monthIntervalData(evt){
    sessionStorage.setItem('complaintFilter', evt);

    sessionStorage.removeItem('callFromTileTechnicalCom');
    sessionStorage.removeItem('callFromTileOpenTechnicalCom');
    sessionStorage.removeItem('callFromTileLogisticalCom');
    sessionStorage.removeItem('callFromTileOpenLogisticalCom');

    this.timePeriod = JSON.parse(sessionStorage.getItem('complaintFilter'));
    sessionStorage.setItem('tabIndex', JSON.stringify(this.selectedIndex));
    this.logisticComplaintsData();
    this.getTechnicalComplaintData();
    window.location.reload();
    this.selectedIndex = +sessionStorage.getItem('tabIndex');
  }

  openDetailsDataPopupForExcel(text){
    if(text == 'chart1'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.result }});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.result }});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } 
        else if(this.region){
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.region,
            customerId: null,
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: null,
            code: "C1",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.result }});
          }
        })
      }
    }

    if(text == 'chart2'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.getLogisticComplaintDetails[0]?.entries}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.getLogisticComplaintDetails[0]?.entries}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } 
        else if(this.region){
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.getLogisticComplaintDetails[0]?.entries}});
          }
        })
      }
    }

    if(text == 'chart3'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data?.result }});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data?.result }});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } 
        else if(this.region){
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: [this.region],
            customerId: null,
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: null,
            code: "C2",
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data?.result }});
          }
        })
      }
  
    }

    if(text == 'chart4'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data?.getLogisticComplaintDetails[0]?.entries}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data?.getLogisticComplaintDetails[0]?.entries}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } 
        else if(this.region){
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.dialog.open(ComplaintChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data?.getLogisticComplaintDetails[0]?.entries}});
          }
        })
      }
    }

  }
  
  removeFile(){
    this.fileArr = [];
    this.myInputVariable.nativeElement.value = "";
  }

  goBackToHome(){
    this.router.navigate(['/home']).then(success => {
      window.location.reload();
    });
    sessionStorage.removeItem('dispatchFilter');
    sessionStorage.removeItem('complaintFilter');
    sessionStorage.removeItem('salesTimeinterval');
    sessionStorage.removeItem('tabIndex');
    sessionStorage.removeItem('sliderGcc');
  }

  viewTechnicalComplaintsDetail(item){
    this.dialog.open(TechnicalComplaintDetailsPopupComponent, { disableClose: true, width: '50%', height: '90%', data: item });
  }

}
