import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { ComplaintsManagementService } from 'src/app/services/complaints-management/complaints-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';

@Component({
  selector: 'app-complaint-chart-details-popup',
  templateUrl: './complaint-chart-details-popup.component.html',
  styleUrls: ['./complaint-chart-details-popup.component.css']
})
export class ComplaintChartDetailsPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  pageNo = 1;
  tableSearchComplaints: any;
  timePeriod = sessionStorage.getItem('complaintFilter');
  payloadAllComplaintsExcelDownload: any;
  payloadDownloadAvgResolveTimeLogicalComReport: any;
  payloadDownloadComplaintStatusLogisticsReport: any;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');



  constructor(private loaderService: LoaderService, private complaintService: ComplaintsManagementService, private dialogRef: MatDialogRef<ComplaintChartDetailsPopupComponent>, @Inject(MAT_DIALOG_DATA) public excelChartData: any){}

  
  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  searchtableComplaints(){

    if (this.excelChartData?.text == 'chart1'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.excelChartData.chartData = data?.result;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.excelChartData.chartData = data?.result;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } 
        else if(this.region){
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.region,
            customerId: null,
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: null,
            code: "C1",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.excelChartData.chartData = data?.result;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart2'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.excelChartData.chartData = data?.getLogisticComplaintDetails[0]?.entries;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.excelChartData.chartData = data?.getLogisticComplaintDetails[0]?.entries;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } 
        else if(this.region){
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }else {
          this.payloadDownloadAvgResolveTimeLogicalComReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'ART',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadAvgResolveTimeLogicalComReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.excelChartData.chartData = data?.getLogisticComplaintDetails[0]?.entries;
          }
        })
      }
    }
   
    if (this.excelChartData?.text == 'chart3'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.excelChartData.chartData = data?.result;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: this.user?.userId,
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.excelChartData.chartData = data?.result;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: null,
            customerId: this.filterCode?.encrypt(),
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } 
        else if(this.region){
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: [this.region],
            customerId: null,
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }else {
          this.payloadAllComplaintsExcelDownload = {
            monthInterval: this.timePeriod,
            region: this.user?.userRegion,
            customerId: null,
            code: "C2",
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelTechnicalComplaintsTableData(this.payloadAllComplaintsExcelDownload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.result != null){
            this.excelChartData.chartData = data?.result;
          }
        })
      }
    }

    if (this.excelChartData?.text == 'chart4'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.excelChartData.chartData = data?.getLogisticComplaintDetails[0]?.entries;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } else {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.user.userId],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.excelChartData.chartData = data?.getLogisticComplaintDetails[0]?.entries;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [this.filterCode.encrypt()],
            regions: [],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        } 
        else if(this.region){
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: [this.region],
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }else {
          this.payloadDownloadComplaintStatusLogisticsReport = {
            customerCodes: [],
            regions: this.user?.userRegion,
            payer: [],
            monthInterval: this.timePeriod,
            statusIds: [],
            toggleCode: 'CS',
            is24Hour: false,
            loginFromApp: false,
            type: 'details',
            gccCode: this.viewAsGCC,
            text: this.tableSearchComplaints
          }
        }
  
        this.loaderService.show();
        this.complaintService.excelLogisticComplaintsTableData(this.payloadDownloadComplaintStatusLogisticsReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getLogisticComplaintDetails[0]?.entries != null){
            this.excelChartData.chartData = data?.getLogisticComplaintDetails[0]?.entries;
          }
        })
      }
    }
  }

  closePopup() {
    this.dialogRef.close();
  }

}
