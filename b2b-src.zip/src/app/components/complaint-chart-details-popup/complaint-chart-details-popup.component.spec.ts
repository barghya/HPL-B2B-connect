import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintChartDetailsPopupComponent } from './complaint-chart-details-popup.component';

describe('ComplaintChartDetailsPopupComponent', () => {
  let component: ComplaintChartDetailsPopupComponent;
  let fixture: ComponentFixture<ComplaintChartDetailsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ComplaintChartDetailsPopupComponent]
    });
    fixture = TestBed.createComponent(ComplaintChartDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
