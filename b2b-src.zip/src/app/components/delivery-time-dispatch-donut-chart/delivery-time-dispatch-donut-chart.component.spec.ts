import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryTimeDispatchDonutChartComponent } from './delivery-time-dispatch-donut-chart.component';

describe('DeliveryTimeDispatchDonutChartComponent', () => {
  let component: DeliveryTimeDispatchDonutChartComponent;
  let fixture: ComponentFixture<DeliveryTimeDispatchDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeliveryTimeDispatchDonutChartComponent]
    });
    fixture = TestBed.createComponent(DeliveryTimeDispatchDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
