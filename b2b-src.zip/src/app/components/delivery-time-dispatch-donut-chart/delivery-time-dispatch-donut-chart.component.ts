import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-delivery-time-dispatch-donut-chart',
  templateUrl: './delivery-time-dispatch-donut-chart.component.html',
  styleUrls: ['./delivery-time-dispatch-donut-chart.component.css']
})
export class DeliveryTimeDispatchDonutChartComponent implements OnInit {

  @Input() inputDataDeliveryTimeDispatch: any;

  constructor() {}

  ngOnInit(): void {
    this.praparedDeliveryTimeDonutChartData();
  }

  praparedDeliveryTimeDonutChartData(){
    this.inputDataDeliveryTimeDispatch = {
      grid:{
        top:0
      },
      tooltip: {
        trigger: 'item',
        // formatter: '{c} ({d}%)'
        formatter: '{d}%'
      },
      legend: {
        top: '5%',
        left: 'center'
      },
      series: [
        {
          type: 'pie',
          radius: ['50%', '30%'],
          center: ['50%', '50%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          color: ['#754827','#FFD2D2'],
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: this.inputDataDeliveryTimeDispatch?.actualScheduleDiff,
        }
      ]
    }
  }

}
