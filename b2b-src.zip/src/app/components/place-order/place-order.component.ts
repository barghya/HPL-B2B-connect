import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, ReplaySubject, map, startWith, takeUntil } from 'rxjs';
import { CommonApiService } from 'src/app/services/common/common-api.service';
import { PlaceOrderService } from 'src/app/services/place-order/place-order.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  productItemsList: any;
  billingAddressList: any[]=[];
  deliveryAddressList: any[]=[];
  customerMail: any;
  customerSelectedProduct: any;
  customerQuantity: any;
  customerShipCode: any;
  customerBillingAddress: any;
  customerDeliveryAddress: any;
  customerData: any;
  customerRemarks: any;
  customerMaterialDesc: any;
  materialNameArr: any [] = [];
  materialNameControl = new FormControl('');
  filteredMaterialName: Observable<any[]>;
  selectedMaterialId: any;
  addressList: any [] = [];
  csaEmailList: any[] = [];
  isDisableplaceOrderBtn: boolean = false;



  constructor(private commonApi: CommonApiService, private commonservice: CommonService, private placeOrderService: PlaceOrderService, private loaderService: LoaderService) {}

  ngOnInit() : void{
    // this.fetchPlaceOrderDetails();
    this.getCSAEmail();
    this.fetProductItems();
    this.fetchAddressForCustomer();
    this.getMaterial();
    this.filteredMaterialName = this.materialNameControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filterMaterialName(value || '')),
    );
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  private _filterMaterialName(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.materialNameArr.filter(option => option?.name?.toLowerCase().includes(filterValue));
  }

  getMaterial() {
    this.loaderService.show();
    this.commonApi.materialName().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.materialNameArr = data;
      }
    })
  }

  getCSAEmail(){
    let payload = {
      userId: this.user?.userId,
      loginFromApp: false
    }
    this.loaderService.show();
    this.placeOrderService.getEmailCSA(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data?.getEmailList != null){
        this.csaEmailList = data?.getEmailList;
      }
    })
  }

  selectedMaterial(item){
    this.selectedMaterialId = item?.code;
  }

  fetProductItems(){
    this.loaderService.show();
    this.placeOrderService.productItems().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data?.productList){
        this.productItemsList = data?.productList;
      }
    })
  }

  fetchAddressForCustomer(){
    let payload = {
      userId: this.user.userId,
      loginFromApp: false
    }

    this.loaderService.show();
    this.placeOrderService.customerAddress(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data?.fetchAddressDetails){
        this.addressList = data?.fetchAddressDetails;
        data.fetchAddressDetails.forEach(element => {
          if(element.customerType == 'Self'){
            this.billingAddressList.push(element);
          }else if(element.customerType == 'Ship to party'){
            this.deliveryAddressList.push(element)
          }
        })
      }
    })
  }

  // fetchPlaceOrderDetails(){
  //   let payload = {
  //     userId: this.user.userId,
  //     loginFromApp: false
  //   }

  //   this.loaderService.show();
  //   this.placeOrderService.fetchPlaceOrderDetails(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
  //     this.loaderService.hide();
  //     if(data && data?.orderDetails != null){
  //       this.customerData = data?.orderDetails[0];
  //       // this.customerMail = data?.orderDetails[0]?.salesAgeEmailId;
  //       this.customerShipCode = data?.orderDetails[0]?.shippedToCode;
  //     }
  //   })
  // }

  reset(){
    window.location.reload();
  }

  numbersOnlyQty(){
    this.customerQuantity = this.customerQuantity.replace(/[^0-9.-]/g, '');
  }

  placeOrder(){
  
    let validEmail = this.commonservice.regexForEmail(this.customerMail);
    let validQuantity = this.commonservice.regexForNumericandDecimalNumber(this.customerQuantity);
    
    if(!this.customerMail){
      Swal.fire(alertPopup.mailEmpty);
    }
    else if(!validEmail){
      Swal.fire(alertPopup.validmail);
    }
    else if(!this.customerSelectedProduct){
      Swal.fire(alertPopup.productEmpty);
    }
    else if(!this.materialNameControl?.value){
      Swal.fire(alertPopup.materialNameEmpty);
    }
    else if(this.customerQuantity == null){
      Swal.fire(alertPopup.quantityEmpty);
    }
    else if(this.customerQuantity <= 0){
      Swal.fire(alertPopup.validQty);
    }
    // else if(validQuantity){
    //   Swal.fire(alertPopup.validQty);
    // }
    // else if(!this.customerMaterialDesc){
    //   Swal.fire(alertPopup.materialDescriptionEmpty);
    // }
    else if(!this.customerBillingAddress){
      Swal.fire(alertPopup.billingAddressEmpty);
    }
    // else if(!this.customerDeliveryAddress){
    //   Swal.fire(alertPopup.deliveryAddressEmpty);
    // }
    else{
      this.isDisableplaceOrderBtn = true;

      let payload = {
        userId: this.user.userId,
        customerId: this.user.userId,
        emailId: this.customerMail,
        productId: this.customerSelectedProduct,
        quantity: this.customerQuantity,
        billingAddress: this.customerBillingAddress,
        shippingAddress: this.customerDeliveryAddress,
        remarks: this.customerRemarks,
        materialCode: this.selectedMaterialId,
        materialDesc: null,
        loginFromApp: false
      }

      this.loaderService.show();
      this.placeOrderService.placeOrder(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if(data){
          if(data?.status == 1){
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }else{
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        }
      })
    }

  }

}
