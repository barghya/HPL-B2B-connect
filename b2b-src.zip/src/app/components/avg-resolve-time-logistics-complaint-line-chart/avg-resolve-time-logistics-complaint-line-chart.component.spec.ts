import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvgResolveTimeLogisticsComplaintLineChartComponent } from './avg-resolve-time-logistics-complaint-line-chart.component';

describe('AvgResolveTimeLogisticsComplaintLineChartComponent', () => {
  let component: AvgResolveTimeLogisticsComplaintLineChartComponent;
  let fixture: ComponentFixture<AvgResolveTimeLogisticsComplaintLineChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AvgResolveTimeLogisticsComplaintLineChartComponent]
    });
    fixture = TestBed.createComponent(AvgResolveTimeLogisticsComplaintLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
