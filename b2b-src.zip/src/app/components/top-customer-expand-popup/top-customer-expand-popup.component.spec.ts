import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopCustomerExpandPopupComponent } from './top-customer-expand-popup.component';

describe('TopCustomerExpandPopupComponent', () => {
  let component: TopCustomerExpandPopupComponent;
  let fixture: ComponentFixture<TopCustomerExpandPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TopCustomerExpandPopupComponent]
    });
    fixture = TestBed.createComponent(TopCustomerExpandPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
