import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { LoaderService } from 'src/app/utils/loader-service';

@Component({
  selector: 'app-top-customer-expand-popup',
  templateUrl: './top-customer-expand-popup.component.html',
  styleUrls: ['./top-customer-expand-popup.component.css']
})
export class TopCustomerExpandPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  monthInterval = sessionStorage.getItem('salesTimeinterval');
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');
  user = JSON.parse(sessionStorage.getItem('user') || '');
  region = sessionStorage.getItem('region');
  valOrQty: any;
  topOrBottom: any;
  valOrQtyPayload: any;
  topOrBottomPayload: any;



  constructor(private loaderService: LoaderService, private purchaseService: PurchaseManagementService, private dialogRef: MatDialogRef<TopCustomerExpandPopupComponent>, @Inject(MAT_DIALOG_DATA) public topCustomerDetailData: any) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  valOrQtyChange(evt) {
    if (this.region) {
      if (evt?.target?.value == "false") {
        this.valOrQtyPayload = {
          topOrBottom: this.topOrBottom,
          quantityOrValue: "false",
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: [this.region],
        }
      } else {
        this.valOrQtyPayload = {
          topOrBottom: this.topOrBottom,
          quantityOrValue: "true",
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: [this.region],
        }
      }
    } else {
      if (evt?.target?.value == "false") {
        this.valOrQtyPayload = {
          topOrBottom: this.topOrBottom,
          quantityOrValue: "false",
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: this.user.userRegion,
        }
      } else {
        this.valOrQtyPayload = {
          topOrBottom: this.topOrBottom,
          quantityOrValue: "true",
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: this.user.userRegion,
        }
      }
    }

    this.loaderService.show();
    this.purchaseService.topCustomerDetails(this.valOrQtyPayload).pipe(takeUntil(this.destroyed$)).subscribe(dataCustomer => {
      this.loaderService.hide();
      if (dataCustomer && dataCustomer?.getTopCustomers) {
        this.topCustomerDetailData = dataCustomer;
      }
    })
  }

  topOrBottomChange(evt) {
    if (this.region) {
      if (evt?.target?.value == "false") {
        this.topOrBottomPayload = {
          topOrBottom: "false",
          quantityOrValue: this.valOrQty,
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: [this.region],
        }
      } else {
        this.topOrBottomPayload = {
          topOrBottom: "true",
          quantityOrValue: this.valOrQty,
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: [this.region],
        }
      }
    } else {
      if (evt?.target?.value == "false") {
        this.topOrBottomPayload = {
          topOrBottom: this.topOrBottom,
          quantityOrValue: "false",
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: this.user.userRegion,
        }

      } else {
        this.topOrBottomPayload = {
          topOrBottom: this.topOrBottom,
          quantityOrValue: "true",
          monthInterval: this.monthInterval,
          gccCode : this.viewAsGCC,
          regions: this.user.userRegion,
        }
      }
    }

    this.loaderService.show();
    this.purchaseService.topCustomerDetails(this.topOrBottomPayload).pipe(takeUntil(this.destroyed$)).subscribe(dataCustomer => {
      this.loaderService.hide();
      if (dataCustomer && dataCustomer?.getTopCustomers) {
        this.topCustomerDetailData = dataCustomer;
      }
    })
  }

  closePopup() {
    this.dialogRef.close();
  }

}
