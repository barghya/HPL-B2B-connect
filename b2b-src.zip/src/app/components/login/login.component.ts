import { Component, OnDestroy, OnInit } from '@angular/core';
import { Constants } from 'src/app/utils/constants';
import { CaptchaService } from '../captcha/captcha.service';
import Swal from 'sweetalert2';
import { alertPopup } from 'src/app/utils/alert-popup';
import { LoaderService } from 'src/app/utils/loader-service';
import { ActivatedRoute, Router } from '@angular/router';
import 'src/app/encryptor-extension/encryptor-extension';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { CommonService } from 'src/app/utils/common-service';
import { ReplaySubject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  userId: string;
  password: string;
  lowerCaseValid: boolean;
  upperCaseValid: boolean;
  numberValid: boolean;
  lengthValid: boolean;
  sendMailScreen: boolean = false;
  resendScreen: boolean = false;
  resetPasswordScreen: boolean = false;
  loginScreen: boolean = true;
  isCaptchaVerified: boolean;
  captchaQus: any;
  captchaAnswer: any;
  captchaStatus: any = '';
  captchaConfig: any;
  isLogout: any;
  resetEmailId: any = '';
  cnfPwd: any;
  scode: any;
  resendId: any;
  linkResetId: any;
  validateUserId: any;
  resendMessage: any;
  isDisableResendBtn: boolean = false;


  constructor(private commonService: CommonService, private route: ActivatedRoute, private loaderService: LoaderService, private captchaService: CaptchaService, private router: Router, private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
    sessionStorage.clear();
    this.route.queryParams.pipe(takeUntil(this.destroyed$)).subscribe(params => {
      this.scode = params['sc'];
      if (this.scode) {
        this.verifySecurityCode();
      }
    });
    this.resetCaptcha();
    this.generateCaptcha();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  resetCaptcha() {
    this.captchaConfig = {
      type: Math.random() < 0.5 ? 1 : 2,
      length: 6,
      cssClass: 'custom',
      back: {
        stroke: "#2F9688",
        solid: "#f2efd2"
      },
      font: {
        color: "#000000",
        size: "35px"
      }
    };
  }

  setCaptchaValidation(evt) {
    this.isCaptchaVerified = evt;
  }

  generateCaptcha() {
    this.captchaService.logoutStatus.pipe(takeUntil(this.destroyed$)).subscribe((status) => {
      this.isLogout = status;
    });

    this.captchaService.captchStatus.pipe(takeUntil(this.destroyed$)).subscribe((status) => {
      this.captchaStatus = status;
      if (status == false && !this.isLogout) {
        this.isCaptchaVerified = false;
        this.commonService.openSnackBar("Captcha not verified. Please try again!");
        // Swal.fire(alertPopup.captchaNotVerified);
      } else if (status == true) {
        if (this.isLogout) {
          this.isLogout = false;
          this.isCaptchaVerified = true;
        } else if (!this.isLogout) {
          this.isCaptchaVerified = true;
          this.commonService.openSnackBar("Captcha verified!");
          // Swal.fire(alertPopup.captchaVerified);
        }

      }
    });
  }

  verifySecurityCode() {
    const payload = {
      "scode": this.scode
    }
    this.loaderService.show();
    this.authenticationService.validateCode(payload).pipe(takeUntil(this.destroyed$)).subscribe((data: any) => {
      this.loaderService.hide();
      if (data?.status === 1) {
        this.linkResetId = data?.linkResetId;
        this.validateUserId = data?.userId;
        this.resetPasswordScreen = true;
      }
      if (data?.status === 0) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: data?.message,
          showConfirmButton: true
        })
      }
    }, (error) => {
      Swal.fire(alertPopup.verifySecurityCodeError);
    }
    )
  }


  getUserId(val: string) {
    this.userId = val;
    if (this.isCaptchaVerified) {
      this.isCaptchaVerified = false;
      this.resetCaptcha();
    }
  }

  getPwd(event: any, screen?) {

    const myInputValue = (document.getElementById("pwd") as HTMLInputElement)?.value;
    const letter = document.getElementById("letter");
    const capital = document.getElementById("capital");
    const number = document.getElementById("number");
    const length = document.getElementById("length");

    // Validate lowercase letters
    if (myInputValue) {

      var lowerCaseLetters = Constants.regexPattern.lowerCaseLetters;

      if (myInputValue?.match(lowerCaseLetters)) {
        letter.classList.remove("invalid");
        letter.classList.add("valid");
        this.lowerCaseValid = true;
      } else {
        letter.classList.remove("valid");
        letter.classList.add("invalid");
        this.lowerCaseValid = false;
      }

      // Validate capital letters
      var upperCaseLetters = Constants.regexPattern.upperCaseLetters;
      if (myInputValue?.match(upperCaseLetters)) {
        capital.classList.remove("invalid");
        capital.classList.add("valid");
        this.upperCaseValid = true;
      } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
        this.upperCaseValid = false;
      }

      // Validate numbers
      var numbers = Constants.regexPattern.numbers;
      if (myInputValue?.match(numbers)) {
        number.classList.remove("invalid");
        number.classList.add("valid");
        this.numberValid = true;
      } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
        this.numberValid = false;
      }

      // Validate length
      if (myInputValue?.length >= 15) {
        length.classList.remove("invalid");
        length.classList.add("valid");
        this.lengthValid = true;
      } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
        this.lengthValid = false;
      }
    }

    if (event.key === 'Enter' && screen === 'login') {
      if (this.isCaptchaVerified) {
        this.login();
      } else {
        this.commonService.openSnackBar("Captcha not verified. Please try again!");
        // Swal.fire(alertPopup.captchaNotVerified);
      }
    } else {
      this.password = event.target.value;
      if (this.isCaptchaVerified) {
        this.isCaptchaVerified = false;
        this.resetCaptcha();
      }
    }
  }

  changePasswordScreen() {
    this.sendMailScreen = true;
    this.resendScreen = false;
    this.resetPasswordScreen = false;
    this.loginScreen = false;
    this.userId = '';
  }

  goBackBtn() {
    this.sendMailScreen = false;
    this.resendScreen = false;
    this.resetPasswordScreen = false;
    this.loginScreen = true;
  }

  changeToResendMailScreen() {
    this.resendScreen = true;
    this.sendMailScreen = false;
    this.resetPasswordScreen = false;
    this.loginScreen = false;
  }

  changeToResetPasswordScreen() {
    this.resetPasswordScreen = true;
  }

  sendEmailForPassword() {
    if (!this.isCaptchaVerified) {
      this.commonService.openSnackBar("Captcha not verified. Please try again!");
      // Swal.fire(alertPopup.captchaNotVerified);
      return;
    } 
    else if(!this.userId){
      Swal.fire(alertPopup.userId);
    }else {
      const payload = {
        userId: this.userId.encrypt(),
        loginFromApp: false
      };

      if ((this.userId && this.userId.length > 0)) {
        this.loaderService.show();
        this.authenticationService.sendResetPasswordMail(payload).pipe(takeUntil(this.destroyed$)).subscribe((data: any) => {
          this.loaderService.hide();
          if (data && data?.status === 1) {
            this.resetEmailId = data?.message;
            this.resendId = data?.id;
            this.changeToResendMailScreen();
          } else if (data && data?.status === 0) {
            this.isCaptchaVerified = false;
            this.resetCaptcha();
            Swal.fire({
              position: 'center',
              title: data?.message,
              showConfirmButton: true
            })
          }
        }, (error) => {
          Swal.fire(alertPopup.unauthorized);
        }
        )
      }
      else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: "User Id is empty. Please type valid UserId",
          showConfirmButton: true
        })
      }
    }
  }

  login() {
    const payload = {
      userId: this.userId.encrypt(),
      password: this.password.encrypt(),
      loginFromApp: false
    };

    if ((this.userId && this.userId.length > 0) && (this.password && this.password.length > 0)) {
      if (!this.isCaptchaVerified) {
        this.commonService.openSnackBar("Captcha not verified. Please try again!");
        // Swal.fire(alertPopup.captchaNotVerified);
        return;
      } else {
        this.loaderService.show();
        this.authenticationService.authenticate(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            if(data?.userRole[0]?.id == 11){
              this.router.navigate(['/uploadContribution']).then((succeeded) => {
                window.location.reload();
              })
            }else{
              this.router.navigate(['/home']).then((succeeded) => {
                window.location.reload();
              })
            }
          }
        }, (err) => {
          this.isCaptchaVerified = false;
          this.resetCaptcha();
        }
        )
      }
    }else{
      if(!this.userId && this.userId.length == 0){
        Swal.fire(alertPopup.nullUser);
      }
      else if(!this.password && this.password.length == 0){
        Swal.fire(alertPopup.nullPassword);
      }
    }
  }

  confirmPwd(event) {
    if (event.key === 'Enter' && this.password) {
      if (this.lowerCaseValid && this.lowerCaseValid && this.numberValid && this.lengthValid) {
        this.resetPassword();
      } else {
        Swal.fire(alertPopup.passwordVerified);
      }
    } else {
      this.cnfPwd = event.target.value;
    }
  }


  resendEmail() {
    this.isDisableResendBtn = true;
    setTimeout(() => {
      this.isDisableResendBtn = false;
    }, 60000);

    const payload = {
      "resendId": this.resendId
    };
    this.loaderService.show();
    this.authenticationService.resendResetPasswordMail(payload).pipe(takeUntil(this.destroyed$)).subscribe((data: any) => {
      this.loaderService.hide();
      if (data?.status === 1) {
        this.resendMessage = " Mail has been resend, please check now";
      }
    }, (error) => {
      Swal.fire(alertPopup.unauthorized);
    }
    )
  }


  resetPassword() {
    let whiteSpacePassword = this.commonService.regexForWhiteSpace(this.password);
    let whiteSpaceCnfPassword = this.commonService.regexForWhiteSpace(this.cnfPwd);


    if(!this.password){
      Swal.fire(alertPopup.password);
    }
    else if(whiteSpacePassword){
      Swal.fire(alertPopup.whiteSpacePassword);
    }
    else if(!this.cnfPwd){
      Swal.fire(alertPopup.confirmPassword);
    }
    else if(whiteSpaceCnfPassword){
      Swal.fire(alertPopup.whiteSpacePassword);
    }else{
      if (this.lowerCaseValid && this.lowerCaseValid && this.numberValid && this.lengthValid) {
        const payload = {
          "linkResetId": this.linkResetId,
          "userId": this.validateUserId.toString().encrypt(),
          "newPassword": this.password.encrypt(),
          "confirmNewPassword": this.cnfPwd.encrypt()
        }
        this.loaderService.show();
        this.authenticationService.resetPassword(payload).pipe(takeUntil(this.destroyed$)).subscribe((data: any) => {
          this.loaderService.hide();
          if (data?.status === 1) {
            Swal.fire(alertPopup.passwordResetSuccessfully);
            this.goBackBtn();
          } else if (data?.status === 0) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: data?.message,
              showConfirmButton: true
            })
          }
        }, (error) => {
          Swal.fire(alertPopup.unauthorized);
        }
        )
      } else {
        Swal.fire(alertPopup.passwordVerified);
      }
    }
  }

}

