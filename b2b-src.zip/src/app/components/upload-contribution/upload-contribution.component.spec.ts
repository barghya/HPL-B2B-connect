import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadContributionComponent } from './upload-contribution.component';

describe('UploadContributionComponent', () => {
  let component: UploadContributionComponent;
  let fixture: ComponentFixture<UploadContributionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UploadContributionComponent]
    });
    fixture = TestBed.createComponent(UploadContributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
