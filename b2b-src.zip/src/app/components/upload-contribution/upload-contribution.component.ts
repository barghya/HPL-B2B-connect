import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ContributionCalculatorService } from 'src/app/services/contribution-calculator/contribution-calculator.service';
import { DownloadService } from 'src/app/services/download/download.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';
import { saveAs } from 'file-saver';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-upload-contribution',
  templateUrl: './upload-contribution.component.html',
  styleUrls: ['./upload-contribution.component.css']
})
export class UploadContributionComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  @ViewChild('myInputFile')
  myInputVariable: ElementRef;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  isFileUploaded: any;
  fileAdded: boolean;
  file: File = null;
  nonCCSDiscountValue: any;
  contributionDetails: any [] = [];
  pageNo = 1;
  ccMonth: any;
  monthArr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
  fileArr: any[]=[];
 
  
  constructor(private downloadService: DownloadService, private commonservice: CommonService, private loaderService: LoaderService, private contributionCalculatorService: ContributionCalculatorService) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.getContributionDetails();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  onFileChangeTarget(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    this.fileArr = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  numbersOnlyCCSDiscountValue(){
    this.nonCCSDiscountValue = this.nonCCSDiscountValue.replace(/[^0-9.-]/g, '');
  }

  getContributionDetails(){
    let payload = {

    }
    this.loaderService.show();
    this.contributionCalculatorService.searchContributionDetails(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data != null){
        this.contributionDetails = data;
      }
    })
  }

  uploadContribution() {

    let validNonCCSValue = this.commonservice.regexForNumericandDecimalNumber(this.nonCCSDiscountValue);

    if(!this.nonCCSDiscountValue){
      Swal.fire(alertPopup.nonCCSValueEmpty);
    }
    else if(this.nonCCSDiscountValue <= 0){
      Swal.fire(alertPopup.validQty);
    }
    // else if(validNonCCSValue){
    //   Swal.fire(alertPopup.validCCSValueEmpty);
    // }
    else if(!this.ccMonth){
      Swal.fire(alertPopup.monthEmpty);
    }
    else if(!this.file){
      Swal.fire(alertPopup.uploadFile);
    }else{
      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('attachment', this.file, this.file.name);
      }

      let fileUploadReq = {
        value: this.nonCCSDiscountValue,
        userId: this.user?.id,
        userTypeId: this.user?.userTypeId,
        month: this.ccMonth,
        loginFromApp: false
      }

      Object.entries(fileUploadReq).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.contributionCalculatorService.uploadContributionCalculator(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        }
      })
    }

  }

  actionToProceedExcelFileCCS(item){
    Swal.fire(alertPopup.confirmProcess).then((result) => {
      if (result.isConfirmed) {
        let payload = {
          id: item?.id,
          loggedInUserId: this.user?.id,
          loginFromApp: false
        }

        this.loaderService.show();
        this.contributionCalculatorService.processContribution(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data?.status == 1){
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }else{
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
    })
    
  }

  removeFile(){
    this.fileArr = [];
    this.myInputVariable.nativeElement.value = "";
  }

  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

}
