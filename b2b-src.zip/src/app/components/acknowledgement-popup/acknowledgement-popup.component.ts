import { Component, ElementRef, Inject, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-acknowledgement-popup',
  templateUrl: './acknowledgement-popup.component.html',
  styleUrls: ['./acknowledgement-popup.component.css']
})
export class AcknowledgementPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  @ViewChild('myInputFile')
  myInputVariable: ElementRef;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  isFileUploaded: any;
  fileAdded: boolean;
  file: File = null;
  acknowledgement: any;
  ackPin: any;
  ackLocation: any;
  ackRemarks: any;
  ackDate: any;
  todayDate: Date = new Date();
  ackReportingDate: any;
  ackDeliveryDate: any;
  ackMasterData: any[]=[];
  selectedAckEvent: any;
  fileArr: any[]=[];



  constructor(private commonservice: CommonService, private loaderService: LoaderService, private dispatchService: DispatchManagementService, private dialogRef: MatDialogRef<AcknowledgementPopupComponent>, @Inject(MAT_DIALOG_DATA) public dispatchAckData: any){}


  ngOnInit(): void {
    this.fetchDetails();
    this.fetchAcknowledgement();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  fetchDetails(){
    if(this.dispatchAckData){
      this.ackReportingDate = this.dispatchAckData?.reportingDate;
    }
  }

  fetchAcknowledgement(){
    this.loaderService.show();
    this.dispatchService.fetchAck().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data?.getPodAckMaster != null){
        this.ackMasterData = data.getPodAckMaster;
      }
    })
  }

  onFileChange(event: any, isFileUploaded?){
    this.isFileUploaded = isFileUploaded;
    this.fileArr = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }


  ackTypeChange(event){
    this.selectedAckEvent = event.target.value;
  }


  acknowledge(){
    let formData =new FormData();
  
    if(this.fileAdded || this.isFileUploaded){
      formData = new FormData();
      formData.append('file', this.file, this.file.name);
    }
 
    let fileUploadRequest = {
      ackId: this.acknowledgement,
      pin: this.ackPin,
      location: this.ackLocation,
      reportingDate: this.commonservice.convertDateTimeISO(this.ackReportingDate, true),
      deliveryDate: this.commonservice.convertDateTimeISO(this.ackDeliveryDate, true),
      remarks: this.ackRemarks,
      statusId: this.selectedAckEvent,
      previousStatusId: this.dispatchAckData?.consignmentStatusId,
      invNo: this.dispatchAckData?.invoiceNo,
      b2bLoggedInUserCode: this.user.userId,
      consignmentId: this.dispatchAckData?.consignmentId,
      loginFromApp: false
    }
    
    Object.entries(fileUploadRequest).forEach(([key, value]) => {
      formData.append(key, value);
    });

    if(!this.acknowledgement){
      Swal.fire(alertPopup.acknowledgementType);
    }
    else if(!this.ackReportingDate){
      Swal.fire(alertPopup.ackReportingDate);
    }
    else if(!this.ackDeliveryDate){
      Swal.fire(alertPopup.ackDeliveryDate);
    }
    else if(this.selectedAckEvent == 3 && !this.file){
      Swal.fire(alertPopup.uploadFile);
    }else{
      this.loaderService.show();
      this.dispatchService.ackSave(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if(data?.status == 1){
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        }else{
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        }
      })
    }
   
  }

  closePopup(){
    this.dialogRef.close();
  }

  removeFile(){
    this.fileArr = [];
    this.myInputVariable.nativeElement.value = "";
  }

}
