import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcknowledgementPopupComponent } from './acknowledgement-popup.component';

describe('AcknowledgementPopupComponent', () => {
  let component: AcknowledgementPopupComponent;
  let fixture: ComponentFixture<AcknowledgementPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AcknowledgementPopupComponent]
    });
    fixture = TestBed.createComponent(AcknowledgementPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
