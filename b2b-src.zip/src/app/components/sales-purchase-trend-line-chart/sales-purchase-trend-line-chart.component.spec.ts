import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesPurchaseTrendLineChartComponent } from './sales-purchase-trend-line-chart.component';

describe('SalesPurchaseTrendLineChartComponent', () => {
  let component: SalesPurchaseTrendLineChartComponent;
  let fixture: ComponentFixture<SalesPurchaseTrendLineChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SalesPurchaseTrendLineChartComponent]
    });
    fixture = TestBed.createComponent(SalesPurchaseTrendLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
