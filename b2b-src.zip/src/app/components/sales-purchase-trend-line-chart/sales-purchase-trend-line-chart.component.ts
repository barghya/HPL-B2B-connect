import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-purchase-trend-line-chart',
  templateUrl: './sales-purchase-trend-line-chart.component.html',
  styleUrls: ['./sales-purchase-trend-line-chart.component.css']
})
export class SalesPurchaseTrendLineChartComponent implements OnInit {

  @Input() inputDataSalesPurchaseLineChart: any;

  constructor() {}

  ngOnInit(): void {
    this.praparedSalesPurchaseLineChartData();
  }

  praparedSalesPurchaseLineChartData(){
    this.inputDataSalesPurchaseLineChart = {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999'
          }
        }
      },
      xAxis: [
        {
          type: 'category',
          data: this.inputDataSalesPurchaseLineChart?.chartXaxisData?.data,
          axisPointer: {
            type: 'shadow'
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: 'Value (₹)',
          // interval: 10,
        },
        {
          type: 'value',
          name: 'Qty (MT)',
          // interval: 5,
        }
      ],
      series: [
        {
          name: 'Value',
          type: 'bar',
          color: ['#BB8C6B'],
          barWidth: '20%',
          tooltip: {
            valueFormatter: function (value) {
              return value;
            }
          },
          data: this.inputDataSalesPurchaseLineChart?.barChartSeriesData?.data,
        },
        {
          name: 'Qty',
          type: 'line',
          color: ['#EE756D'],
          yAxisIndex: 1,
          smooth: true,
          tooltip: {
            valueFormatter: function (value) {
              return value;
            }
          },
          data: this.inputDataSalesPurchaseLineChart?.lineChartSeriesData?.data,
        }
      ]
    }; }


}
