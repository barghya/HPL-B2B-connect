import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CcMailPopupComponent } from './cc-mail-popup.component';

describe('CcMailPopupComponent', () => {
  let component: CcMailPopupComponent;
  let fixture: ComponentFixture<CcMailPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CcMailPopupComponent]
    });
    fixture = TestBed.createComponent(CcMailPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
