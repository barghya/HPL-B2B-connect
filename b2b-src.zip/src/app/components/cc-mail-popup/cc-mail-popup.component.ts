import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { ContributionCalculatorService } from 'src/app/services/contribution-calculator/contribution-calculator.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cc-mail-popup',
  templateUrl: './cc-mail-popup.component.html',
  styleUrls: ['./cc-mail-popup.component.css']
})
export class CcMailPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  ccSentEmail: any;
  ccSentReamrks: any;
  mainSendArr: any[]=[];



  constructor(private commonservice: CommonService, private loaderService: LoaderService, private contributionService: ContributionCalculatorService, private dialogRef: MatDialogRef<CcMailPopupComponent>, @Inject(MAT_DIALOG_DATA) public ccSentDetailsData: any){}

  ngOnInit(): void {

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  sendDetailsMail(){
    let validEmail = this.commonservice.regexForEmail(this.ccSentEmail);

    if(!this.ccSentEmail){
      Swal.fire(alertPopup.mailEmpty);
    }
    else if(!validEmail){
      Swal.fire(alertPopup.validmail);
    }
    else if(!this.ccSentReamrks){
      Swal.fire(alertPopup.remarks);
    }else{
      this.ccSentDetailsData.forEach(element => {
        this.mainSendArr.push({
        billToParty: element?.ccBillToParty,
        shipToParty: element?.ccShipToParty,
        grade: element?.ccGrade,
        location: element?.ccLocation,
        region: element?.ccRegion,
        contributionPerMt: element?.ccContributionPerMt,
        additionalDiscountPerMt: element?.ccAdditionalDiscountPerMt,
        month: element?.ccMonth,
        netContribution: element?.netContribution,
        ccsQty: element?.ccQty,
        additionalQty: element?.ccAddlQty,
        overallDiscount: element?.ccOverallAddlDiscount,
        additionalContribution: element?.ccAdditionContribution,
        totalContribution: element?.ccTotalContribution
      })
      })
  
      let payload = {
        data: this.mainSendArr,
        toMail: this.ccSentEmail,
        ccMail: this.user?.emailId,
        remarks: this.ccSentReamrks,
        loggedInUserId: this.user?.userId,
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.contributionService.sendEmail(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
  
    }

  }

  closePopup(){
    this.dialogRef.close();
  }


}
