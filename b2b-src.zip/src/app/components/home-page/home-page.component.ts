import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import * as moment from 'moment';
import { ReplaySubject, takeUntil } from 'rxjs';
import { AccountManagementService } from 'src/app/services/accounts-management/account-management.service';
import { ComplaintsManagementService } from 'src/app/services/complaints-management/complaints-management.service';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  viewAsCustomerName = sessionStorage.getItem('codeName');
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');
  dispatchDetails: any;
  logisticComplaintsDetails: any;
  technicalComplaintsDetails: any;
  purchaseManagementCountDetails: any;
  payloadDispatch: any;
  payloadLogisticsComplaint: any;
  payloadTechnicalComplaint: any;
  payloadPurchaseOrderManagementData: any;
  payloadAccountManagementData: any;
  accountManagementCountDetails: any;
  currentMonth: any;
  currentFinancialYear: any;
  payloadPurchaseTarget: any;
  salesTargetRemainingDetails: any;
  today = new Date();
  presentDate = moment(new Date()).format('DD');
  getCurrentMonthHomePage = this.today.toLocaleString('default', { month: 'long' });
  getCurrentYear = (new Date()).getFullYear();
  timePeriod = 0;
  timePeriodList : any [] = [];
  userRoleId: any[] = [];
  getCurrentDateTime = moment(new Date()).format('DD-MM-YYYY HH:mm');



  constructor(private router: Router, private loaderService: LoaderService, private dispatchService: DispatchManagementService, private complaintService: ComplaintsManagementService, private purchaseService: PurchaseManagementService, private accountService: AccountManagementService) { }

  ngOnInit(): void {
    this.getDispatchData();
    this.getLogisticsComplaintData();
    this.getTechnicalComplaintData();
    this.getPurchaseOrderManagementData();
    this.getAccountManagementData();
    this.getCurrentMonth();
    this.getCurrentFinancialYear();
    this.getPurchaseTarget();
    this.filterValidation();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  getCurrentMonth(){
    const d = new Date();
    this.currentMonth = d.getMonth();
  }

  getCurrentFinancialYear() {
    let today = new Date();
    if ((today.getMonth() + 1) <= 3) {
      this.currentFinancialYear = today.getFullYear();
    }
    else {
      this.currentFinancialYear = (today.getFullYear() + 1);
    }
  }

  getPurchaseTarget(){
    this.user?.userRole.forEach(ele => {
      this.userRoleId.push(ele?.id);
    })

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.filterCode?.encrypt()],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: [5]
        }
      } else {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.user?.userId],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: this.userRoleId
        }
      }

      this.loaderService.show();
      this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data) {
          this.salesTargetRemainingDetails = data;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.filterCode?.encrypt()],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: this.userRoleId
        }
      } else {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.user?.userId],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: this.userRoleId
        }
        
      }


      this.loaderService.show();
      this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data) {
          this.salesTargetRemainingDetails = data;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.filterCode?.encrypt()],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: this.userRoleId
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.filterCode?.encrypt()],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: [5]
        }
      } else {
        this.payloadPurchaseTarget = {
          year: this.currentFinancialYear,
          month: this.currentMonth+1,
          customers: null,
          payer: [this.user?.userId],
          loggedInUserId: this.user?.id,
          gccCode : [this.viewAsGCC?.encrypt()],
          userRoleIds: this.userRoleId
        }
      }

      this.loaderService.show();
      this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data) {
          this.salesTargetRemainingDetails = data;
        }
      })
    }
  }


  getDispatchData() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDispatch = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchCountDetails(this.payloadDispatch).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data.dispatchOrders != null) {
          this.dispatchDetails = data?.dispatchOrders[0]?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDispatch = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchCountDetails(this.payloadDispatch).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data.dispatchOrders != null) {
          this.dispatchDetails = data?.dispatchOrders[0]?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDispatch = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadDispatch = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDispatch = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: 0,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchCountDetails(this.payloadDispatch).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data.dispatchOrders != null) {
          this.dispatchDetails = data?.dispatchOrders[0]?.entries[0];
        }
      })
    }

  }

  getLogisticsComplaintData() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadLogisticsComplaint = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLogisticsComplaint = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      
      this.loaderService.show();
      this.complaintService.complaintsCountDetails(this.payloadLogisticsComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintInfo[0]?.entries[0] != null) {
          this.logisticComplaintsDetails = data?.getLogisticsComplaintInfo[0]?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadLogisticsComplaint = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadLogisticsComplaint = {
          customerCodes: [this.user?.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsCountDetails(this.payloadLogisticsComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintInfo[0]?.entries[0] != null) {
          this.logisticComplaintsDetails = data?.getLogisticsComplaintInfo[0]?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadLogisticsComplaint = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadLogisticsComplaint = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadLogisticsComplaint = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadLogisticsComplaint = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: 0,
          statusIds: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.complaintsCountDetails(this.payloadLogisticsComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getLogisticsComplaintInfo[0]?.entries[0] != null) {
          this.logisticComplaintsDetails = data?.getLogisticsComplaintInfo[0]?.entries[0];
        }
      })
    }

  }

  getTechnicalComplaintData(){

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.complaintService.technicalComplaintsCountDetails(this.payloadTechnicalComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.technicalComplaintsDetails = data?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: this.user?.userRegion,
          customerId: this.user?.userId,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.technicalComplaintsCountDetails(this.payloadTechnicalComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.technicalComplaintsDetails = data?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: null,
          customerId: this.filterCode?.encrypt(),
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } 
      else if(this.region){
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: [this.region],
          customerId: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadTechnicalComplaint = {
          monthInterval: 0,
          region: this.user?.userRegion,
          customerId: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.complaintService.technicalComplaintsCountDetails(this.payloadTechnicalComplaint).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.technicalComplaintsDetails = data?.entries[0];
        }
      })
    }

  }

  getPurchaseOrderManagementData() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: 0,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
       else {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: 0,
          regions: this.user?.userRegion,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.purchaseManagementCountDetails = data?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: 0,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: 0,
          regions: this.user?.userRegion,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.purchaseManagementCountDetails = data?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: 0,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: 0,
          regions: [],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: 0,
          regions: [this.region],
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadPurchaseOrderManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: 0,
          regions: this.user?.userRegion,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseOrderManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.purchaseManagementCountDetails = data?.entries[0];
        }
      })
    }

  }

  getAccountManagementData() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: 0,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: 0,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: 0,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: 0,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: 0,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: 0,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: 0,
          regions: [this.region],
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: 0,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    }

  }

  
  navigateToDispatch() {
    this.router.navigate(['/dispatchManagement']).then((succeeded) => {
      window.location.reload()
    });
  }

  navigateToComplaints() {
    this.router.navigate(['/complaintsManagement']).then((succeeded) => {
      window.location.reload()
    });
  }

  navigateToSalesPurchase() {
    if (this.user?.userTypeId == 1) {
      this.router.navigate(['/salesOrderManagement']).then((succeeded) => {
        window.location.reload()
      });
    } else if (this.user?.userTypeId == 3 || this.user?.userTypeId == 2) {
      this.router.navigate(['/purchaseManagement']).then((succeeded) => {
        window.location.reload()
      });
    }
  }

  navigateToAccountLedger() {
    this.router.navigate(['/accountManagement']).then((succeeded) => {
      window.location.reload()
    });
  }

  totalSalesHome(){
    sessionStorage.setItem('callFromTileTotalSales', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Total Sales',
      },
    };
    this.router.navigate(['/salesOrderManagement'], {
      state: { dataTotalSales: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  confirmedSalesHome(){
    sessionStorage.setItem('callFromTileTotalConfirmSales', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Confirmed Sales',
      },
    };
    this.router.navigate(['/salesOrderManagement'], {
      state: { dataConfirmedSales: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  pendingSalesHome(){
    sessionStorage.setItem('callFromTileTotalPendingSales', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Pending Sales',
      },
    };
    this.router.navigate(['/salesOrderManagement'], {
      state: { dataPendingSales: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  blockedSalesHome(){
    sessionStorage.setItem('callFromTileTotalBlockedSales', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Blocked Sales',
      },
    };
    this.router.navigate(['/salesOrderManagement'], {
      state: { dataBlockedSales: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  totalPurchaseHome(){
    sessionStorage.setItem('callFromTileTotalPurchase', 'true');

    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Total Purchase',
      },
    };
    this.router.navigate(['/purchaseManagement'], {
      state: { dataTotalPurchase: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  confirmedPurchaseHome(){
    sessionStorage.setItem('callFromTileConfirmPurchase', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Confirmed Purchase',
      },
    };
    this.router.navigate(['/purchaseManagement'], {
      state: { dataConfirmPurchase: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }
  
  pendingPurchaseHome(){
    sessionStorage.setItem('callFromTilePendingPurchase', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Pending Purchase',
      },
    };
    this.router.navigate(['/purchaseManagement'], {
      state: { dataPendingPurchase: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  blockedPurchaseHome(){
    sessionStorage.setItem('callFromTileBlockedPurchase', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Blocked Purchase',
      },
    };
    this.router.navigate(['/purchaseManagement'], {
      state: { dataBlockedPurchase: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  totalSalesAccHome(){
    sessionStorage.setItem('callFromTileTotalSalesAcc', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Total Sales Acc',
      },
    };
    this.router.navigate(['/accountManagement'], {
      state: { dataTotalSalesAcc: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  totalPurchaseAccHome(){
    sessionStorage.setItem('callFromTileTotalPurAcc', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Total Purchase Acc',
      },
    };
    this.router.navigate(['/accountManagement'], {
      state: { dataTotalPurchaseAcc: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  accLedgerHome(){
    sessionStorage.setItem('callFromTileAccLedger', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Account Ledger',
      },
    };
    this.router.navigate(['/accountManagement'], {
      state: { dataAccLedger: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  accPendingInvoices(){
    sessionStorage.setItem('callFromTileAccPendingInvoice', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Account Pending Invoices',
      },
    };
    this.router.navigate(['/accountManagement'], {
      state: { dataAccPendingInvoice: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  accCrDr(){
    sessionStorage.setItem('callFromTileAccCrDr', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Account Cr Dr',
      },
    };
    this.router.navigate(['/accountManagement'], {
      state: { dataAccCrDr: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  totalDispatch(){
    sessionStorage.setItem('callFromTileTotalDispatch', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Total Dispatch',
      },
    };
    this.router.navigate(['/dispatchManagement'], {
      state: { dataTotalDispatch: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  pendingDispatch(){
    sessionStorage.setItem('callFromTilePendingDispatch', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Pending Dispatch',
      },
    };
    this.router.navigate(['/dispatchManagement'], {
      state: { dataPendingDispatch: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  inTransitOrder(){
    sessionStorage.setItem('callFromTileInTransitOrder', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'In Transit',
      },
    };
    this.router.navigate(['/dispatchManagement'], {
      state: { dataInTransit: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  totalPODAck(){
    sessionStorage.setItem('callFromTileTotalPodAck', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Total POD ACK',
      },
    };
    this.router.navigate(['/dispatchManagement'], {
      state: { dataTotalPODAck: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  PODAck(){
    sessionStorage.setItem('callFromTilePodAck', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'POD ACK',
      },
    };
    this.router.navigate(['/dispatchManagement'], {
      state: { dataPODAck: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  technicalCom(){
    sessionStorage.setItem('callFromTileTechnicalCom', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Technical Com',
      },
    };
    this.router.navigate(['/complaintsManagement'], {
      state: { dataTechnicalCom: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  openTechCom(){
    sessionStorage.setItem('callFromTileOpenTechnicalCom', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Open Technical',
      },
    };
    this.router.navigate(['/complaintsManagement'], {
      state: { dataOpenTechnical: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  logisticCom(){
    sessionStorage.setItem('callFromTileLogisticalCom', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Logistic Com',
      },
    };
    this.router.navigate(['/complaintsManagement'], {
      state: { dataLogisticCom: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }

  openLogistic(){
    sessionStorage.setItem('callFromTileOpenLogisticalCom', 'true');
    let navigationExtras: NavigationExtras = {
      state: {
        callFrom: 'Open Logistic',
      },
    };
    this.router.navigate(['/complaintsManagement'], {
      state: { dataOpenLogistic: navigationExtras },
    }).then(success =>{
      window.location.reload();
    });
  }
  

}
