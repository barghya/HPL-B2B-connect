import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDataManagementDetailsComponent } from './user-data-management-details.component';

describe('UserDataManagementDetailsComponent', () => {
  let component: UserDataManagementDetailsComponent;
  let fixture: ComponentFixture<UserDataManagementDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserDataManagementDetailsComponent]
    });
    fixture = TestBed.createComponent(UserDataManagementDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
