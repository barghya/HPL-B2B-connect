import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { LoaderService } from 'src/app/utils/loader-service';
import { UserManagementService } from 'src/app/services/user-management/user-management.service';
import Swal from 'sweetalert2';
import { UserEditPopupComponent } from '../user-edit-popup/user-edit-popup.component';
import { UserAddPopupComponent } from '../user-add-popup/user-add-popup.component';
import { ReplaySubject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-user-data-management-details',
  templateUrl: './user-data-management-details.component.html',
  styleUrls: ['./user-data-management-details.component.css']
})
export class UserDataManagementDetailsComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  pageNo = 1;
  userList: any[] = [];


  constructor(private dialog: MatDialog, private loaderService: LoaderService, private userService: UserManagementService){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.getUserList();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  getUserList(){
    let payload = {
        text: null
    }

    this.loaderService.show();
    this.userService.userList(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data){
        this.userList = data;
      }
    })
  }

  addUserPopup(){
    this.dialog.open(UserAddPopupComponent, { disableClose: true, width: '60%', height: '65%' });
  }
  
  updateUserActiveInactiveStatus(data?, status?){
    let payload = {
      userId: data?.user?.id,
      employeeId: data?.employeeId,
      isActive: status,
      loggedInUserId: this.user?.id
    }

    this.loaderService.show();
    this.userService.updateEmployeeActivation(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data.status == 1) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: data.message,
          showCancelButton: false,
          allowEnterKey: false,
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: data.message,
          showCancelButton: false,
          allowEnterKey: false,
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        })
      }
    })
  }

  editUserPopup(item){
    this.dialog.open(UserEditPopupComponent, { disableClose: true, width: '60%', height: '65%', data: item});
  }

}
