import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-actual-target-combo-chart',
  templateUrl: './purchase-actual-target-combo-chart.component.html',
  styleUrls: ['./purchase-actual-target-combo-chart.component.css']
})
export class PurchaseActualTargetComboChartComponent implements OnInit {

  @Input() inputDataOverallPurchaseActualTargetValue: any;
  maxValBarChart: any;
  maxValLineChart: any;


  constructor() { }

  ngOnInit(): void {
    this.praparedOverallPurchaseActualTargetChartData();
  }

  praparedOverallPurchaseActualTargetChartData() {
    if(this.inputDataOverallPurchaseActualTargetValue?.barChartSeriesData?.data){
      this.maxValBarChart = Math.max(...this.inputDataOverallPurchaseActualTargetValue?.barChartSeriesData?.data);
    }

    if(this.inputDataOverallPurchaseActualTargetValue?.lineChartSeriesData?.data){
      this.maxValLineChart = Math.max(...this.inputDataOverallPurchaseActualTargetValue?.lineChartSeriesData?.data);
    }

    let chartHighestValArr = [];
    chartHighestValArr.push(this.maxValBarChart, this.maxValLineChart);
    const maxValChart: number = Math.max(...chartHighestValArr);
    
    if(this.inputDataOverallPurchaseActualTargetValue?.lineChartSeriesData == null){
      this.inputDataOverallPurchaseActualTargetValue = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          },
          // textStyle: {
          //   fontSize: 12,
          // },
          appendToBody: true
        },
        grid: { left: '15%', width: '67%', height: '60%', top: '12%' },
        xAxis: [
          {
            axisLabel: {
              rotate: 70,
            },
            splitLine: {
              show: false
            },
            type: 'category',
            data: this.inputDataOverallPurchaseActualTargetValue?.chartXaxisData?.data,
            axisPointer: {
              type: 'shadow'
            },
            axisTick: {
              alignWithLabel: true
            },
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: 'Actual',
            splitLine: {
              show: false
            },
            axisLabel: {
              formatter: function (value) {
                // if (value >= 0 && value < 1000) {
                //   value;
                // }
                // if (value >= 1000 && value < 100000) {
                //   value = value / 1000 + "K";
                // }
                // if (value >= 100000 && value < 1000000) {
                //   value = value / 1000000 + "M";
                // }
                // if (value >= 1000000) {
                //   value = value / 1000000000 + "B";
                // }
                // return value;
                if (value >= 0 && value < 1000) {
                  value;
                }
                if (value >= 100000 && value < 10000000) {
                  value = value / 100000 + "L";
                }
                if (value >= 10000000) {
                  value = value / 10000000 + "Cr";
                }
                return value;
              },
            },
            // interval: 400,
          },
        ],
        series: [
          {
            name: 'Actual',
            type: 'bar',
            color: ['#BB8C6B'],
            barWidth: '20%',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: this.inputDataOverallPurchaseActualTargetValue?.barChartSeriesData?.data,
          }
        ]
      }; 
    }else{
      this.inputDataOverallPurchaseActualTargetValue = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          },
          // textStyle: {
          //   fontSize: 12,
          // },
          appendToBody: true
        },
        grid: { left: '15%', width: '67%', height: '60%', top: '12%' },
        xAxis: [
          {
            axisLabel: {
              rotate: 70,
            },
            splitLine: {
              show: false
            },
            type: 'category',
            data: this.inputDataOverallPurchaseActualTargetValue?.chartXaxisData?.data,
            axisPointer: {
              type: 'shadow'
            },
            axisTick: {
              alignWithLabel: true
            },
          }
        ],
        yAxis: [
          {
            type: 'value',
            max: maxValChart,
            min: 0,
            name: 'Actual',
            splitLine: {
              show: false
            },
            axisLabel: {
              formatter: function (value) {
                // if (value >= 0 && value < 1000) {
                //   value;
                // }
                // if (value >= 1000 && value < 100000) {
                //   value = value / 1000 + "K";
                // }
                // if (value >= 100000 && value < 1000000) {
                //   value = value / 1000000 + "M";
                // }
                // if (value >= 1000000) {
                //   value = value / 1000000000 + "B";
                // }
                // return value;
                if (value >= 0 && value < 1000) {
                  value;
                }
                if (value >= 100000 && value < 10000000) {
                  value = value / 100000 + "L";
                }
                if (value >= 10000000) {
                  value = value / 10000000 + "Cr";
                }
                return value;
              },
            },
            // interval: 400,
          },
          {
            type: 'value',
            name: 'Target',
            max: maxValChart,
            min: 0,
            // axisLabel: {
            //   color: '#fff'
            // },
            splitLine: {
              show: false
            },
            axisLabel: {
              formatter: function (value) {
                // if (value >= 0 && value < 1000) {
                //   value;
                // }
                // if (value >= 1000 && value < 100000) {
                //   value = value / 1000 + "K";
                // }
                // if (value >= 100000 && value < 1000000) {
                //   value = value / 1000000 + "M";
                // }
                // if (value >= 1000000) {
                //   value = value / 1000000000 + "B";
                // }
                // return value;
                if (value >= 0 && value < 1000) {
                  value;
                }
                if (value >= 100000 && value < 10000000) {
                  value = value / 100000 + "L";
                }
                if (value >= 10000000) {
                  value = value / 10000000 + "Cr";
                }
                return value;
              },
            },
            // interval: 400,
          }
        ],
        series: [
          {
            name: 'Actual',
            type: 'bar',
            color: ['#BB8C6B'],
            barWidth: '20%',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: this.inputDataOverallPurchaseActualTargetValue?.barChartSeriesData?.data,
          },
          {
            name: 'Target',
            type: 'line',
            color: ['#EE756D'],
            yAxisIndex: 1,
            smooth: true,
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            triggerLineEvent: true,
            data: this.inputDataOverallPurchaseActualTargetValue?.lineChartSeriesData?.data,
          }
        ]
      };
    }

  }

}
