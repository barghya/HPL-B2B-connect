import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseActualTargetComboChartComponent } from './purchase-actual-target-combo-chart.component';

describe('PurchaseActualTargetComboChartComponent', () => {
  let component: PurchaseActualTargetComboChartComponent;
  let fixture: ComponentFixture<PurchaseActualTargetComboChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PurchaseActualTargetComboChartComponent]
    });
    fixture = TestBed.createComponent(PurchaseActualTargetComboChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
