import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-avg-resolve-time-technical-comp-line-chart',
  templateUrl: './avg-resolve-time-technical-comp-line-chart.component.html',
  styleUrls: ['./avg-resolve-time-technical-comp-line-chart.component.css']
})
export class AvgResolveTimeTechnicalCompLineChartComponent implements OnInit {

  @Input() inputAvgResolveTimeTechCom: any;

  constructor() { }
 
  ngOnInit(): void {
    this.praparedAvgResolveTimeTechnicalComChartData();
  }

  praparedAvgResolveTimeTechnicalComChartData() {
    this.inputAvgResolveTimeTechCom = {
      grid: { left: '15%', width: '80%', height: '50%' },
      color: ['#BB8C6B'],
      tooltip: {
        trigger: 'axis'
      },
      xAxis: {
        axisLabel: {
          rotate: 70,
        },
        type: 'category',
        data: this.inputAvgResolveTimeTechCom?.xaxis?.data,
      },
      yAxis: {
        type: 'value',
        name: 'Days',
        splitLine: {
          show: false
        },
      },
      series: [
        {
          data: this.inputAvgResolveTimeTechCom?.yaxis?.data,
          type: 'line',
          smooth: true
        }
      ]
    };
  }

}
