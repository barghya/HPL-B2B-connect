import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvgResolveTimeTechnicalCompLineChartComponent } from './avg-resolve-time-technical-comp-line-chart.component';

describe('AvgResolveTimeTechnicalCompLineChartComponent', () => {
  let component: AvgResolveTimeTechnicalCompLineChartComponent;
  let fixture: ComponentFixture<AvgResolveTimeTechnicalCompLineChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AvgResolveTimeTechnicalCompLineChartComponent]
    });
    fixture = TestBed.createComponent(AvgResolveTimeTechnicalCompLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
