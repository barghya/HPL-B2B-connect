import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { LoaderService } from 'src/app/utils/loader-service';
import { AcknowledgementPopupComponent } from '../acknowledgement-popup/acknowledgement-popup.component';
import { DownloadService } from 'src/app/services/download/download.service';
import { saveAs } from 'file-saver';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';
import { DeliveryInfoDetailsComponent } from '../delivery-info-details/delivery-info-details.component';
import { CommonService } from 'src/app/utils/common-service';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Constants } from 'src/app/utils/constants';


@Component({
  selector: 'app-dispatch-details-popup',
  templateUrl: './dispatch-details-popup.component.html',
  styleUrls: ['./dispatch-details-popup.component.css']
})
export class DispatchDetailsPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  pageNo = 1;
  tableSearchDispatch: any;
  urlsafe: SafeResourceUrl;
  payloadAllDispatchDetails: any;
  timePeriod = 0;
  allDispatchDetailsDataFinal :  any [] = [];
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');



  constructor(private modalService: NgbModal, private sanitizer: DomSanitizer, private commonService: CommonService, private dispatchService: DispatchManagementService, private downloadService : DownloadService, private dialog: MatDialog, private loaderService: LoaderService, private dialogRef: MatDialogRef<DispatchDetailsPopupComponent>, @Inject(MAT_DIALOG_DATA) public allDispatchDetailsData: any){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.allDispatchDetailsDataFinal = this.allDispatchDetailsData?.searchData;
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  searchtableDispatch(){
    
    this.allDispatchDetailsDataFinal = [];

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsDataFinal = data?.entries;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsDataFinal = data?.entries;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',  
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      }else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: this.allDispatchDetailsData?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          searchText: this.tableSearchDispatch,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsDataFinal = data?.entries;
        }
      })
    }


  }

  closePopup(){
    this.dialogRef.close();
  }

  acknowledge(item) {
    this.dialog.open(AcknowledgementPopupComponent, { disableClose: true, width: '50%', height: '96%', data: item });
  }

  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  viewDeliveryInfoDetails(item) {
    let url = this.commonService.appendUrl(ApiEndPoints.urls.individualTripDetailsUrl, item.tripId);
    this.loaderService.show();
    this.dispatchService.individualTripDetails(url).pipe(takeUntil(this.destroyed$)).subscribe(dataIndividualTripDetails => {
      if (dataIndividualTripDetails && dataIndividualTripDetails.entries[0]) {
        this.dialog.open(DeliveryInfoDetailsComponent, { disableClose: true, width: '50%', height: '87%', data: dataIndividualTripDetails.entries[0] });
      }
    })
  }

  viewHistory(content: any, item) {
    let payload = {
      trip_id: item.tripId,
      feed_unique_id: "",
      tracking_only: true
    }
    this.loaderService.show();
    this.dispatchService.vehicleViewInMap(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.urlsafe = this.sanitizer.bypassSecurityTrustResourceUrl(data?.link);
        this.modalService.open(content, {
          windowClass: 'modal-holder',
          backdrop: 'static',
          size: 'editchart-popup',
          keyboard: false
        });

      }
    })
  }

  dismissGradModal(modal: any) {
    modal.dismiss('Cross click');
  }


}
