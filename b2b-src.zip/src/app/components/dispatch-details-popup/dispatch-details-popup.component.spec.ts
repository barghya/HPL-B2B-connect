import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispatchDetailsPopupComponent } from './dispatch-details-popup.component';

describe('DispatchDetailsPopupComponent', () => {
  let component: DispatchDetailsPopupComponent;
  let fixture: ComponentFixture<DispatchDetailsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DispatchDetailsPopupComponent]
    });
    fixture = TestBed.createComponent(DispatchDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
