import { Component, OnInit, OnDestroy } from '@angular/core';
import * as moment from 'moment';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { SalesOrderChartDetailsPopupComponent } from '../sales-order-chart-details-popup/sales-order-chart-details-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ViewHistoricalPopupComponent } from '../view-historical-popup/view-historical-popup.component';
import { ReplaySubject, takeUntil } from 'rxjs';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { DispatchDetailsPopupComponent } from '../dispatch-details-popup/dispatch-details-popup.component';

@Component({
  selector: 'app-purchase-management',
  templateUrl: './purchase-management.component.html',
  styleUrls: ['./purchase-management.component.css']
})
export class PurchaseManagementComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  gccValue = JSON.parse(sessionStorage.getItem('gcc'));
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  selectedIndex: number;
  pageNo = 1;
  purchaseManagementCountDetails: any;
  tabLabels = Constants.normalText.purchaseDetails;
  allPurchaseDetailsData: any;
  purchaseManagementBarLineChartDetails: any;
  purchaseManagementActualTargetChartDetails: any;
  isTargetRemainingTable: boolean = false;
  isTotalPurchaseTable: boolean = false;
  isConfirmOrderTable: boolean = false;
  isPendingOrderTable: boolean = false;
  isBlockedOrderTable: boolean = false;
  payloadDownloadIndividualTile: any;
  payloadDownloadOverallPurchaseTrendValueQtyReport: any;
  currentMonth: any;
  currentFinancialYear: any;
  payloadPurchaseTarget: any;
  salesTargetRemainingDetails: any;
  salesPurchase: any;
  region = sessionStorage.getItem('region');
  isCheckedSliderGcc: any;
  gccChart: boolean = false;
  gccChartData: any;
  timePeriod = 0;
  // timePeriodList : any [] = [];
  getTotalPurchaseDetails: any;
  getConfirmedPurchaseDetails: any;
  getPendingPurchaseDetails: any;
  getBlockedPurchaseDetails: any;
  isPanelActive: boolean = true;
  userRoleId: any[] = [];
  gccSlider: any;

  timePeriodList = [
    { id: 1, label: 'MTD', value: 0 },
    { id: 2, label: 'YTD', value: 1 },
    { id: 3, label: 'Prv Month', value: 2 },
  ];
  payloadPurchaseCount: any;
  payloadAllPurchaseDetails: any;
  payloadChartData: any;
  payloadActualTargetChart: any;
  payloadMonthInterval: any;
  isCheckedSliderSales: any;
  isGradeEnabled: boolean = true;
  payloadAllDispatchDetails: any;
  allDispatchDetailsData: any [] = [];
  isCheckedZDDPSliderSales: any;
  isCheckedZDOPSliderSales: any;
  isZDDPEnabled: boolean = false;
  isZDOPEnabled: boolean = false;
  isZCDPZCOPTable: boolean = false;
  isColumnActive: boolean = false;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');


  // timePeriodList = [    
  //   {id:1, label:'MTD', value: 0},
  //   {id:2, label:'Last 3 months', value: 3},
  //   {id:3, label:'Last 6 months', value: 6},
  //   {id:4, label:'Last 1 year', value: 12},
  //   {id:4, label:'Last 3 year', value: 36},
  // ]



  constructor(private dispatchService: DispatchManagementService, private router: Router, private dialog: MatDialog, private loaderService: LoaderService, private purchaseService: PurchaseManagementService) {

    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalPurchase')) {
      this.getTotalPurchaseDetails = this.router.getCurrentNavigation().extras.state['dataTotalPurchase'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileConfirmPurchase')) {
      this.getConfirmedPurchaseDetails = this.router.getCurrentNavigation().extras.state['dataConfirmPurchase'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTilePendingPurchase')) {
      this.getPendingPurchaseDetails = this.router.getCurrentNavigation().extras.state['dataPendingPurchase'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileBlockedPurchase')) {
      this.getBlockedPurchaseDetails = this.router.getCurrentNavigation().extras.state['dataBlockedPurchase'];
    }

  }



  ngOnInit(): void {

    if(this.viewAsGCC){
      this.isCheckedSliderGcc = false;
      sessionStorage.removeItem('sliderGcc');
      sessionStorage.removeItem('gcc');
    }

    if (sessionStorage.getItem('sliderGcc') || this.viewAs == 'GCC') {
      this.isCheckedSliderGcc = 'on';
      this.gccSlider = 'On GCC',
      this.gccChart = true;
      if(this.viewAs != 'GCC'){
        let payload = {
          gccDate: this.user?.gccData[0]?.gccBillingDate ? this.user?.gccData[0]?.gccBillingDate : this.gccValue?.gccBillingDate,
          gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.gccChartData = data;
          }
        })
      }else{
        let payload = {
          gccDate: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.gccChartData = data;
          }
        })
      }
     
    } else {
      this.gccChart = false;
    }


    gridUtilObj.resizeGrid();


    this.getPurchaseCountData();

    if (this.getTotalPurchaseDetails == undefined && this.getConfirmedPurchaseDetails == undefined && this.getPendingPurchaseDetails == undefined && this.getBlockedPurchaseDetails == undefined) {
      this.allPurchaseDetails();
    }

    this.getChartData();
    // this.getChartDataForActualTarget();
    this.getCurrentMonth();
    this.getCurrentFinancialYear();
    this.getPurchaseTarget();

    this.fetchTableDetails();

    // this.filterValidation();

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation() {
    if (this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5) {
      this.timePeriodList = [
        { id: 1, label: 'MTD', value: 0 },
        { id: 2, label: 'Last 3 months', value: 3 },
        { id: 3, label: 'Last 6 months', value: 6 },
        { id: 4, label: 'Last 1 year', value: 12 },
      ]
    }
    if (this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4) {
      this.timePeriodList = [
        { id: 1, label: 'MTD', value: 0 },
        { id: 2, label: 'Last 3 months', value: 3 },
        { id: 3, label: 'Last 6 months', value: 6 },
      ]
    }
    if (this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2) {
      this.timePeriodList = [
        { id: 1, label: 'MTD', value: 0 },
        { id: 2, label: 'Last 3 months', value: 3 },
      ]
    }

  }

  fetchTableDetails() {

    if (this.getTotalPurchaseDetails?.state?.callFrom == "Total Purchase") {
      this.totalPurchase();
    }

    if (this.getConfirmedPurchaseDetails?.state?.callFrom == "Confirmed Purchase") {
      this.totalConfirmOrder();
    }

    if (this.getPendingPurchaseDetails?.state?.callFrom == "Pending Purchase") {
      this.totalPendingOrder();
    }

    if (this.getBlockedPurchaseDetails?.state?.callFrom == "Blocked Purchase") {
      this.blockedOrder();
    }

  }

  informationChange(event: any) {
    this.isCheckedSliderSales = false;
    this.isCheckedZDDPSliderSales = false;
    this.isCheckedZDOPSliderSales = false;
    this.isZCDPZCOPTable = false;
    this.selectedIndex = event;
    this.pageNo = 1;
  }

  getPurchaseCountData() {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC' ) {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }


        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseCount).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseCount = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseCount).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseCount).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
          
        } else {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseCount).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        
        } else {
          this.payloadPurchaseCount = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseCount).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        
        }
        else if (this.region) {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
       
        } else {
          this.payloadPurchaseCount = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
       
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadPurchaseCount).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
    }

  }

  allPurchaseDetails() {
    this.isTotalPurchaseTable = true;
    let code = Constants.normalText.tp;
    this.allPurchaseDetailsForIndividualTile(code);
  }

  allPurchaseDetailsForIndividualTile(codeData, slidercode?) {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null || data?.zcdpZcopDetails != null)) {
            this.allPurchaseDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null || data?.zcdpZcopDetails != null)) {
            this.allPurchaseDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.allPurchaseDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
          
        } else {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null || data?.zcdpZcopDetails != null)) {
            this.allPurchaseDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null || data?.zcdpZcopDetails != null)) {
            this.allPurchaseDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadAllPurchaseDetails = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            text: this.salesPurchase,
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.allPurchaseDetailsData = data;
            this.pageNo = 1;
          }
        })
      }
    }


  }


  targetRemainingPurchase() {
    this.allPurchaseDetailsData = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.targetRemainingDetails;
    let code = Constants.normalText.tr;
    this.allPurchaseDetailsForIndividualTile(code);
    this.isTargetRemainingTable = true;
    this.isTotalPurchaseTable = false;
    this.isConfirmOrderTable = false;
    this.isBlockedOrderTable = false;
    this.isPendingOrderTable = false;
  }

  totalPurchase() {
    this.allPurchaseDetailsData = null;
    this.salesPurchase = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.purchaseDetails;
    let code = Constants.normalText.tp;
    this.allPurchaseDetailsForIndividualTile(code);
    this.isTotalPurchaseTable = true;
    this.isTargetRemainingTable = false;
    this.isConfirmOrderTable = false;
    this.isBlockedOrderTable = false;
    this.isPendingOrderTable = false;
    this.isGradeEnabled = true;
    this.isZDDPEnabled = false;
    this.isZDOPEnabled = false;
  }

  totalConfirmOrder() {
    this.allPurchaseDetailsData = null;
    this.salesPurchase = null;
    this.selectedIndex = 1;
    let code = Constants.normalText.co;
    let slidercode = Constants.normalText.zddp;
    if(this.user?.userTypeId == 2 && (this.viewAs != 'Customer' && this.viewAs != 'GCC')){
      this.tabLabels = Constants.normalText.confirmOrderDetails;
      this.allPurchaseDetailsForIndividualTile(code, slidercode);
    }else{
      this.tabLabels = Constants.normalText.confirmOrderDetailsPurchase;
      this.allPurchaseDetailsForIndividualTile(code);
    }
    this.isConfirmOrderTable = true;
    this.isTotalPurchaseTable = false;
    this.isTargetRemainingTable = false;
    this.isBlockedOrderTable = false;
    this.isPendingOrderTable = false;
    this.isGradeEnabled = false;
    this.isZDDPEnabled = true;
    this.isZDOPEnabled = false;
    this.isColumnActive = true;
  }

  totalPendingOrder() {
    this.allPurchaseDetailsData = null;
    this.salesPurchase = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.pendingOrderDetailsPurchase;
    let code = Constants.normalText.po;
    let slidercode = Constants.normalText.zdop;
    if(this.user?.userTypeId == 2 && (this.viewAs != 'Customer' && this.viewAs != 'GCC')){
      this.allPurchaseDetailsForIndividualTile(code, slidercode);
    }else{
      this.allPurchaseDetailsForIndividualTile(code);
    }
    this.isPendingOrderTable = true;
    this.isConfirmOrderTable = false;
    this.isTotalPurchaseTable = false;
    this.isTargetRemainingTable = false;
    this.isBlockedOrderTable = false;
    this.isGradeEnabled = false;
    this.isZDDPEnabled = false;
    this.isZDOPEnabled = true;
    this.isColumnActive = false;
  }

  blockedOrder() {
    this.allPurchaseDetailsData = null;
    this.salesPurchase = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.blockedOrderDetails;
    let code = Constants.normalText.bo;
    this.allPurchaseDetailsForIndividualTile(code);
    this.isBlockedOrderTable = true;
    this.isPendingOrderTable = false;
    this.isConfirmOrderTable = false;
    this.isTotalPurchaseTable = false;
    this.isTargetRemainingTable = false;
    this.isGradeEnabled = false;
    this.isZDDPEnabled = false;
    this.isZDOPEnabled = false;
  }

  getChartData() {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadChartData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadChartData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadChartData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadChartData = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadChartData = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadChartData = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadChartData = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadChartData = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementValueQtyChart(this.payloadChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementBarLineChartDetails = data?.chartEntry;
          }
        })
      }
    }

  }

  getChartDataForActualTarget() {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        } else {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        } else {
          this.payloadActualTargetChart = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        } else {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            targetValue: this.salesTargetRemainingDetails?.total,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadActualTargetChart = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadActualTargetChart = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            regions: this.user?.userRegion,
            targetValue: this.salesTargetRemainingDetails?.total,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementLineBarChart(this.payloadActualTargetChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.chartEntry != null) {
            this.purchaseManagementActualTargetChartDetails = data?.chartEntry;
          }
        })
      }
    }

  }

  downloadOverallPurchaseTrendValueQtyReport() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Trend_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Trend_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          loginFromApp: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          regions: [],
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          loginFromApp: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          regions: [],
        }
      } else if (this.region) {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
          customerCodes: [],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Trend_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadTargetAchievementValueReport() {

  }


  downloadForIndividualTile(codeData, fileName, slidercode?) {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else if (this.region) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [this.region],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }

    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else if (this.region) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: [this.region],
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: this.timePeriod,
            toggleCode: codeData,
            regions: this.user?.userRegion,
            userType: "BU",
            sliderEnabled: true,
            slidercode: slidercode,
            gccCode: this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }

    }

  }


  downloadTableDataPurchase() {
    if (!this.isCheckedSliderSales) {
      if (this.tabLabels == Constants.normalText.targetRemainingDetails) {
        // this.downloadForIndividualTile(Constants.normalText.tdo);
      }
      else if (this.tabLabels == Constants.normalText.purchaseDetails) {
        this.downloadForIndividualTile(Constants.normalText.tp, 'Total_Purchase_');
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetails) {

        if(this.isCheckedZDDPSliderSales){
          this.downloadForIndividualTile(Constants.normalText.co,'Pending_Order(ZDDP/ZCDP)_', Constants.normalText.zcdp);
        }else{
          this.downloadForIndividualTile(Constants.normalText.co,'Pending_Order(ZDDP/ZCDP)_',  Constants.normalText.zddp);  
        }
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetailsPurchase) {
        this.downloadForIndividualTile(Constants.normalText.co, 'Pending_Order_');
      }

      else if (this.tabLabels == Constants.normalText.pendingOrderDetailsPurchase && this.user?.userTypeId == 2 && (this.viewAs != 'Customer' && this.viewAs != 'GCC')) {
        if(this.isCheckedZDOPSliderSales){
          this.downloadForIndividualTile(Constants.normalText.po,'Open_Order_', Constants.normalText.zcop);  
        }else{
          this.downloadForIndividualTile(Constants.normalText.po,'Open_Order_', Constants.normalText.zdop);  
        } 
      }

      else if ((this.tabLabels == Constants.normalText.pendingOrderDetailsPurchase && this.user?.userTypeId == 3) || (this.viewAs == 'Customer' || this.viewAs == 'GCC')) {
        this.downloadForIndividualTile(Constants.normalText.po, 'Open_Order_');
      }

      else if (this.tabLabels == Constants.normalText.blockedOrderDetails) {
        this.downloadForIndividualTile(Constants.normalText.bo, 'Blocked_Order_');
      }
    } else {
      if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Purchase_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Purchase_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else if (this.region) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [this.region],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Purchase_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }

      } else {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Purchase_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Purchase_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          } else if (this.region) {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: [this.region],
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadDownloadIndividualTile = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              userType: "BU",
              sliderEnabled: false,
              gccCode: this.viewAsGCC,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(data);
            link.download = 'Total_Purchase_' + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
            link.click();
          })
        }

      }
    }

  }

  getCurrentMonth() {
    const d = new Date();
    this.currentMonth = d.getMonth();
  }

  getCurrentFinancialYear() {
    let today = new Date();
    if ((today.getMonth() + 1) <= 3) {
      this.currentFinancialYear = today.getFullYear();
    }
    else {
      this.currentFinancialYear = (today.getFullYear() + 1);
    }
  }

  getPurchaseTarget() {

    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      this.user?.userRole.forEach(ele => {
        this.userRoleId.push(ele?.id);
      })

      let gccArr = [];
      if (!this.viewAs) {
        this.user?.gccData?.forEach(ele => {
          gccArr.push(ele?.gccCode.encrypt());
        })
      }
      if (this.viewAs) {
        gccArr = [this.gccValue?.gccCode];
      }


      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: [7]
          }
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
         
        }

        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        
        }


        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
        
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: [7]
          }
          
        }
        else if (this.region) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
       
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gccCode: gccArr,
            gcc: true,
            userRoleIds: this.userRoleId
          }
       
        }

        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
    } else {
      this.user?.userRole.forEach(ele => {
        this.userRoleId.push(ele?.id);
      })

      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: [7]
          }
          
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        
        }

        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
         
        } else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        }
     

        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
         
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.filterCode?.encrypt()],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: [7]
          }
      
        }
        else if (this.region) {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
        
        }
        else {
          this.payloadPurchaseTarget = {
            year: this.currentFinancialYear,
            month: this.currentMonth + 1,
            customers: null,
            payer: [this.user?.userId],
            loggedInUserId: this.user?.id,
            gcc: false,
            gccCode : [this.viewAsGCC?.encrypt()],
            userRoleIds: this.userRoleId
          }
       
        }

        this.loaderService.show();
        this.purchaseService.targetRemaining(this.payloadPurchaseTarget).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data) {
            this.salesTargetRemainingDetails = data;
            this.getChartDataForActualTarget();
          }
        })
      }
    }

  }

  searchPurchase() {
    if (!this.isCheckedSliderSales) {
      if (this.tabLabels == Constants.normalText.purchaseDetails) {
        this.allPurchaseDetailsForIndividualTile(Constants.normalText.tp);
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetails) {

        if(this.isCheckedZDDPSliderSales){
          this.allPurchaseDetailsForIndividualTile(Constants.normalText.co, Constants.normalText.zcdp);
        }else{
          this.allPurchaseDetailsForIndividualTile(Constants.normalText.co, Constants.normalText.zddp);  
        }
      }
      else if (this.tabLabels == Constants.normalText.confirmOrderDetailsPurchase) {
        this.allPurchaseDetailsForIndividualTile(Constants.normalText.co);
      }

      else if (this.tabLabels == Constants.normalText.pendingOrderDetailsPurchase && this.user?.userTypeId == 2 && (this.viewAs != 'Customer' && this.viewAs != 'GCC')) {
        if(this.isCheckedZDOPSliderSales){
          this.allPurchaseDetailsForIndividualTile(Constants.normalText.po, Constants.normalText.zcop);  
        }else{
          this.allPurchaseDetailsForIndividualTile(Constants.normalText.po, Constants.normalText.zdop);  
        } 
      }

      else if ((this.tabLabels == Constants.normalText.pendingOrderDetailsPurchase && this.user?.userTypeId == 3) || (this.viewAs == 'Customer' || this.viewAs == 'GCC')) {
        this.allPurchaseDetailsForIndividualTile(Constants.normalText.po);
      }
      else if (this.tabLabels == Constants.normalText.blockedOrderDetails) {
        this.allPurchaseDetailsForIndividualTile(Constants.normalText.bo);
      }
    } else {
      if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }
          else if (this.region) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allPurchaseDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
      } else {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          }
          else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          }
          else if (this.region) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              gccCode : this.viewAsGCC,
              sliderEnabled: false,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allPurchaseDetailsData = data;
              this.pageNo = 1;
            }
          })
        }
      }
    }

  }

  showGcc(evt) {

    sessionStorage.removeItem('callFromTileTotalPurchase');
    sessionStorage.removeItem('callFromTileConfirmPurchase');
    sessionStorage.removeItem('callFromTilePendingPurchase');
    sessionStorage.removeItem('callFromTileBlockedPurchase');

    if (this.getTotalPurchaseDetails?.state?.callFrom == "Total Purchase") {
      this.getTotalPurchaseDetails.state.callFrom = null;
    }

    if (this.getConfirmedPurchaseDetails?.state?.callFrom == "Confirmed Purchase") {
      this.getConfirmedPurchaseDetails.state.callFrom = null;
    }

    if (this.getPendingPurchaseDetails?.state?.callFrom == "Pending Purchase") {
      this.getPendingPurchaseDetails.state.callFrom = null;
    }

    if (this.getBlockedPurchaseDetails?.state?.callFrom == "Blocked Purchase") {
      this.getBlockedPurchaseDetails.state.callFrom = null;
    }


    if (!this.isCheckedSliderGcc) {
      sessionStorage.setItem('sliderGcc', 'On GCC');

      this.gccChart = true;

      if(this.viewAs != 'GCC'){
        let payload = {
          gccDate: this.user?.gccData[0]?.gccBillingDate ? this.user?.gccData[0]?.gccBillingDate : this.gccValue?.gccBillingDate,
          gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.gccChartData = data;
          }
        })
  
        this.getPurchaseCountData();
        this.getChartData();
        this.getChartDataForActualTarget();
        this.getPurchaseTarget();
        window.location.reload();
      }else{
        let payload = {
          gccDate: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
  
        this.loaderService.show();
        this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.gccChartData = data;
          }
        })
  
        this.getPurchaseCountData();
        this.getChartData();
        this.getChartDataForActualTarget();
        this.getPurchaseTarget();
        window.location.reload();
      }
      
    } else {
      sessionStorage.removeItem('sliderGcc');
      this.gccChart = false;
      window.location.reload();
    }
  }

  downloadSalesComparisonGccWiseValueReport() {
    if(this.viewAs != 'GCC'){
      let payload = {
        gccDate: this.user?.gccData[0]?.gccBillingDate ? this.user?.gccData[0]?.gccBillingDate : this.gccValue?.gccBillingDate,
        gccCode: this.user?.gccData[0]?.gccCode.encrypt() ? this.user?.gccData[0]?.gccCode.encrypt() : this.gccValue?.gccCode,
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Value_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }else{
      let payload = {
        gccDate: null,
        gccCode: this.viewAsGCC.encrypt(),
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Value_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
   
  }

  downloadSalesComparisonGccWiseQtyReport() {
    if(this.viewAs != 'GCC'){
      let payload = {
        gccDate: this.user?.gccData[0]?.gccBillingDate ? this.user?.gccData[0]?.gccBillingDate : this.gccValue?.gccBillingDate,
        gccCode: this.user?.gccData[0]?.gccCode.encrypt() ? this.user?.gccData[0]?.gccCode.encrypt() : this.gccValue?.gccCode,
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }else{
      let payload = {
        gccDate: null,
        gccCode: this.viewAsGCC.encrypt(),
        userType: "BU",
        loginFromApp: false
      }
  
      this.loaderService.show();
      this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "GCC_Qty_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    
  }

  // targetAskingRateDataChange(event){
  //   if(event != 0){
  //     this.salesTargetRemainingDetails?.total == 1;
  //     this.purchaseManagementBarLineChartDetails?.askingRate == "N/A";
  //   }
  // }

  monthIntervalData(evt) {

    sessionStorage.setItem('salesTimeinterval', evt);

    if (evt != 0) {
      this.isPanelActive = false;
    } else {
      this.isPanelActive = true;
    }

    // this.targetAskingRateDataChange(evt);

    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadMonthInterval).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadMonthInterval = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadMonthInterval).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        } else {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadMonthInterval).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
    } else {
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadMonthInterval).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadMonthInterval = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadMonthInterval).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      } else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }
        else if (this.region) {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        } else {
          this.payloadMonthInterval = {
            customerCodes: [],
            payer: [],
            monthInterval: evt,
            regions: this.user?.userRegion,
            gccCode : this.viewAsGCC,
            loginFromApp: false
          }
        }

        this.loaderService.show();
        this.purchaseService.purchaseManagementCountDetails(this.payloadMonthInterval).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data?.entries[0] != null) {
            this.purchaseManagementCountDetails = data?.entries[0];
          }
        })
      }
    }


  }

  openDetailsDataPopupForExcel(text) {
    if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
      if (text == 'chart1') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart1', chartData: data?.getChartExcelData } });
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart1', chartData: data?.getChartExcelData } });
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else if (this.region) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [this.region],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart1', chartData: data?.getChartExcelData } });
            }
          })
        }
      }

      if (text == 'chart2') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart2', chartData: data?.getChartExcelData } });
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart2', chartData: data?.getChartExcelData } });
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else if (this.region) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [this.region],
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart2', chartData: data?.getChartExcelData } });
            }
          })
        }
      }

      if (text == 'chart3') {
        let payload = {
          gccDate: this.user?.gccData[0]?.gccBillingDate ? this.user?.gccData[0]?.gccBillingDate : this.gccValue?.gccBillingDate,
          gccCode: this.user?.gccData[0]?.gccCode.encrypt() ? this.user?.gccData[0]?.gccCode.encrypt() : this.gccValue?.gccCode,
          loginFromApp: false,
          type: 'details'
        }

        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart3', chartData: data, gccDate: this.user?.gccData[0]?.gccBillingDate, gccCode: this.user?.gccData[0]?.gccCode.encrypt() } });
          }
        })
      }

      if (text == 'chart4') {
        let payload = {
          gccDate: this.user?.gccData[0]?.gccBillingDate ? this.user?.gccData[0]?.gccBillingDate : this.gccValue?.gccBillingDate,
          gccCode: this.user?.gccData[0]?.gccCode.encrypt() ? this.user?.gccData[0]?.gccCode.encrypt() : this.gccValue?.gccCode,
          loginFromApp: false,
          type: 'details'
        }

        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart4', chartData: data, gccDate: this.user?.gccData[0]?.gccBillingDate, gccCode: this.user?.gccData[0]?.gccCode.encrypt() } });
          }
        })
      }
    } else {
      if (text == 'chart1') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart1', chartData: data?.getChartExcelData } });
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart1', chartData: data?.getChartExcelData } });
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else if (this.region) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [this.region],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart1', chartData: data?.getChartExcelData } });
            }
          })
        }
      }

      if (text == 'chart2') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart2', chartData: data?.getChartExcelData } });
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart2', chartData: data?.getChartExcelData } });
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else if (this.region) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: [this.region],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details'
            }
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart2', chartData: data?.getChartExcelData } });
            }
          })
        }
      }

      if (text == 'chart3') {
        if(this.viewAs != 'GCC'){
          let payload = {
            gccDate: this.user?.gccData[0]?.gccBillingDate,
            gccCode: this.user?.gccData[0]?.gccCode.encrypt(),
            loginFromApp: false,
            type: 'details'
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart3', chartData: data, gccDate: this.user?.gccData[0]?.gccBillingDate, gccCode: this.user?.gccData[0]?.gccCode.encrypt() } });
            }
          })
        }else{
          let payload = {
            gccDate: null,
            gccCode: this.viewAsGCC.encrypt(),
            loginFromApp: false,
            type: 'details'
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart3', chartData: data, gccDate: null, gccCode: this.viewAsGCC.encrypt() } });
            }
          })
        }
       
      }

      if (text == 'chart4') {
        if(this.viewAs != 'GCC'){
          let payload = {
            gccDate: this.user?.gccData[0]?.gccBillingDate,
            gccCode: this.user?.gccData[0]?.gccCode.encrypt(),
            loginFromApp: false,
            type: 'details'
          }
          
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart4', chartData: data, gccDate: this.user?.gccData[0]?.gccBillingDate, gccCode: this.user?.gccData[0]?.gccCode.encrypt() } });
            }
          })
        }else{
          let payload = {
            gccDate: null,
            gccCode: this.viewAsGCC.encrypt(),
            loginFromApp: false,
            type: 'details'
          }

          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data != null) {
              this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: { text: 'chart4', chartData: data, gccDate: null, gccCode: this.viewAsGCC.encrypt() } });
            }
          })
        }
       
      }
    }

  }

  goBackToHome() {
    this.router.navigate(['/home']).then(success => {
      window.location.reload();
    });
    sessionStorage.removeItem('dispatchFilter');
    sessionStorage.removeItem('complaintFilter');
    sessionStorage.removeItem('salesTimeinterval');
    sessionStorage.removeItem('tabIndex');
    sessionStorage.removeItem('sliderGcc');
  }

  openPopupForHistoricalData() {
    this.dialog.open(ViewHistoricalPopupComponent, { disableClose: true, width: '60%', height: '70%' });
  }

  changeGradeYesNo() {
    if (this.isCheckedSliderSales) {
      let code = Constants.normalText.tp;
      this.allPurchaseDetailsForIndividualTile(code);
    } else {
      if (this.gccSlider == 'On GCC' && this.viewAs != 'GCC') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }
          else if (this.region) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode.decrypt(),
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allPurchaseDetailsData = data;
            }
          })
        }
      } else {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
          else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && (data?.blockedSalesDetails != null || data?.confirmPendingSalesDetails != null || data?.salesDetails != null)) {
              this.allPurchaseDetailsData = data;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }
          else if (this.region) {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          } else {
            this.payloadAllPurchaseDetails = {
              customerCodes: [],
              payer: [],
              monthInterval: this.timePeriod,
              toggleCode: Constants.normalText.tp,
              regions: this.user?.userRegion,
              text: this.salesPurchase,
              sliderEnabled: false,
              gccCode : this.viewAsGCC,
              loginFromApp: false
            }
          }

          this.loaderService.show();
          this.purchaseService.purchaseManagementDetails(this.payloadAllPurchaseDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data) {
              this.allPurchaseDetailsData = data;
            }
          })
        }
      }
    }
  }

  changeZDDPToZCDP(){
    if(this.isCheckedZDDPSliderSales){
      let code = Constants.normalText.co;
      let slidercode = Constants.normalText.zddp;
      this.allPurchaseDetailsForIndividualTile(code, slidercode);
      this.isConfirmOrderTable = true;
      this.isZCDPZCOPTable = false;
    }else{
      let code = Constants.normalText.co;
      let slidercode = Constants.normalText.zcdp;
      this.allPurchaseDetailsForIndividualTile(code, slidercode);
      this.isConfirmOrderTable = false;
      this.isZCDPZCOPTable = true;
    }
  }

  changeZDOPToZCOP(){
    if(this.isCheckedZDOPSliderSales){
      let code = Constants.normalText.po;
      let slidercode = Constants.normalText.zdop;
      this.allPurchaseDetailsForIndividualTile(code, slidercode);
      this.isZCDPZCOPTable = false;
      this.isPendingOrderTable = true;
    }else{
      let code = Constants.normalText.po;
      let slidercode = Constants.normalText.zcop;
      this.allPurchaseDetailsForIndividualTile(code, slidercode);  
      this.isZCDPZCOPTable = true;
      this.isPendingOrderTable = false;
    }
  }

 

  openDispatchDetailsPopup(itemDdata){
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsData = data?.entries;
          this.dialog.open(DispatchDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {searchData: this.allDispatchDetailsData, zddpSalesDocNo: itemDdata?.zddpSalesDocNo} });
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.user.userId],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsData = data?.entries;
          this.dialog.open(DispatchDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {searchData: this.allDispatchDetailsData, zddpSalesDocNo: itemDdata?.zddpSalesDocNo} });
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [this.filterCode.encrypt()],
          regions: [],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllDispatchDetails = {
          customerCodes: [],
          regions: this.user?.userRegion,
          payer: [],
          monthInterval: this.timePeriod,
          code: 'TDO',
          text: itemDdata?.zddpSalesDocNo,
          gccCode : this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.dispatchService.dispatchDetails(this.payloadAllDispatchDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries?.length != 0) {
          this.allDispatchDetailsData = data?.entries;
          this.dialog.open(DispatchDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {searchData: this.allDispatchDetailsData, zddpSalesDocNo: itemDdata?.zddpSalesDocNo} });
        }
      })
    }

  }

}
