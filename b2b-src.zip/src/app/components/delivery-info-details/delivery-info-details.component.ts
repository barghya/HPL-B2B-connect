import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReplaySubject, takeUntil } from 'rxjs';
import { DispatchManagementService } from 'src/app/services/dispatch-management/dispatch-management.service';
import { LoaderService } from 'src/app/utils/loader-service';


@Component({
  selector: 'app-delivery-info-details',
  templateUrl: './delivery-info-details.component.html',
  styleUrls: ['./delivery-info-details.component.css']
})
export class DeliveryInfoDetailsComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  urlsafe: SafeResourceUrl;


  constructor(private modalService: NgbModal, private loaderService: LoaderService, private dispatchService: DispatchManagementService,private dialogRef: MatDialogRef<DeliveryInfoDetailsComponent>, @Inject(MAT_DIALOG_DATA) public deliveryInfoDetailsData: any, private sanitizer: DomSanitizer){}

  
  ngOnInit(): void {  

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  closePopup() {
    this.dialogRef.close();
  }

  viewHistory(content: any) {
    let payload = {
      trip_id: this.deliveryInfoDetailsData?.tripId,
      feed_unique_id: "",
      tracking_only: true
    }
    this.loaderService.show();
    this.dispatchService.vehicleViewInMap(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.urlsafe = this.sanitizer.bypassSecurityTrustResourceUrl(data?.link);
        this.modalService.open(content, {
          windowClass: 'modal-holder',
          backdrop: 'static',
          size: 'editchart-popup',
          keyboard: false
        });

      }
    })
  }

  dismissGradModal(modal: any) {
    modal.dismiss('Cross click');
  }
  
}
