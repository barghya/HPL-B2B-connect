import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryInfoDetailsComponent } from './delivery-info-details.component';

describe('DeliveryInfoDetailsComponent', () => {
  let component: DeliveryInfoDetailsComponent;
  let fixture: ComponentFixture<DeliveryInfoDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeliveryInfoDetailsComponent]
    });
    fixture = TestBed.createComponent(DeliveryInfoDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
