import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReleaseOrderComponent } from './release-order.component';

describe('ReleaseOrderComponent', () => {
  let component: ReleaseOrderComponent;
  let fixture: ComponentFixture<ReleaseOrderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReleaseOrderComponent]
    });
    fixture = TestBed.createComponent(ReleaseOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
