import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { alertPopup } from 'src/app/utils/alert-popup';
import Swal from 'sweetalert2';
import { ReleaseOrderPopupComponent } from '../release-order-popup/release-order-popup.component';
import { ReleaseOrderService } from 'src/app/services/release-order/release-order.service';
import { LoaderService } from 'src/app/utils/loader-service';
import { NavigationExtras } from '@angular/router';
import { Constants } from 'src/app/utils/constants';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-release-order',
  templateUrl: './release-order.component.html',
  styleUrls: ['./release-order.component.css']
})
export class ReleaseOrderComponent implements OnInit , OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  masterSelected: boolean;
  checkedList: any;
  pageNo = 1;
  pageSize = 4;
  maxSizes = 1;
  // boundaryLinks: boolean = true;
  bulkApproveBtn: boolean = false;
  bulkApproveArr: any[] = [];
  releaseOrderList: any[] = [];
  bulkApproveObj: any;
  bulkRelease: any[] = [];
  bulkReleaseShipToParty: any[] = [];
  bulkReleaseCumulConfirmedQty: any[] = [];
  payloadReleaseOrderDetails: any;
  releaseOrderSearch: any
  checkedRelArr: any[] = [];

  timePeriod = 0;
  timePeriodList : any [] =[];


  constructor(private purchaseService: PurchaseManagementService, private dialog: MatDialog, private releaseOrderService: ReleaseOrderService, private loaderService: LoaderService) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
    this.fetchReleaseOrderDetails();
    this.filterValidation();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  fetchReleaseOrderDetails() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadReleaseOrderDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: "BO",
          regions: [],
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      } else {
        this.payloadReleaseOrderDetails = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: "BO",
          regions: this.user?.userRegion,
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadReleaseOrderDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.blockedSalesDetails != null) {
          this.releaseOrderList = data?.blockedSalesDetails;
        }
      })
    }

    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadReleaseOrderDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: "BO",
          regions: [],
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      } else {
        this.payloadReleaseOrderDetails = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: "BO",
          regions: this.user?.userRegion,
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadReleaseOrderDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.blockedSalesDetails != null) {
          this.releaseOrderList = data?.blockedSalesDetails;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadReleaseOrderDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: "BO",
          regions: [],
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadReleaseOrderDetails = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: "BO",
          regions: [],
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      }
      else if (this.region) {
        this.payloadReleaseOrderDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: "BO",
          regions: [this.region],
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      } else {
        this.payloadReleaseOrderDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: "BO",
          regions: [],
          text: this.releaseOrderSearch,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadReleaseOrderDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.blockedSalesDetails != null) {
          this.releaseOrderList = data?.blockedSalesDetails;
        }
      })
    }

  }

  checkUncheckAll(evt) {
    this.checkedRelArr = [];
    for (var i = 0; i < this.releaseOrderList.length; i++) {
      this.releaseOrderList[i].isSelected = this.masterSelected;
    }
    this.getCheckedItemList();
    
    if (evt.target.checked) {
      this.bulkApproveBtn = true;
    } else {
      this.bulkApproveBtn = false;
    }

  }

  isAllSelected(evt, item) {
    if (evt.target.checked) {
      if (this.checkedRelArr.length > 0 ) {
        this.bulkApproveBtn = true;
      }
      this.checkedRelArr.push(item);
    } else {
      this.checkedRelArr.splice(item, 1);

      if (this.checkedRelArr.length == 1) {
        this.bulkApproveBtn = false;
      }
    }

    this.masterSelected = this.releaseOrderList.every(function (item: any) {
      return item.isSelected == true;
    })

    this.getCheckedItemList();
  }

  getCheckedItemList() {
    this.checkedList = [];
    for (var i = 0; i < this.releaseOrderList.length; i++) {
      if (this.releaseOrderList[i].isSelected)
        this.checkedList.push(this.releaseOrderList[i]);
    }
    this.checkedList = JSON.stringify(this.checkedList);
  }

  releaseOrder(item) {
    if (!item.isSelected) {
      Swal.fire(alertPopup.releaseOrderChecked);
    } else {
      this.dialog.open(ReleaseOrderPopupComponent, { disableClose: true, width: '60%', height: '65%', data: item });
    }
  }

  bulkApprove() {
    this.bulkRelease = [];
    this.bulkReleaseCumulConfirmedQty = [];
    this.bulkReleaseShipToParty = [];

    this.releaseOrderList.forEach(ele => {
      if (ele.isSelected) {
        this.bulkRelease.push(ele.delvOrderNo);
        this.bulkReleaseCumulConfirmedQty.push(ele.cumulConfirmedQty);
        this.bulkReleaseShipToParty.push(ele.shipToParty);
      }
    })
    this.bulkApproveObj = { callFrom: 'Bulk Approve', bulkDelvOrderNo: this.bulkRelease, bulkCumulConfirmedQty: this.bulkReleaseCumulConfirmedQty, bulkShipToParty: this.bulkReleaseShipToParty };
    this.dialog.open(ReleaseOrderPopupComponent, { disableClose: true, width: '60%', height: '40%', data: this.bulkApproveObj });
  }

  searchReleaseOrder() {
    this.fetchReleaseOrderDetails();
  }

}
