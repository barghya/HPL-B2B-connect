import { Component, OnInit, OnDestroy } from '@angular/core';
import * as moment from 'moment';
import { AccountManagementService } from 'src/app/services/accounts-management/account-management.service';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { AccountsChartDetailsPopupComponent } from '../accounts-chart-details-popup/accounts-chart-details-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ReplaySubject, takeUntil } from 'rxjs';
import { SalesOrderChartDetailsPopupComponent } from '../sales-order-chart-details-popup/sales-order-chart-details-popup.component';


@Component({
  selector: 'app-account-management',
  templateUrl: './account-management.component.html',
  styleUrls: ['./account-management.component.css']
})
export class AccountManagementComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');
  selectedIndex: number;
  pageNo = 1;
  payloadAccountManagementData: any;
  payloadAccountManagementAgeingChartData: any;
  accountManagementCountDetails: any;
  accountManagementAgeingChartDetails: any;
  payloadSalesPurchaseLineChartData: any;
  accountManagementSalesPurchaseTrendLineChartDetails: any;
  allAccountDetailsData: any;
  payloadAllAccountDetails: any;
  tabLabels: any;
  isTotalSalesPurchaseTable : boolean = false;
  isAccountLedgerTable : boolean = false;
  isPaymentStatusTable : boolean = false;
  isOutstandingStatusTable : boolean = false;
  payloadDownloadIndividualTile: any;
  payloadDownloadAgeingChart: any;
  isTotalPurchaseTable: boolean = false;
  isAccountLedgerTableData: boolean = false;
  isPendingInvoicesTableData: boolean = false;
  isOutstabdingCrDrTableData: boolean = false;
  payloadAccountRecentTransactionsData: any;
  accountManagementRecentTransactionsDetails: any[] = [];
  accountSearch: any;
  timePeriod = 0;
  timePeriodList : any [] =[];
  invoiceNo:any = 'All';
  customerType:any = 'Customer';
  productType:any = 'All';
  getTotalSalesAccDetails: any;
  getPurchaseAccDetails: any;
  getAccLedgerDetails: any;
  getPendingInvoiceDetails: any;
  getAccCrDrDetails: any;
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');
  gccChartData: any;
  


  constructor(private router: Router, private dialog: MatDialog, private purchaseService: PurchaseManagementService, private loaderService: LoaderService, private accountService: AccountManagementService){
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalSalesAcc')) {
      this.getTotalSalesAccDetails = this.router.getCurrentNavigation().extras.state['dataTotalSalesAcc'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileTotalPurAcc')) {
      this.getPurchaseAccDetails = this.router.getCurrentNavigation().extras.state['dataTotalPurchaseAcc'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileAccLedger')) {
      this.getAccLedgerDetails = this.router.getCurrentNavigation().extras.state['dataAccLedger'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileAccPendingInvoice')) {
      this.getPendingInvoiceDetails = this.router.getCurrentNavigation().extras.state['dataAccPendingInvoice'];
    }
    if (this.router.getCurrentNavigation().extras.state && sessionStorage.getItem('callFromTileAccCrDr')) {
      this.getAccCrDrDetails = this.router.getCurrentNavigation().extras.state['dataAccCrDr'];
    }
  }


  ngOnInit(): void {
    gridUtilObj.resizeGrid();  
    this.getAccountManagementCountData();
    this.getAgeingChartData();
    this.getSalesPurchaseTrendLineChart();
    this.tabNameChange();
    this.getRecentTransactionsData();
    this.fetchTableDetails();

    if(this.getTotalSalesAccDetails == undefined && this.getPurchaseAccDetails == undefined && this.getAccLedgerDetails == undefined && this.getPendingInvoiceDetails == undefined && this.getAccCrDrDetails == undefined){
      this.allAccountDetails();
    }
    this.filterValidation();

    if(this.viewAs == 'GCC'){
      this.getGCCChart();
    }
  }

  getGCCChart(){
    let payload = {
      gccDate: null,
      gccCode: this.viewAsGCC,
      loginFromApp: false
    }

    this.loaderService.show();
    this.purchaseService.gccGraph(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if(data && data != null){
        this.gccChartData = data;
      }
    })
  }

  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  fetchTableDetails(){
    if(this.getTotalSalesAccDetails?.state?.callFrom == "Total Sales Acc"){
     this.totalSalesValueAccount();
    }

    if(this.getPurchaseAccDetails?.state?.callFrom == "Total Purchase Acc"){
     this.totalPurchaseValueAccount();
    }

    if(this.getAccLedgerDetails?.state?.callFrom == "Account Ledger"){
      this.accountLedgerCurrBalance();
    }

    if(this.getPendingInvoiceDetails?.state?.callFrom == "Account Pending Invoices"){
      this.paymentStatusPendingInvoice();
    }

    if(this.getAccCrDrDetails?.state?.callFrom == "Account Cr Dr"){
      this.OutstandingCrDrStatus();
    }

  }


  tabNameChange(){
    if(this.user?.userTypeId == 3 || this.user?.userTypeId == 2){
      this.tabLabels = Constants.normalText.totalPurchase;
    }else{
      this.tabLabels = Constants.normalText.totalSales;
    }
  }

  informationChange(event: any) {
    this.selectedIndex = event;
    this.pageNo = 1;
  }

  getRecentTransactionsData(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.recentTransactions(this.payloadAccountRecentTransactionsData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getRecentTransactions != null) {
          this.accountManagementRecentTransactionsDetails = data?.getRecentTransactions;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.accountService.recentTransactions(this.payloadAccountRecentTransactionsData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getRecentTransactions != null) {
          this.accountManagementRecentTransactionsDetails = data?.getRecentTransactions;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: [this.region],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAccountRecentTransactionsData = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.recentTransactions(this.payloadAccountRecentTransactionsData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.getRecentTransactions != null) {
          this.accountManagementRecentTransactionsDetails = data?.getRecentTransactions;
        }
      })
    }
  }

  getAccountManagementCountData() {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [this.region],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    }

  }

  getAgeingChartData(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsAgeingChartDetails(this.payloadAccountManagementAgeingChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.chartEntry != null) {
          this.accountManagementAgeingChartDetails = data?.chartEntry;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.accountService.accountsAgeingChartDetails(this.payloadAccountManagementAgeingChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.chartEntry != null) {
          this.accountManagementAgeingChartDetails = data?.chartEntry;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: [this.region],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAccountManagementAgeingChartData = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsAgeingChartDetails(this.payloadAccountManagementAgeingChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.chartEntry != null) {
          this.accountManagementAgeingChartDetails = data?.chartEntry;
        }
      })
    }

  }

  getSalesPurchaseTrendLineChart(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          regions: this.user?.userRegion,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementValueQtyChart(this.payloadSalesPurchaseLineChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.chartEntry != null) {
          this.accountManagementSalesPurchaseTrendLineChartDetails = data?.chartEntry;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.purchaseService.purchaseManagementValueQtyChart(this.payloadSalesPurchaseLineChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.chartEntry != null) {
          this.accountManagementSalesPurchaseTrendLineChartDetails = data?.chartEntry;
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          regions: [],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region) {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: [this.region],
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadSalesPurchaseLineChartData = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementValueQtyChart(this.payloadSalesPurchaseLineChartData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.chartEntry != null) {
          this.accountManagementSalesPurchaseTrendLineChartDetails = data?.chartEntry;
        }
      })
    }

  }

  allAccountDetailsForIndividualTile(codeData) {
    this.allAccountDetailsData = null;

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.allAccountDetailsData = data?.entries;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.allAccountDetailsData = data?.entries;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: [this.region],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: codeData,
          excelToggleCode: null,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries != null) {
          this.allAccountDetailsData = data?.entries;
        }
      })
    }

  }

  allAccountDetails() {
    this.isTotalPurchaseTable = true;
    let code = Constants.normalText.tp;
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          sliderEnabled: true,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          sliderEnabled: true,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          sliderEnabled: true,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          sliderEnabled: true,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [this.region],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
  }

  totalSalesValueAccount(){
    this.allAccountDetailsData = null;
    // this.accountSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.totalSales;
    this.isTotalPurchaseTable = true;
    this.isAccountLedgerTableData = false;
    this.isPendingInvoicesTableData = false;
    this.isOutstabdingCrDrTableData = false;

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [this.region],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }

    // let code = Constants.normalText.tp;
    // this.allAccountDetailsForIndividualTile(code);
    // this.isTotalSalesPurchaseTable = true;
    // this.isAccountLedgerTable = false;
    // this.isPaymentStatusTable = false;
    // this.isOutstandingStatusTable = false;
  }

  totalPurchaseValueAccount(){
    this.allAccountDetailsData = null;
    // this.accountSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.totalPurchase;
    this.isTotalPurchaseTable = true;
    this.isAccountLedgerTableData = false;
    this.isPendingInvoicesTableData = false;
    this.isOutstabdingCrDrTableData = false;
    
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else {
        this.payloadAllAccountDetails = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: [this.region],
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }else {
        this.payloadAllAccountDetails = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: Constants.normalText.tp,
          regions: this.user?.userRegion,
          text: this.accountSearch,
          gccCode: this.viewAsGCC,
          sliderEnabled: true,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.purchaseService.purchaseManagementDetails(this.payloadAllAccountDetails).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.salesDetails != null) {
          this.allAccountDetailsData = data?.salesDetails;
        }
      })
    }
    
    // let code = Constants.normalText.tp;
    // this.allAccountDetailsForIndividualTile(code);
    // this.isTotalSalesPurchaseTable = true;
    // this.isAccountLedgerTable = false;
    // this.isPaymentStatusTable = false;
    // this.isOutstandingStatusTable = false;
  }

  accountLedgerCurrBalance(){
    this.allAccountDetailsData = null;
    // this.accountSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.accountLedger;
    let code = Constants.normalText.al;
    this.allAccountDetailsForIndividualTile(code);
    this.isAccountLedgerTableData = true;
    this.isTotalPurchaseTable = false;
    this.isPendingInvoicesTableData = false;
    this.isOutstabdingCrDrTableData = false;
  }

  paymentStatusPendingInvoice(){
    this.allAccountDetailsData = null;
    // this.accountSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.paymentStatus;
    let code = Constants.normalText.ps;
    this.allAccountDetailsForIndividualTile(code);
    this.isPendingInvoicesTableData = true;
    this.isAccountLedgerTableData = false;
    this.isTotalPurchaseTable = false;
    this.isOutstabdingCrDrTableData = false;
  }

  OutstandingCrDrStatus(){
    this.allAccountDetailsData = null;
    // this.accountSearch = null;
    this.selectedIndex = 1;
    this.tabLabels = Constants.normalText.outstandingStatus;
    let code = Constants.normalText.os;
    this.allAccountDetailsForIndividualTile(code);
    this.isOutstabdingCrDrTableData = true;
    this.isPendingInvoicesTableData = false;
    this.isAccountLedgerTableData = false;
    this.isTotalPurchaseTable = false;
  }

  downloadForIndividualTile(codeData, fileName) {
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: [this.region],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: codeData,
          regions: this.user.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = fileName + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadTableDataPurchase(){
    if (this.tabLabels == Constants.normalText.totalSales) {
      // this.downloadForIndividualTile(Constants.normalText.tp,'Total_Sales_');
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: this.user?.userRegion,
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = "Total_Sales_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: this.user?.userRegion,
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = "Total_Sales_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [this.region],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: this.user?.userRegion,
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = "Total_Sales_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
    }
    else if (this.tabLabels == Constants.normalText.totalPurchase) {
      // this.downloadForIndividualTile(Constants.normalText.tp,'Total_Purchase_');
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: this.user?.userRegion,
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = "Total_Purchase_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: this.user?.userRegion,
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = "Total_Purchase_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: [this.region],
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: Constants.normalText.tp,
            regions: this.user?.userRegion,
            userType: "BU",
            gccCode: this.viewAsGCC,
            sliderEnabled: true,
            loginFromApp: false
          }
        }
  
        this.loaderService.show();
        this.purchaseService.downloadTableDataPurchaseManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(data);
          link.download = "Total_Purchase_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
          link.click();
        })
      }
    }
    else if (this.tabLabels == Constants.normalText.accountLedger) {
      this.downloadForIndividualTile(Constants.normalText.al,'Account_Ledger_');
    }
    else if (this.tabLabels == Constants.normalText.paymentStatus) {
      this.downloadForIndividualTile(Constants.normalText.ps,'Payment_Status_');
    }
    else if (this.tabLabels == Constants.normalText.outstandingStatus) {
      this.downloadForIndividualTile(Constants.normalText.os,'Cr_Dr_Details_');
    }
  }

  downloadTotalSalesValueReport(){
    // if (this.user?.userTypeId == 2) {
    //   if (this.filterCode) {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [this.filterCode.encrypt()],
    //       payer: [],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: this.user.userRegion,
    //       loginFromApp: false
    //     }
    //   } else {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [],
    //       payer: [this.user.userId],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: this.user.userRegion,
    //       loginFromApp: false
    //     }
    //   }

    //   this.loaderService.show();
    //   this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
    //     this.loaderService.hide();
    //     var link = document.createElement('a');
    //     link.href = window.URL.createObjectURL(data);
    //     link.download = "Total_Sales_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
    //     link.click();
    //   })
    // }
    // else if (this.user?.userTypeId == 3) {
    //   if (this.filterCode) {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [this.filterCode.encrypt()],
    //       payer: [],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: this.user.userRegion,
    //       loginFromApp: false
    //     }
    //   } else {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [this.user.userId],
    //       payer: [],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: this.user.userRegion,
    //       loginFromApp: false
    //     }
    //   }

    //   this.loaderService.show();
    //   this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
    //     this.loaderService.hide();
    //     var link = document.createElement('a');
    //     link.href = window.URL.createObjectURL(data);
    //     link.download = "Total_Sales_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
    //     link.click();
    //   })
    // }
    // else {
    //   if (this.viewAs == Constants.normalText.customer && this.filterCode) {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [this.filterCode.encrypt()],
    //       payer: [],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: [],
    //       loginFromApp: false
    //     }
    //   }
    //   else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [],
    //       payer: [this.filterCode.encrypt()],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: [],
    //       loginFromApp: false
    //     }
    //   } else {
    //     this.payloadDownloadIndividualTile = {
    //       customerCodes: [],
    //       payer: [],
    //       monthInterval: null,
    //       toggleCode: null,
    //       excelToggleCode: "LC",
    //       regions: this.user.userRegion,
    //       loginFromApp: false
    //     }
    //   }

    //   this.loaderService.show();
    //   this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
    //     this.loaderService.hide();
    //     var link = document.createElement('a');
    //     link.href = window.URL.createObjectURL(data);
    //     link.download = "Total_Sales_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
    //     link.click();
    //   })
    // }

    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Total_Sales_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Total_Sales_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          regions: [],
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      } else if(this.region){
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: [this.region],
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      }else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          loginFromApp: false,
          gccCode: this.viewAsGCC,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Total_Sales_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }

  }

  downloadPaymentStausInvoiceQtyReport(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Payment_Status_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Payment_Status_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: [this.region],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C1",
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Payment_Status_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }

  downloadOutstandingStausValueReport(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Cr_Dr_Details_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Cr_Dr_Details_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }  else if(this.region){
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: [this.region],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "C2",
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.downloadTableDataAccountManagement(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Cr_Dr_Details_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }

  downloadSalesComparisonGccWiseValueReport(){
    let payload = {
      gccDate: null,
      gccCode: this.viewAsGCC.encrypt(),
      userType: "BU",
      loginFromApp: false
    }

    this.loaderService.show();
    this.purchaseService.downloadSalesComparisonGccWiseQtyVal(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(data);
      link.download = "GCC_Value_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
      link.click();
    })
  }

  downloadOverallPurchaseTrendValueReport(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: this.timePeriod,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          toggleCode: null,
          excelToggleCode: "LC",
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: this.timePeriod,
          loginFromApp: false,
          userType: "BU",
          gccCode: this.viewAsGCC,
          regions: [],
        }
      }  else if(this.region){
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          regions: [this.region],
          payer: [],
          monthInterval: this.timePeriod,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadDownloadIndividualTile = {
          customerCodes: [],
          payer: [],
          monthInterval: this.timePeriod,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadPurchaseTrendValueQtyReport(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Overall_Purchase_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }

  searchAccount(){
    if (this.tabLabels == Constants.normalText.totalSales) {
      this.totalSalesValueAccount();
    }
    else if (this.tabLabels == Constants.normalText.totalPurchase) {
      this.totalPurchaseValueAccount();
    }
    else if (this.tabLabels == Constants.normalText.accountLedger) {
      this.allAccountDetailsForIndividualTile(Constants.normalText.al);
    }
    else if (this.tabLabels == Constants.normalText.paymentStatus) {
      this.allAccountDetailsForIndividualTile(Constants.normalText.ps);
    }
    else if (this.tabLabels == Constants.normalText.outstandingStatus) {
      this.allAccountDetailsForIndividualTile(Constants.normalText.os);
    }
   
  }

  downloadAgeingAvgReport(){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadDownloadAgeingChart = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadAgeingChart = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadAccAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Pending_Invoice_Ageing_Average_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadDownloadAgeingChart = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else {
        this.payloadDownloadAgeingChart = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadAccAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Pending_Invoice_Ageing_Average_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
    else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadDownloadAgeingChart = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadDownloadAgeingChart = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: null,
          regions: [],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      } else if(this.region){
        this.payloadDownloadAgeingChart = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: [this.region],
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }else {
        this.payloadDownloadAgeingChart = {
          customerCodes: [],
          payer: [],
          monthInterval: null,
          regions: this.user?.userRegion,
          userType: "BU",
          gccCode: this.viewAsGCC,
          loginFromApp: false,
        }
      }

      this.loaderService.show();
      this.purchaseService.downloadAccAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(data);
        link.download = "Pending_Invoice_Ageing_Average_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
        link.click();
      })
    }
  }

  monthIntervalData(evt){
    if (this.user?.userTypeId == 2) {
      if (this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: evt,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [this.user.userId],
          monthInterval: evt,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    }
    else if (this.user?.userTypeId == 3) {
      if (this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: evt,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else {
        this.payloadAccountManagementData = {
          customerCodes: [this.user.userId],
          payer: [],
          monthInterval: evt,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }


      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    } else {
      if (this.viewAs == Constants.normalText.customer && this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [this.filterCode.encrypt()],
          payer: [],
          monthInterval: evt,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }
      else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [this.filterCode.encrypt()],
          monthInterval: evt,
          regions: [],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      } else if(this.region){
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: evt,
          regions: [this.region],
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }else {
        this.payloadAccountManagementData = {
          customerCodes: [],
          payer: [],
          monthInterval: evt,
          regions: this.user?.userRegion,
          excelToggleCode: null,
          toggleCode: null,
          gccCode: this.viewAsGCC,
          loginFromApp: false
        }
      }

      this.loaderService.show();
      this.accountService.accountsCountDetails(this.payloadAccountManagementData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data && data?.entries[0] != null) {
          this.accountManagementCountDetails = data?.entries[0];
        }
      })
    }

  }

  openDetailsDataPopupForExcel(text){

    if(text == 'chart1' && this.user?.userTypeId == 1 && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: [this.region],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData}});
          }
        })
      }
  
    }

    if(text == 'chart1' && (this.user?.userTypeId == 2 || this.user?.userTypeId == 3) && this.viewAs != 'GCC'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }  else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: [this.region],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.getChartExcelData != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart1', chartData: data?.getChartExcelData}});
          }
        })
      }
    }

    if(text == 'chart1' && this.viewAs == 'GCC'){
      let payload = {
        gccDate: null,
        gccCode: this.viewAsGCC.encrypt(),
        loginFromApp: false,
        type: 'details'
      }
  
      this.loaderService.show();
      this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if(data && data != null){
          this.dialog.open(SalesOrderChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data, gccDate:null,  gccCode: this.viewAsGCC.encrypt()}});
        }
      })
    }

    if(text == 'chart2'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.entries}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.entries}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: [this.region],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C1",
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart2', chartData: data?.entries}});
          }
        })
      }
    }

    if(text == 'chart3'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data?.entries}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data?.entries}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }  else if(this.region){
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: [this.region],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadIndividualTile = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            toggleCode: null,
            excelToggleCode: "C2",
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.accountService.excelDetailsPaymentOutstandingStatus(this.payloadDownloadIndividualTile).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.entries != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart3', chartData: data?.entries}});
          }
        })
      }
    }

    if(text == 'chart4'){
      if (this.user?.userTypeId == 2) {
        if (this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [this.user.userId],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.ageingChartDetails != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data?.ageingChartDetails}});
          }
        })
      }
      else if (this.user?.userTypeId == 3) {
        if (this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.user.userId],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.ageingChartDetails != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data?.ageingChartDetails}});
          }
        })
      }
      else {
        if (this.viewAs == Constants.normalText.customer && this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [this.filterCode.encrypt()],
            payer: [],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
        else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [this.filterCode.encrypt()],
            monthInterval: null,
            regions: [],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        } else if(this.region){
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: [this.region],
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }else {
          this.payloadDownloadAgeingChart = {
            customerCodes: [],
            payer: [],
            monthInterval: null,
            regions: this.user?.userRegion,
            loginFromApp: false,
            gccCode: this.viewAsGCC,
            type: 'details'
          }
        }
  
        this.loaderService.show();
        this.purchaseService.excelAgeingChartData(this.payloadDownloadAgeingChart).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if(data && data?.ageingChartDetails != null){
            this.dialog.open(AccountsChartDetailsPopupComponent, { disableClose: true, width: '80%', height: '93%', data: {text: 'chart4', chartData: data?.ageingChartDetails}});
          }
        })
      }
    }

  }

  goBackToHome(){
    this.router.navigate(['/home']).then(success => {
      window.location.reload();
    });
    sessionStorage.removeItem('dispatchFilter');
    sessionStorage.removeItem('complaintFilter');
    sessionStorage.removeItem('salesTimeinterval');
    sessionStorage.removeItem('tabIndex');
    sessionStorage.removeItem('sliderGcc');
  }


}
