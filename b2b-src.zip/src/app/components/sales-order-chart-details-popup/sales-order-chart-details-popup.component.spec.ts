import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesOrderChartDetailsPopupComponent } from './sales-order-chart-details-popup.component';

describe('SalesOrderChartDetailsPopupComponent', () => {
  let component: SalesOrderChartDetailsPopupComponent;
  let fixture: ComponentFixture<SalesOrderChartDetailsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SalesOrderChartDetailsPopupComponent]
    });
    fixture = TestBed.createComponent(SalesOrderChartDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
