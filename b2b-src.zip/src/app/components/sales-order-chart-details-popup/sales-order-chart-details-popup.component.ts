import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReplaySubject, takeUntil } from 'rxjs';
import { PurchaseManagementService } from 'src/app/services/purchase-management/purchase-management.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';

@Component({
  selector: 'app-sales-order-chart-details-popup',
  templateUrl: './sales-order-chart-details-popup.component.html',
  styleUrls: ['./sales-order-chart-details-popup.component.css']
})
export class SalesOrderChartDetailsPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  tableSearchSales: any;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  gccSlider = sessionStorage.getItem('sliderGcc');
  gccValue = JSON.parse(sessionStorage.getItem('gcc'));
  salesTimeInterval = sessionStorage.getItem('salesTimeinterval');
  viewAsGCC = sessionStorage.getItem('filterCodeGCC');
  pageNo = 1;
  payloadDownloadOverallPurchaseTrendValueQtyReport: any;
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  region = sessionStorage.getItem('region');


  constructor(private loaderService: LoaderService, private purchaseService: PurchaseManagementService, private dialogRef: MatDialogRef<SalesOrderChartDetailsPopupComponent>, @Inject(MAT_DIALOG_DATA) public excelChartData: any) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  searchtableSales() {
    if (this.gccSlider == 'On GCC'){
      if (this.excelChartData?.text == 'chart1' || this.excelChartData?.text == 'chart2') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.salesTimeInterval,
              regions: this.user?.userRegion,
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.excelChartData.chartData = data?.getChartExcelData;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: this.user?.userRegion,
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.excelChartData.chartData = data?.getChartExcelData;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          } else if (this.region) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [this.region],
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: this.user?.userRegion,
              loginFromApp: false,
              type: 'details',
              gccCode: this.user?.gccData[0]?.gccCode ? this.user?.gccData[0]?.gccCode : this.gccValue?.gccCode,
              text: this.tableSearchSales
            }
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.excelChartData.chartData = data?.getChartExcelData;
            }
          })
        }
      }
  
      else {
        let payload = {
          gccDate: this.excelChartData?.gccDate ? this.excelChartData?.gccDate : this.gccValue?.gccBillingDate,
          gccCode: this.excelChartData?.gccCode ? this.excelChartData?.gccCode : this.gccValue?.gccCode,
          loginFromApp: false,
          type: 'details',
          text: this.tableSearchSales
        }
  
        this.loaderService.show();
        this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data && data != null) {
            this.excelChartData.chartData = data;
          }
        })
      }
    }else{
      if (this.excelChartData?.text == 'chart1' || this.excelChartData?.text == 'chart2') {
        if (this.user?.userTypeId == 2) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.user.userId],
              monthInterval: this.salesTimeInterval,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.excelChartData.chartData = data?.getChartExcelData;
            }
          })
        }
        else if (this.user?.userTypeId == 3) {
          if (this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.user.userId],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.excelChartData.chartData = data?.getChartExcelData;
            }
          })
        }
        else {
          if (this.viewAs == Constants.normalText.customer && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [this.filterCode.encrypt()],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          }
          else if (this.viewAs == Constants.normalText.salesAgent && this.filterCode) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [this.filterCode.encrypt()],
              monthInterval: this.salesTimeInterval,
              regions: [],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          } else if (this.region) {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: [this.region],
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          } else {
            this.payloadDownloadOverallPurchaseTrendValueQtyReport = {
              customerCodes: [],
              payer: [],
              monthInterval: this.salesTimeInterval,
              regions: this.user?.userRegion,
              loginFromApp: false,
              gccCode : this.viewAsGCC,
              type: 'details',
              text: this.tableSearchSales
            }
          }
  
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesQty(this.payloadDownloadOverallPurchaseTrendValueQtyReport).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data?.getChartExcelData != null) {
              this.excelChartData.chartData = data?.getChartExcelData;
            }
          })
        }
      }
  
      else {
        if(this.viewAs != 'GCC'){
          let payload = {
            gccDate: this.excelChartData?.gccDate,
            gccCode: this.excelChartData?.gccCode,
            loginFromApp: false,
            type: 'details',
            text: this.tableSearchSales
          }
    
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data != null) {
              this.excelChartData.chartData = data;
            }
          })
        }else{
          let payload = {
            gccDate: null,
            gccCode: this.viewAsGCC.encrypt(),
            loginFromApp: false,
            type: 'details',
            text: this.tableSearchSales
          }
    
          this.loaderService.show();
          this.purchaseService.excelDataForOverallSalesGcc(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
            this.loaderService.hide();
            if (data && data != null) {
              this.excelChartData.chartData = data;
            }
          })
        }
       
      }
    }
  

  }


  closePopup() {
    this.dialogRef.close();
  }

}
