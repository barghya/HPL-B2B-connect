import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintsDownloadPopupComponent } from './complaints-download-popup.component';

describe('ComplaintsDownloadPopupComponent', () => {
  let component: ComplaintsDownloadPopupComponent;
  let fixture: ComponentFixture<ComplaintsDownloadPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ComplaintsDownloadPopupComponent]
    });
    fixture = TestBed.createComponent(ComplaintsDownloadPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
