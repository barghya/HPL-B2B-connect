import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DownloadService } from 'src/app/services/download/download.service';
import { saveAs } from 'file-saver';
import { ReplaySubject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-complaints-download-popup',
  templateUrl: './complaints-download-popup.component.html',
  styleUrls: ['./complaints-download-popup.component.css']
})
export class ComplaintsDownloadPopupComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  pageNo = 1;


  constructor(private downloadService: DownloadService, private dialogRef: MatDialogRef<ComplaintsDownloadPopupComponent>, @Inject(MAT_DIALOG_DATA) public downComData: any){}

  ngOnInit(): void {
    gridUtilObj.resizeGrid();
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  closePopup(){
    this.dialogRef.close();
  }

  downloadFile(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

}
