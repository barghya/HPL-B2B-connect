import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributionCalculatorComponent } from './contribution-calculator.component';

describe('ContributionCalculatorComponent', () => {
  let component: ContributionCalculatorComponent;
  let fixture: ComponentFixture<ContributionCalculatorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ContributionCalculatorComponent]
    });
    fixture = TestBed.createComponent(ContributionCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
