import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Observable, ReplaySubject, map, startWith, takeUntil } from 'rxjs';
import { ContributionCalculatorService } from 'src/app/services/contribution-calculator/contribution-calculator.service';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonService } from 'src/app/utils/common-service';
import { LoaderService } from 'src/app/utils/loader-service';
import Swal from 'sweetalert2';
import { CcMailPopupComponent } from '../cc-mail-popup/cc-mail-popup.component';

@Component({
  selector: 'app-contribution-calculator',
  templateUrl: './contribution-calculator.component.html',
  styleUrls: ['./contribution-calculator.component.css']
})
export class ContributionCalculatorComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  ccBillToParty: any;
  ccShipToParty: any;
  ccGrade = new FormControl('');
  ccBillToPartyIdName = new FormControl('');
  ccLocation: any;
  ccAdditionalDiscount: any;
  ccQty: any;
  ccAddlQty: any;
  ccProductType: any;
  productTypeArr = ["HDPE", "LLDPE", "PP"];
  discountValueForNonCCS: boolean = false;
  childShipToPartyList: any;
  locationArr: any[] = [];
  contributionData: any;
  gradeList: Observable<any[]>;
  billToPartyList: Observable<any[]>;
  netContribution: any;
  overAllAdditionalDiscount: any;
  additionalContribution: any;
  totalContribution: any;
  ccTableData: any[] = [];
  gradeArrList: any[] = [];
  biilToPartyArrList: any[] = [];
  nonCCSEvent = 'ccsCustomer';
  totalContributionPanel: boolean = false;
  totalOfTotalContribution: any;



  constructor(private dialog: MatDialog, private commonservice: CommonService, private contributionCalculatorService: ContributionCalculatorService, private loaderService: LoaderService) { }

  ngOnInit(): void {
    gridUtilObj.resizeGrid();

  }


  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  getBillToParty(){
    let payload= {
      codeOrName: this.ccBillToPartyIdName.value
    }
    
    if(this.ccBillToPartyIdName.value.length > 4){
      this.loaderService.show();
      this.contributionCalculatorService.getBillTpParty(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
  
        this.loaderService.hide();

        if (data && data?.getCustomerList.length > 0) {
          this.biilToPartyArrList = data?.getCustomerList;
          this.billToPartyList = this.ccBillToPartyIdName.valueChanges.pipe(
            startWith(''),
            map(value => this.filterBillToParty(value || '')),
          );
        }
      })
    }else{
      this.biilToPartyArrList = [];
    }
 
  }

  private filterGrade(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.gradeArrList.filter(option => option?.name?.toLowerCase().includes(filterValue));
  }

  private filterBillToParty(value: string): string[] {
    const filterValueBillTpParty = value.toLowerCase();
    return this.biilToPartyArrList.filter(option => option?.customerName?.toLowerCase().includes(filterValueBillTpParty));
  }

  getGrade() {
    let payload = {
      product : this.ccProductType,
    }

    this.loaderService.show();
    this.contributionCalculatorService.getGradebyProduct(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();

      if (data && data != null) {
        this.gradeArrList = data;
        this.gradeList = this.ccGrade.valueChanges.pipe(
          startWith(''),
          map(value => this.filterGrade(value || '')),
        );
      }
    })

  }

  calculateCC() {
    let validAddDic = this.commonservice.regexForNumericandDecimalNumber(this.ccAdditionalDiscount);
    let validCCSQty = this.commonservice.regexForNumericandDecimalNumber(this.ccQty);
    let validAddQty = this.commonservice.regexForNumericandDecimalNumber(this.ccAddlQty);

    if (!this.ccBillToPartyIdName.value) {
      Swal.fire(alertPopup.billToPartyIdEmpty);
    }
    else if (!this.ccShipToParty) {
      Swal.fire(alertPopup.shipToPartyIdEmpty);
    }
    else if (!this.ccProductType) {
      Swal.fire(alertPopup.productTypeEmpty);
    }
    else if (!this.ccGrade.value) {
      Swal.fire(alertPopup.gradeEmpty);
    }
    else if (!this.ccLocation) {
      Swal.fire(alertPopup.locationEmpty);
    }
    else if (!this.ccAdditionalDiscount) {
      Swal.fire(alertPopup.addlDiscountEmpty);
    }
    else if (!this.ccQty) {
      Swal.fire(alertPopup.ccsQtyEmpty);
    }
    else if (!this.ccAddlQty) {
      Swal.fire(alertPopup.addlQtyEmpty);
    }
    else if (validAddDic) {
      Swal.fire(alertPopup.validAddDis);
    }
    else if (validCCSQty) {
      Swal.fire(alertPopup.validCCSQty);
    }
    else if (validAddQty) {
      Swal.fire(alertPopup.validAddQty);
    }
    else {
      if (this.nonCCSEvent === 'nonccsCustomer') {
        if (this.ccAdditionalDiscount.startsWith(".")) {
          this.ccAdditionalDiscount = 0 + this.ccAdditionalDiscount;
        }
        if (this.ccQty.startsWith(".")) {
          this.ccQty = 0 + this.ccQty;
        }
        if (this.ccAddlQty.startsWith(".")) {
          this.ccAddlQty = 0 + this.ccAddlQty;
        }
        this.netContribution = ((+this.contributionData?.value) - (+this.ccAdditionalDiscount) + (+this.contributionData?.inputNumber)).toFixed(2);
        this.overAllAdditionalDiscount = (((+this.ccQty) + (+this.ccAddlQty)) * (+this.ccAdditionalDiscount)).toFixed(2);
        this.additionalContribution = ((+this.ccAddlQty) * (this.netContribution)).toFixed(2);
        this.totalContribution = (((+this.ccQty) + (+this.ccAddlQty)) * (this.netContribution)).toFixed(2);
      }
      else if (this.nonCCSEvent === 'ccsCustomer') {
        if (this.ccAdditionalDiscount.startsWith(".")) {
          this.ccAdditionalDiscount = 0 + this.ccAdditionalDiscount;
        }
        if (this.ccQty.startsWith(".")) {
          this.ccQty = 0 + this.ccQty;
        }
        if (this.ccAddlQty.startsWith(".")) {
          this.ccAddlQty = 0 + this.ccAddlQty;
        }
        
        this.netContribution = ((+this.contributionData?.value) - (+this.ccAdditionalDiscount)).toFixed(2);
        this.overAllAdditionalDiscount = (((+this.ccQty) + (+this.ccAddlQty)) * (+this.ccAdditionalDiscount)).toFixed(2);
        this.additionalContribution = ((+this.ccAddlQty) * (this.netContribution)).toFixed(2);
        this.totalContribution = (((+this.ccQty) + (+this.ccAddlQty)) * (this.netContribution)).toFixed(2);
      }
    }

  }

  findChildShipToParty(item) {
    let payload = {
      soldToPartyCode: item?.customerCode.encrypt(),
      loginFromApp: false
    }

    this.loaderService.show();
    this.contributionCalculatorService.getChildShipToParty(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data != null) {
        this.childShipToPartyList = data;
        if (data?.shipToPartyDetails[0]?.shipToPartyUserName == null) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: "Customer Code does not exist",
            showConfirmButton: true,
            allowEnterKey: false,
            allowOutsideClick: false
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        }
      }
    })
  }

  getLocation() {
    this.ccLocation = undefined;
    this.contributionData = null;
    this.loaderService.show();
    this.contributionCalculatorService.getLocation().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data != null) {
        this.locationArr = data;
      }
    })
  }

  numbersOnlyAddlDis(){
    if(this.ccAdditionalDiscount){
      this.ccAdditionalDiscount = this.ccAdditionalDiscount.replace(/[^0-9.-]/g, '');
    }
  }

  numbersOnlyCCSQty(){
    if(this.ccQty){
      this.ccQty = this.ccQty.replace(/[^0-9.-]/g, '');
    }
  }

  numbersOnlyAddlQty(){
    if(this.ccAddlQty){
      this.ccAddlQty = this.ccAddlQty.replace(/[^0-9.-]/g, '');
    }
  }

  getContributionData() {

    let payload = {
      grade: this.ccGrade.value,
      location: this.ccLocation,
    }
    this.loaderService.show();
    this.contributionCalculatorService.getContributionData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data != null) {
        this.contributionData = data;
      }
    })

  }

  resetCC() {
    window.location.reload();
  }

  addDetailsTable() {
    if (this.netContribution && this.overAllAdditionalDiscount && this.additionalContribution && this.totalContribution) {
      this.totalContributionPanel = true;
      this.ccTableData.push({
        ccBillToParty: this.ccBillToPartyIdName.value,
        ccShipToParty: this.ccShipToParty,
        ccGrade: this.ccGrade.value,
        ccLocation: this.ccLocation,
        ccRegion: this.contributionData?.region,
        ccContributionPerMt: this.contributionData?.value,
        ccAdditionalDiscountPerMt: this.ccAdditionalDiscount,
        ccTotalContribution: this.totalContribution,
        ccMonth: this.contributionData?.month,
        ccQty: this.ccQty,
        ccAddlQty: this.ccAddlQty,
        ccAdditionContribution: this.additionalContribution,
        netContribution: this.netContribution,
        ccOverallAddlDiscount: this.overAllAdditionalDiscount
      });
    }
    let arr = [];

    this.ccTableData.forEach(ele => {
      arr.push(+ele?.ccTotalContribution);
      var sum = arr.reduce((acc, cur) => acc + cur);
      this.totalOfTotalContribution = sum;

    })
  }

  deleteCCTableRow(item, index) {
    this.ccTableData.splice(index, 1);
    this.totalOfTotalContribution = this.totalOfTotalContribution - parseInt(item?.ccTotalContribution)
  }


  // nonCCSCustomer(evt) {
  //   this.nonCCSEvent = evt?.source?._value;
  //   this.ccTableData = [];
  //   this.discountValueForNonCCS = true;
  //   this.netContribution = "N/A";
  //   this.overAllAdditionalDiscount = "N/A";
  //   this.additionalContribution = "N/A";
  //   this.totalContribution = "N/A";
  //   this.totalContributionPanel = false;
  // }

  // ccsCustomer(evt) {
  //   this.nonCCSEvent = evt?.source?._value;
  //   this.ccTableData = [];
  //   this.discountValueForNonCCS = false;
  //   this.netContribution = "N/A";
  //   this.overAllAdditionalDiscount = "N/A";
  //   this.additionalContribution = "N/A";
  //   this.totalContribution = "N/A";
  //   this.totalContributionPanel = false;
  // }
  
  nonCCSCustomer(evt) {
    this.nonCCSEvent = evt?.source?._value;
    this.ccTableData = [];
    this.discountValueForNonCCS = true;
    this.netContribution = "";
    this.overAllAdditionalDiscount = "";
    this.additionalContribution = "";
    this.totalContribution = "";
    this.totalContributionPanel = false;
  }

  ccsCustomer(evt) {
    this.nonCCSEvent = evt?.source?._value;
    this.ccTableData = [];
    this.discountValueForNonCCS = false;
    this.netContribution = "";
    this.overAllAdditionalDiscount = "";
    this.additionalContribution = "";
    this.totalContribution = "";
    this.totalContributionPanel = false;
  }

  sendDetailPopup() {
    if (this.ccTableData.length != 0) {
      this.dialog.open(CcMailPopupComponent, { disableClose: true, width: '45%', height: '50%', data: this.ccTableData });
    }
  }

}
