import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispatchStatusQtyDonutChartComponent } from './dispatch-status-qty-donut-chart.component';

describe('DispatchStatusQtyDonutChartComponent', () => {
  let component: DispatchStatusQtyDonutChartComponent;
  let fixture: ComponentFixture<DispatchStatusQtyDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DispatchStatusQtyDonutChartComponent]
    });
    fixture = TestBed.createComponent(DispatchStatusQtyDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
