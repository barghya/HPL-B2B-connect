import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ComplaintsDownloadPopupComponent } from '../complaints-download-popup/complaints-download-popup.component';

@Component({
  selector: 'app-dispatch-status-qty-donut-chart',
  templateUrl: './dispatch-status-qty-donut-chart.component.html',
  styleUrls: ['./dispatch-status-qty-donut-chart.component.css']
})
export class DispatchStatusQtyDonutChartComponent implements OnInit {

  @Input() inputDataDispatchStatusQty: any;

  constructor(private dialog: MatDialog) {}

  ngOnInit(): void {
    this.praparedDispatchStatusDonutChartData();
  }

  praparedDispatchStatusDonutChartData(){
    this.inputDataDispatchStatusQty = {
      tooltip: {
        trigger: 'item',
        formatter: 'Qty {c} ({d}%)'
      },
      legend: {
        top: '5%', 
        left: 'center',
      },
      series: [
        {
          type: 'pie',
          radius: ['50%', '30%'],
          center: ['50%', '55%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          color: ['#754827','#BB8C6B','#FFD2D2', '#FCDEC8'],
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: this.inputDataDispatchStatusQty?.dispatchStatus,
        }
      ]
    }
  }
  
  // openPopupValue(){
  //   this.dialog.open(ComplaintsDownloadPopupComponent, { disableClose: true, width: '38%', height: '54%'});
  // }

}
