import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-logistics-complaints-status-donut-chart',
  templateUrl: './logistics-complaints-status-donut-chart.component.html',
  styleUrls: ['./logistics-complaints-status-donut-chart.component.css']
})
export class LogisticsComplaintsStatusDonutChartComponent implements OnInit {

  @Input() inputDataLogisticsComStatus: any;

  constructor() {}

  ngOnInit(): void {
    this.praparedLogisticsComStatusDonutChartData();
  }

  praparedLogisticsComStatusDonutChartData(){
    this.inputDataLogisticsComStatus = {
      tooltip: {
        trigger: 'item',
        formatter: 'Count {c} ({d}%)',
      },
      legend: {
        top: '15%',
        left: 'center'
      },
      series: [
        {
          type: 'pie',
          radius: ['50%', '30%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          color: ['#754827','#FFD2D2'],
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: this.inputDataLogisticsComStatus?.logisticComplaintChart,
        }
      ]
    }
  }

}
