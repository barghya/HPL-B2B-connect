import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogisticsComplaintsStatusDonutChartComponent } from './logistics-complaints-status-donut-chart.component';

describe('LogisticsComplaintsStatusDonutChartComponent', () => {
  let component: LogisticsComplaintsStatusDonutChartComponent;
  let fixture: ComponentFixture<LogisticsComplaintsStatusDonutChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LogisticsComplaintsStatusDonutChartComponent]
    });
    fixture = TestBed.createComponent(LogisticsComplaintsStatusDonutChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
