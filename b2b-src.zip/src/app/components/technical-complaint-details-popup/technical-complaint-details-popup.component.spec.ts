import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalComplaintDetailsPopupComponent } from './technical-complaint-details-popup.component';

describe('TechnicalComplaintDetailsPopupComponent', () => {
  let component: TechnicalComplaintDetailsPopupComponent;
  let fixture: ComponentFixture<TechnicalComplaintDetailsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TechnicalComplaintDetailsPopupComponent]
    });
    fixture = TestBed.createComponent(TechnicalComplaintDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
