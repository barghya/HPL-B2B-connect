import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { Constants } from 'src/app/utils/constants';
import { LoaderService } from 'src/app/utils/loader-service';
import { CustomerActivationPopupComponent } from '../customer-activation-popup/customer-activation-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from 'src/app/utils/common-service';
import { ApiEndPoints } from 'src/app/utils/api-endpoints';
import Swal from 'sweetalert2';
import { alertPopup } from 'src/app/utils/alert-popup';
import { CommonApiService } from 'src/app/services/common/common-api.service';
import { MyTargetService } from 'src/app/services/my-target/my-target.service';
import { Observable, ReplaySubject, map, startWith, takeUntil } from 'rxjs';
import { FormControl } from '@angular/forms';
import * as moment from 'moment';
import { saveAs } from 'file-saver';
import { DownloadService } from 'src/app/services/download/download.service';
import { SendEmailSoCustomerPopupComponent } from '../send-email-so-customer-popup/send-email-so-customer-popup.component';


@Component({
  selector: 'app-customers-management',
  templateUrl: './customers-management.component.html',
  styleUrls: ['./customers-management.component.css']
})
export class CustomersManagementComponent implements OnInit, OnDestroy {

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  selected: any = {};
  subMenuList : any [] = [];
  ammendUserList = ['Basic Details', 'Other Details', 'Files'];
  allSection: boolean = true;
  approvedSection: boolean = false;
  approvalPendingSectionSO: boolean = false;
  activationPendingSection: boolean = false;
  allApproveSection: boolean = false;
  rejectedSection: boolean = false;
  basicDetailsSection: boolean = true;
  otherDetailsSection: boolean = false;
  fileSection: boolean = false;
  user = JSON.parse(sessionStorage.getItem('user') || '');
  filterCode = sessionStorage.getItem('filterCode');
  viewAs = sessionStorage.getItem('viewAs');
  allCustomerData: any[] = [];
  allApprovedCustomerData: any[] = [];
  allApprovalPendingCustomerData: any[] = [];
  allActivationPendingCustomerRMData: any[] = [];
  allActivationPendingCustomerData: any[] = [];
  allRejectedCustomerData: any[] = [];
  allApprovedCustData: any[] = [];
  custDetails: boolean = true;
  amendmentDetails: boolean = false;
  allViewForOfficer: boolean = true;
  officersView: boolean = false;
  individualCustomerData: any;
  companyNameCustomerAmendment: any;
  phoneCustomerAmendment: any;
  emailCustomerAmendment: any;
  addressCustomerAmendment: any;
  countryCustomerAmendment: any;
  faxCustomerAmendment: any;
  payloadDetailIndividualCustomer: any;
  payloadAllCustomer: any;
  salesOfficerRemarks: any;
  isFileUploaded: any;
  fileAdded: boolean;
  file: File = null;
  regionalMarketingRemarks: any;
  headMarketingRemarks: any;
  individualBusinessOfiicerData: any;
  onboardingCustCode: any;
  onboardingRegion: any;
  onboardingCustType: any;
  regionArr: any[] = [];
  custType: any[] = [];
  individualCustomer: any;
  phoneNoCustAmendment: any;
  emailIdCustAmendment: any;
  descriptionCustAmendment: any;
  mainOfficersData: boolean = false;
  custCodeArr: any[] = [];
  filteredCustCode: Observable<any[]>;
  customerCodeControl = new FormControl('');
  customerCode: any;
  uploadDataRes: any;
  selectedItem: any;
  rejectedPanelSO: boolean = false;
  rejectedPanelRM: boolean = false;
  rejectedPanelPH: boolean = false;
  onboardingCustTypeRM: any;
  salesOfficerRemarksSecondLevel: any;
  isAllapprved: boolean = false;
  isInactive: boolean = false;
  isActiveViewDetailsRM: boolean = false;
  activationPendingSectionRM: boolean = false;
  allApprovalPendingCustomerBHData: any[] = [];
  allApprovalPendingCustomerSOData: any[] = [];
  activationPendingSectionBH: boolean = false;
  activationPendingSectionSO: boolean = false;
  customerOnboardingSearch: any;
  timePeriod = 0;
  // timePeriodList : any [] = [];
  timePeriodList = [    
    {id:1, label:'MTD', value: 0},
    {id:2, label:'YTD', value: 1},
  ]
  selectedMenu: any;

  @ViewChild('myInputFile1')
  myInputVariable1: ElementRef;
  fileArr1: any[] = [];

  @ViewChild('myInputFile2')
  myInputVariable2: ElementRef;
  fileArr2: any[] = [];

  @ViewChild('myInputFile3')
  myInputVariable3: ElementRef;
  fileArr3: any[] = [];

  @ViewChild('myInputFile4')
  myInputVariable4: ElementRef;
  fileArr4: any[] = [];

  @ViewChild('myInputFile5')
  myInputVariable5: ElementRef;
  fileArr5: any[] = [];

  isEnabledFilterSearch: boolean = true;


  constructor(private downloadService: DownloadService, private commonservice: CommonService,  private targetService: MyTargetService, private common: CommonApiService, private commonService: CommonService, private dialog: MatDialog, private customerService: CustomerService, private loaderService: LoaderService) { }

  ngOnInit(): void {
    this.selected['main'] = (this.selected['main'] === 'All' ? null : 'All');
    this.submenuRoleBased();
    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 4){
      this.getAllCustomer();
      this.approvalPendingCustomer();
      this.rejectedCustomer();
      this.allApprovedCustomer();
      this.activationPendingCustomer();
      this.approvalPendingCustomerRM();
      this.approvalPendingCustomerBH();
    }

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 3){
      this.getAllCustomer();
      this.approvalPendingCustomer();
      this.rejectedCustomer();
      this.allApprovedCustomer();
      this.activationPendingCustomer();
      this.approvalPendingCustomerSO();
      this.approvalPendingCustomerBH();
    }

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 2){
      this.getAllCustomer();
      this.approvalPendingCustomer();
      this.rejectedCustomer();
      this.allApprovedCustomer();
      this.activationPendingCustomer();
      this.approvalPendingCustomerRM();
      this.approvalPendingCustomerSO();
    }

    if(this.user?.userTypeId == 2){
      this.getCustomerByCSA();
    }
    if (this.user?.userTypeId == 3) {
      this.getDetailIndividualCustomer();
    }
    this.filteredCustCode = this.customerCodeControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filterCustCode(value || '')),
    );

    // this.filterValidation();

  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  
  filterValidation(){
    if(this.user?.userRole[0]?.id == 6 || this.user?.userRole[0]?.id == 7 || this.user?.userRole[0]?.id == 5){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
        {id:4, label:'Last 1 year', value: 12},
      ]
    }
    if(this.user?.userRole[0]?.id == 3 || this.user?.userRole[0]?.id == 4){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
        {id:3, label:'Last 6 months', value: 6},
      ]
    }
    if(this.user?.userRole[0]?.id == 1 || this.user?.userRole[0]?.id == 2){
      this.timePeriodList = [    
        {id:1, label:'MTD', value: 0},
        {id:2, label:'Last 3 months', value: 3},
      ]
    }
  
  }

  submenuRoleBased(){
    if(this.user?.userRole[0]?.id == 2){
      this.subMenuList = ['All', 'Approval Pending - Me', 'Approval Pending - SO','Approval Pending - RM','Rejected', 'Approved', 'Activation Pending'];
    }
    else if(this.user?.userRole[0]?.id == 3){
      this.subMenuList = ['All', 'Approval Pending - Me', 'Approval Pending - SO', 'Approval Pending - PGH', 'Rejected', 'Approved', 'Activation Pending'];
    }
    else if(this.user?.userRole[0]?.id == 4){
      this.subMenuList = ['All', 'Approval Pending - Me', 'Approval Pending - RM', 'Approval Pending - PGH', 'Rejected', 'Approved', 'Activation Pending'];
    }
  }

   private _filterCustCode(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.custCodeArr.filter(option => option?.name?.toLowerCase().includes(filterValue));
  }

  getCustomerByCSA() {
    let payload = {
      objId: this.user?.id
    }

    this.loaderService.show();
    this.targetService.customerByCSA(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.custCodeArr = data;
      }
    })
  }
  
  onFileChange(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    this.fileArr3 = event?.target?.files;
    this.fileArr4 = event?.target?.files;
    this.fileArr5 = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  
  selectedCustCode(item) {
    this.customerCode = item?.code;
    this.selectedItem = item;
  }

  getDetailIndividualCustomer() {
    if (this.filterCode) {
      this.payloadDetailIndividualCustomer = {
        userId: this.filterCode.encrypt(),
        loginFromApp: false
      }
    } else {
      this.payloadDetailIndividualCustomer = {
        userId: this.user.userId,
        loginFromApp: false
      }
    }

    this.loaderService.show();
    this.customerService.customerDetailsUrl(this.payloadDetailIndividualCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

  }


  select(type?, item?, $event?) {
    this.selected[type] = (this.selected[type] === item ? null : item);
    $event ? $event.stopPropagation() : null;
    this.customerNavigationFromSubMenu(item);
    this.customerOnboardingSearch = null;
    this.selectedMenu = item;
  }

  customerNavigationFromSubMenu(data) {
    if (data == Constants.normalText.all) {
      this.allSection = true;
      this.approvedSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.activationPendingSection = false;
      this.rejectedSection = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      // if(this.allCustomerData.length == 0){
      //   this.getAllCustomer();
      // }
    }
    if (data == Constants.normalText.approved) {
      this.approvedSection = true;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.activationPendingSection = false;
      this.rejectedSection = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      if (this.allApprovedCustomerData.length == 0) {
        this.approvedCustomer();
      }
    }
    if (data == Constants.normalText.approvalPendingSO) {
      this.approvalPendingSectionSO = true;
      this.allApproveSection = false;
      this.approvedSection = false;
      this.allSection = false;
      this.activationPendingSection = false;
      this.rejectedSection = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      if (this.allApprovalPendingCustomerData.length == 0) {
        this.approvalPendingCustomer();
      }
    }
    if (data == Constants.normalText.activationPending) {
      this.activationPendingSection = true;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.rejectedSection = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      if (this.allActivationPendingCustomerData.length == 0) {
        this.activationPendingCustomer();
      }
    }
    if (data == Constants.normalText.approvalPendingRM) {
      this.activationPendingSectionRM = true;
      this.activationPendingSection = false;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.rejectedSection = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      if (this.allActivationPendingCustomerRMData.length == 0) {
        this.approvalPendingCustomerRM();
      }
    }
    if (data == Constants.normalText.approvalPendingPGH) {
      this.activationPendingSectionBH = true;
      this.activationPendingSectionRM = false;
      this.activationPendingSection = false;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.rejectedSection = false;
      this.activationPendingSectionSO = false;
      if (this.allApprovalPendingCustomerBHData.length == 0) {
        this.approvalPendingCustomerBH();
      }
    }
    if (data == Constants.normalText.approvalPendingso) {
      this.activationPendingSectionSO = true;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSection = false;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.rejectedSection = false;
      if (this.allApprovalPendingCustomerSOData.length == 0) {
        this.approvalPendingCustomerSO();
      }
    }
    if (data == Constants.normalText.rejected) {
      this.rejectedSection = true;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.allApproveSection = false;
      this.activationPendingSection = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      if (this.allRejectedCustomerData.length == 0) {
        this.rejectedCustomer();
      }
    }

    if (data == Constants.normalText.allApproved) {
      this.allApproveSection = true;
      this.rejectedSection = false;
      this.approvedSection = false;
      this.allSection = false;
      this.approvalPendingSectionSO = false;
      this.activationPendingSection = false;
      this.activationPendingSectionRM = false;
      this.activationPendingSectionBH = false;
      this.activationPendingSectionSO = false;
      if (this.allApprovedCustData.length == 0) {
        this.allApprovedCustomer();
      }
    }
  }

  isActive(type, item) {
    return this.selected[type] === item;
  }

  selectAmendMenu(type?, item?, $event?) {
    this.selected[type] = (this.selected[type] === item ? null : item);
    $event ? $event.stopPropagation() : null;
    this.customerNavigationFromSubMenuAmendment(item);
  }

  isActiveAmend(type, item) {
    return this.selected[type] === item;
  }

  customerNavigationFromSubMenuAmendment(data) {
    if (data == Constants.normalText.basicDetails) {
      this.basicDetailsSection = true;
      this.otherDetailsSection = false;
      this.fileSection = false;
    }
    if (data == Constants.normalText.otherDetails) {
      this.otherDetailsSection = true;
      this.basicDetailsSection = false;
      this.fileSection = false;
    }
    if (data == Constants.normalText.files) {
      this.otherDetailsSection = true;
      this.basicDetailsSection = false;
      this.fileSection = false;
    }

  }

  getAllCustomer() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode?.encrypt(),
        roleId: null,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user?.userId,
        roleId: null,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allCustomerData = data?.custMaster;
      }
    })
  }

  approvedCustomer() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'Y',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        monthInterval: this.timePeriod
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        apprStatus: 'Y',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        monthInterval: this.timePeriod
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovedCustomerData = data?.custMaster;
      }
    })
  }

  approvalPendingCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'N',
        activStatus: 'N',
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        text: this.customerOnboardingSearch,
      }
    } else {
      if(this.user?.userRole[0]?.id == 2){
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'Y',
          activStatus: 'N',
          roleId: this.user?.userRole[0]?.id,
          loginFromApp: false,
          monthInterval: this.timePeriod,
          text: this.customerOnboardingSearch,
        }
      }else{
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'N',
          activStatus: 'N',
          roleId: this.user?.userRole[0]?.id,
          loginFromApp: false,
          monthInterval: this.timePeriod,
          text: this.customerOnboardingSearch,
        }
      }
      
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovalPendingCustomerData = data?.custMaster;
      }
    })
  }

  approvalPendingCustomerRM() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'N',
        activStatus: 'N',
        roleId: 3,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'N',
          activStatus: 'N',
          roleId: 3,
          loginFromApp: false,
          monthInterval: this.timePeriod,
          text: this.customerOnboardingSearch,
        }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allActivationPendingCustomerRMData = data?.custMaster;
      }
    })
  }

  approvalPendingCustomerBH() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'Y',
        activStatus: 'N',
        roleId: 2,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'Y',
          activStatus: 'N',
          roleId: 2,
          loginFromApp: false,
          monthInterval: this.timePeriod,
          text: this.customerOnboardingSearch,
        }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovalPendingCustomerBHData = data?.custMaster;
      }
    })
  }

  approvalPendingCustomerSO() {
    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'N',
        activStatus: 'N',
        roleId: 4,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
        this.payloadAllCustomer = {
          userId: this.user.userId,
          apprStatus: 'N',
          activStatus: 'N',
          roleId: 4,
          loginFromApp: false,
          monthInterval: this.timePeriod,
          text: this.customerOnboardingSearch,
        }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovalPendingCustomerSOData = data?.custMaster;
      }
    })
  }

  activationPendingCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        apprStatus: 'Y',
        activStatus: 'N',
        roleId: 4,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        apprStatus: 'Y',
        activStatus: 'N',
        roleId: 4,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allActivationPendingCustomerData = data?.custMaster;
      }
    })
  }

  rejectedCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        activStatus: 'N',
        apprStatus: 'R',
        roleId: null,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        activStatus: 'N',
        apprStatus: 'R',
        roleId: null,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allRejectedCustomerData = data?.custMaster;
      }
    })
  }

  allApprovedCustomer() {

    if (this.filterCode) {
      this.payloadAllCustomer = {
        userId: this.filterCode.encrypt(),
        finalApprvStatus: 'Y',
        roleId: null,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    } else {
      this.payloadAllCustomer = {
        userId: this.user.userId,
        finalApprvStatus: 'Y',
        roleId: null,
        loginFromApp: false,
        monthInterval: this.timePeriod,
        text: this.customerOnboardingSearch,
      }
    }

    this.loaderService.show();
    this.customerService.allCustomer(this.payloadAllCustomer).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.allApprovedCustData = data?.custMaster;
      }
    })
  }

  raiseAmendmentInitiation() {
    // this.custDetails = false;
    // this.amendmentDetails = true;
    // this.companyNameCustomerAmendment = this.individualCustomerData?.organizationName;
    // this.phoneCustomerAmendment = this.individualCustomerData?.contact;
    // this.emailCustomerAmendment = this.individualCustomerData?.emailId;
    // this.addressCustomerAmendment = this.individualCustomerData?.address, this.individualCustomerData?.city, this.individualCustomerData?.pincode;
    // this.countryCustomerAmendment = this.individualCustomerData?.country;
    // this.faxCustomerAmendment = this.individualCustomerData?.fax;

    if(this.user?.userTypeId == 3){
      let validContact = this.commonservice.regexForNumericandDecimalNumber(this.phoneNoCustAmendment);
      let validEmail = this.commonservice.regexForEmail(this.emailIdCustAmendment);
      
      if(!this.phoneNoCustAmendment){
        Swal.fire(alertPopup.contactNoEmpty);
      }
      else if(validContact){
        Swal.fire(alertPopup.validContact);
      }
      else if(!this.emailIdCustAmendment){
        Swal.fire(alertPopup.mailEmpty);
      }
      else if(!validEmail){
        Swal.fire(alertPopup.validmail);
      }
      else if(!this.descriptionCustAmendment){
        Swal.fire(alertPopup.emptyDescription);
      }
      else{
        let payload = {
          customerName: null,
          regionId: this.user?.regionId[0],
          soEmail: this.emailIdCustAmendment,
          soPhoneNo: this.phoneNoCustAmendment,
          subject: null,
          description: this.descriptionCustAmendment,
          customerCode: this.customerCode?.encrypt() ? this.customerCode.encrypt(): this.user?.userId,
          salesOfficerCode: this.user?.userId,
          loggedInUserId: this.user?.id,
          uploadFileIds: [this.uploadDataRes?.id]
        }
    
        this.loaderService.show();
        this.customerService.raiseAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
    }
   
    if(this.user?.userTypeId == 2){
      let validContact = this.commonservice.regexForNumericandDecimalNumber(this.phoneNoCustAmendment);
      let validEmail = this.commonservice.regexForEmail(this.emailIdCustAmendment);
      
      if(!this.phoneNoCustAmendment){
        Swal.fire(alertPopup.contactNoEmpty);
      }
      else if(validContact){
        Swal.fire(alertPopup.validContact);
      }
      else if(!this.emailIdCustAmendment){
        Swal.fire(alertPopup.mailEmpty);
      }
      else if(!validEmail){
        Swal.fire(alertPopup.validmail);
      }
      else if(!this.descriptionCustAmendment){
        Swal.fire(alertPopup.emptyDescription);
      }
      else{
        let payload = {
          customerName: null,
          regionId: this.selectedItem?.regionId,
          soEmail: this.emailIdCustAmendment,
          soPhoneNo: this.phoneNoCustAmendment,
          subject: null,
          description: this.descriptionCustAmendment,
          customerCode: this.customerCode?.encrypt() ? this.customerCode.encrypt(): this.user?.userId,
          salesOfficerCode: this.user?.userId,
          loggedInUserId: this.user?.id,
          uploadFileIds: [this.uploadDataRes?.id]
        }
    
        this.loaderService.show();
        this.customerService.raiseAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
          this.loaderService.hide();
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data?.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            })
          }
        })
      }
    }

  }

  fileUploadAmendment() {
    if (!this.file) {
      Swal.fire(alertPopup.uploadFile);
    } else {
      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('file', this.file, this.file.name);
      }

      let fileUploadReq = {
        loggedInUserId: this.user?.userId
      }

      Object.entries(fileUploadReq).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.uploadFileAmendment(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data?.status == 1) {
          this.uploadDataRes = data;
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data?.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  discard() {
    this.custDetails = true;
    this.amendmentDetails = false;
  }

  raiseNowAmendmentForCustomer() {

    let validEmail = this.commonService.regexForEmail(this.emailCustomerAmendment);

    if (!validEmail) {
      Swal.fire(alertPopup.validmail);
    } else {
      let payload = {
        oldCompanyName: this.individualCustomerData?.organizationName,
        newCompanyName: this.companyNameCustomerAmendment,
        oldPhoneNo: this.individualCustomerData?.contact,
        newPhoneNo: this.phoneCustomerAmendment,
        oldEmail: this.individualCustomerData?.emailId,
        newEmail: this.emailCustomerAmendment,
        oldContactAddress: this.individualCustomerData?.address,
        newContactAddress: this.addressCustomerAmendment,
        oldCountry: this.individualCustomerData?.country,
        newCountry: this.countryCustomerAmendment,
        oldFaxNo: this.individualCustomerData?.fax,
        newFaxNo: this.faxCustomerAmendment,
        loggedinUserId: this.user.userId,
        loginFromApp: false
      }

      this.loaderService.show();
      this.customerService.raiseCustomerAmendment(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data) {
          if (data?.status == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            })
            this.custDetails = true;
            this.amendmentDetails = false;
            this.getDetailIndividualCustomer();
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: data.message,
              showCancelButton: false,
              allowEnterKey: false,
              allowOutsideClick: false,
            })
          }
        }
      })

    }

  }

  viewDetails(item) {
    this.allViewForOfficer = false;
    this.isEnabledFilterSearch = false;
    this.officersView = true;
    this.individualCustomer = item;
    this.rejectedPanelSO = false;
    this.rejectedPanelRM = false;
    this.rejectedPanelPH = false;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());

    if (this.regionArr.length == 0) {
      this.getRegion();
    }

    if (this.custType.length == 0) {
      this.getCustomerType()
    }

    if((item?.isApprove == 'Y' && item?.isActive == 'Y') || item?.isApprove == 'R'){
      this.isAllapprved = true;
    }

    if(item?.isApprove == 'Y' && item?.isActive == 'N' && item?.isBHenable == 'N'){
      this.isInactive = true;
    }
    if(item?.isApprove == 'Y' && item?.isActive == 'N' && item?.isBHenable == 'Y'){
      this.isInactive = false;
      this.isAllapprved = false;
      this.isActiveViewDetailsRM = false;
    }

    if(item?.isApprove == 'N' && item?.isActive == 'N' && item?.pendingWithRoleId == 3){
      if(this.user.userRole[0]?.id != 3){
        this.isActiveViewDetailsRM = true;
      }else{
        this.isActiveViewDetailsRM = false;
      }
    }

    if(item?.isApprove == 'Y' && item?.isActive == 'N' && item?.pendingWithRoleId == 2){
      if(this.user.userRole[0]?.id != 2){
        this.isActiveViewDetailsRM = true;
      }else{
        this.isActiveViewDetailsRM = false;
      }
    }

    if(item?.isApprove == 'N' && item?.isActive == 'N' && item?.pendingWithRoleId == 4){
      if(this.user.userRole[0]?.id != 4){
        this.isActiveViewDetailsRM = true;
      }else{
        this.isActiveViewDetailsRM = false;
      }
    }

  }

  viewDetailsRejected(item){
    this.isAllapprved = true;
    this.isEnabledFilterSearch = false;
    this.isEnabledFilterSearch = false;
    this.isActiveViewDetailsRM = false;
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    // this.rejectedPanelSO = true;
    // this.rejectedPanelRM = true;
    // this.rejectedPanelPH = true;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());
  }

  viewDetailsAllApproved(item){
    this.isAllapprved = true;
    this.isEnabledFilterSearch = false;
    this.isActiveViewDetailsRM = false;
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());

  }

  viewDetailsActivationPending(item){
    this.isInactive = true;
    this.isEnabledFilterSearch = false;
    this.isActiveViewDetailsRM = false;
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());

  }

  viewDetailsRM(item){
    this.isActiveViewDetailsRM = true;
    this.isEnabledFilterSearch = false;
    this.isInactive = false;
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());
  }

  viewDetailsSO(item){
    this.isActiveViewDetailsRM = true;
    this.isEnabledFilterSearch = false;
    this.isInactive = false;
    this.allViewForOfficer = false;
    this.officersView = true;
    this.individualCustomer = item;
    let url = this.commonService.appendUrl(ApiEndPoints.urls.customerDetailsByIdUrl, item.id);
    this.loaderService.show();
    this.customerService.customerDetailsByIdUrl(url).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.custDetails[0]) {
        this.individualCustomerData = data?.custDetails[0];
      }
    })

    this.getBusinessOfficerData(item?.id.toString().encrypt());
  }


  getBusinessOfficerData(custId) {
    let payload = {
      id: custId,
      userId: this.user.userId,
      loginFromApp: false
    }

    this.loaderService.show();
    this.customerService.businessOfficerData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.onboardingData[0] != null) {
        this.individualBusinessOfiicerData = data?.onboardingData[0];
      }
    })

  }

  getRegion() {
    this.loaderService.show();
    this.common.regionMaster().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data) {
        this.regionArr = data;
      }
    })
  }

  getCustomerType() {
    this.loaderService.show();
    this.common.customerType().pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      if (data && data?.userType != null) {
        this.custType = data?.userType;
      //   data?.userType.forEach(eleCustType => {
      //     if (eleCustType?.id == 2 || eleCustType?.id == 3) {
      //       this.custType.push(eleCustType);
      //     }
      //   })
      }
    })
  }

  goBackOfficersData() {
    this.allViewForOfficer = true;
    this.isEnabledFilterSearch = true;
    this.officersView = false;
    this.isAllapprved = false;
    this.isInactive = false;
    this.isActiveViewDetailsRM = false;
  }
  
  amendForOfficers() {
    this.mainOfficersData = true;
  }

  goBackPrevious() {
    this.mainOfficersData = false;
  }

  activateCustomer() {
    // this.dialog.open(CustomerActivationPopupComponent, { disableClose: true, width: '30%', height: '33%' });
  }

  sendForApproval() {
    if (!this.onboardingCustType) {
      Swal.fire(alertPopup.custType);
    }
    else if (!this.salesOfficerRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('file', this.file, this.file.name);
      }

      let sendForApprovalSO = {
        id: this.individualCustomer?.id,
        soRemarks: this.salesOfficerRemarks,
        customerTypeId: this.onboardingCustType,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      Object.entries(sendForApprovalSO).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.saveSOData(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }

  }

  submitMainApproval() {
   if (!this.salesOfficerRemarksSecondLevel) {
      Swal.fire(alertPopup.remarks);
    } else {
      let formData = new FormData();

      if (this.fileAdded || this.isFileUploaded) {
        formData = new FormData();
        formData.append('file', this.file, this.file.name);
      }

      let finalApprovalSO = {
        id: this.individualCustomer?.id,
        soRemarksLevel2: this.salesOfficerRemarksSecondLevel,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      Object.entries(finalApprovalSO).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.saveSOData(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data?.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }

  }

  rejectRegionalSo(){
    if (!this.salesOfficerRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {

      let formData = new FormData();

      let sendForApprovalSO = {
        id: this.individualCustomer?.id,
        soRemarks: this.salesOfficerRemarks,
        userId: this.user?.userId,
        // customerTypeId: this.onboardingCustType,
        // customerCode: this.onboardingCustCode,
        // regionId: this.onboardingRegion,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: false
      }

      Object.entries(sendForApprovalSO).forEach(([key, value]) => {
        formData.append(key, value);
      });

      this.loaderService.show();
      this.customerService.saveSOData(formData).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data?.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }


  approvalRM() {
  if (!this.regionalMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        customerTypeId: this.onboardingCustTypeRM,
        rmRemarks: this.regionalMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  rejectRM() {
    if (!this.regionalMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        rmRemarks: this.regionalMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: false,
        customerTypeId: this.onboardingCustTypeRM
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  approvalHM() {
    if (!this.headMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        customerCode: this.individualCustomer?.customerCode?.encrypt(),
        regionId: this.individualBusinessOfiicerData?.regionId,
        faRemarks: this.headMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: true
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  rejectHM() {
    if (!this.headMarketingRemarks) {
      Swal.fire(alertPopup.remarks);
    } else {
      let payload = {
        id: this.individualCustomer?.id,
        customerCode: this.individualCustomer?.customerCode?.encrypt(),
        regionId: this.individualBusinessOfiicerData?.regionId,
        faRemarks: this.headMarketingRemarks,
        userId: this.user?.userId,
        roleId: this.user?.userRole[0]?.id,
        loginFromApp: false,
        approved: false
      }

      this.loaderService.show();
      this.customerService.saveOnboardingData(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
        this.loaderService.hide();
        if (data.status == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: data.message,
            showCancelButton: false,
            allowEnterKey: false,
            allowOutsideClick: false,
          })
        }
      })
    }
  }

  onFileChangeTarget(event: any, isFileUploaded?) {
    this.isFileUploaded = isFileUploaded;
    this.fileArr1 = event?.target?.files;
    this.fileArr2 = event?.target?.files;
    if (event?.target?.files?.length) {
      this.fileAdded = true;
      this.file = event.target.files[0];
    }
  }

  downloadCustomerOnboardingReport(){
    let payload = {
      userId: this.user?.userId,
      userType: "BU",
      loginFromApp: false,
    }

    this.loaderService.show();
    this.customerService.downloadCustomerOnboarding(payload).pipe(takeUntil(this.destroyed$)).subscribe(data => {
      this.loaderService.hide();
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(data);
      link.download = "Customer_Onboarding_Report_" + moment(new Date()).format('DD-MM-YYYY_HH-mm') + ".xlsx";
      link.click();
    })

  }

  searchCustomerOnboarding(){

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 4){
      if(this.selectedMenu == undefined || this.selectedMenu == 'All'){
        this.getAllCustomer();
      }
      if(this.selectedMenu == 'Approval Pending - Me'){
        this.approvalPendingCustomer();
      }
      if(this.selectedMenu == 'Rejected'){
        this.rejectedCustomer();
      }
      if(this.selectedMenu == 'Approved'){
        this.allApprovedCustomer();
      }
      if(this.selectedMenu == 'Activation Pending'){
        this.activationPendingCustomer();
      }
      if(this.selectedMenu == 'Approval Pending - RM'){
        this.approvalPendingCustomerRM();
      }
      if(this.selectedMenu == 'Approval Pending - PGH'){
        this.approvalPendingCustomerBH();
      }
      
    }

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 3){

      if(this.selectedMenu == undefined || this.selectedMenu == 'All'){
        this.getAllCustomer();
      }
      if(this.selectedMenu == 'Approval Pending - Me'){
        this.approvalPendingCustomer();
      }
      if(this.selectedMenu == 'Rejected'){
        this.rejectedCustomer();
      }
      if(this.selectedMenu == 'Approved'){
        this.allApprovedCustomer();
      }
      if(this.selectedMenu == 'Activation Pending'){
        this.activationPendingCustomer();
      }
      if(this.selectedMenu == 'Approval Pending - SO'){
        this.approvalPendingCustomerSO();
      }
      if(this.selectedMenu == 'Approval Pending - PGH'){
        this.approvalPendingCustomerBH();
      }

    }

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 2){

      if(this.selectedMenu == undefined || this.selectedMenu == 'All'){
        this.getAllCustomer();
      }
      if(this.selectedMenu == 'Approval Pending - Me'){
        this.approvalPendingCustomer();
      }
      if(this.selectedMenu == 'Rejected'){
        this.rejectedCustomer();
      }
      if(this.selectedMenu == 'Approved'){
        this.allApprovedCustomer();
      }
      if(this.selectedMenu == 'Activation Pending'){
        this.activationPendingCustomer();
      }
      if(this.selectedMenu == 'Approval Pending - SO'){
        this.approvalPendingCustomerSO();
      }
      if(this.selectedMenu == 'Approval Pending - RM'){
        this.approvalPendingCustomerRM();
      }
    }

  }

  monthIntervalData(evt){
    this.timePeriod = evt;
    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 4){
      this.getAllCustomer();
      this.approvalPendingCustomer();
      this.rejectedCustomer();
      this.allApprovedCustomer();
      this.activationPendingCustomer();
      this.approvalPendingCustomerRM();
      this.approvalPendingCustomerBH();
    }

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 3){
      this.getAllCustomer();
      this.approvalPendingCustomer();
      this.rejectedCustomer();
      this.allApprovedCustomer();
      this.activationPendingCustomer();
      this.approvalPendingCustomerSO();
      this.approvalPendingCustomerBH();
    }

    if(this.user?.userTypeId == 1 && this.user.userRole[0]?.id == 2){
      this.getAllCustomer();
      this.approvalPendingCustomer();
      this.rejectedCustomer();
      this.allApprovedCustomer();
      this.activationPendingCustomer();
      this.approvalPendingCustomerRM();
      this.approvalPendingCustomerSO();
    }
  }

  removeFile1(){
    this.fileArr1 = [];
    this.myInputVariable1.nativeElement.value = "";
  }

  removeFile2(){
    this.fileArr2 = [];
    this.myInputVariable2.nativeElement.value = "";
  }

  removeFile3(){
    this.fileArr3 = [];
    this.myInputVariable3.nativeElement.value = "";
  }

  removeFile4(){
    this.fileArr4 = [];
    this.myInputVariable4.nativeElement.value = "";
  }

  removeFile5(){
    this.fileArr5 = [];
    this.myInputVariable5.nativeElement.value = "";
  }

  downloadFile1(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile2(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile3(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile4(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile5(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile6(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile7(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  downloadFile8(url, name) {
    this.downloadService.download(url)
      .pipe(takeUntil(this.destroyed$)).subscribe(blob => saveAs(blob, name))
  }

  sendMailFromSo(){
    this.dialog.open(SendEmailSoCustomerPopupComponent, { disableClose: true, width: '50%', height: '46%', data: this.individualCustomerData });
  }

}
