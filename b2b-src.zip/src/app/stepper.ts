import Stepper from 'bs-stepper';

export default Stepper;