
import { environment } from 'src/environments/environment.prod';
import * as CryptoJS from 'crypto-js';


declare global {
    interface String {
      encrypt(): String;
      decrypt(): String;
    }
  }
  
  String.prototype.encrypt = function(): String {
    // return isNaN(this);
    var text = this;
    var key  = CryptoJS.enc.Hex.parse(environment.key);
    var iv   = CryptoJS.enc.Hex.parse("00000000000000000000000000000000");

    var encrypted = CryptoJS.AES.encrypt(text, key, {iv: iv, padding: CryptoJS.pad.ZeroPadding});
    return encrypted.toString();
  };

  String.prototype.decrypt = function(): String {
    var key  = CryptoJS.enc.Hex.parse(environment.key);
    var iv   = CryptoJS.enc.Hex.parse("00000000000000000000000000000000");

    return CryptoJS.AES.decrypt(
      this, key, {
        keySize: 16,
        iv: iv,
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.ZeroPadding
      }).toString(CryptoJS.enc.Utf8);
  };
  
  export {};