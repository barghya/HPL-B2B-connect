import { Injectable } from "@angular/core";
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from "@angular/material/snack-bar";
import * as moment from "moment";


@Injectable({
    providedIn: 'root'
})
export class CommonService {

    horizontalPosition: MatSnackBarHorizontalPosition = "center";
    verticalPosition: MatSnackBarVerticalPosition = "top";

    constructor(private _snackBar: MatSnackBar) { }

    openSnackBar(msg: any) {
        this._snackBar.open(msg, "CLOSE", {
            duration: 5000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            panelClass: ['pink-snackbar']
        });
    }

    openGreenSnackBar(msg: any) {
        this._snackBar.open(msg, "CLOSE", {
            duration: 2000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            panelClass: ['green-snackbar'],
        });
    }

    appendUrl(url, data) {
        var appendUrl = url + '/' + data;
        return appendUrl;
    }

    regexForEmail(value) {
        var regx = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (regx.test(value)) {
            return true;
        }
        return false;
    }

    regexForNumericandDecimalNumber(value) {
        var regx = /[^\d*\.?\d*$]/;
        if (regx.test(value)) {
            return true;
        }
        return false;
    }

    convertDateTimeISO(inputDate, sendSystemTime?) {
        // This function returns  formatted date time ISO string , where time is in 24 hours format.
        if (inputDate) {
            const startDate = moment(inputDate).format('DD/MM/YYYY');
            const timeSelected = sendSystemTime ? new Date() : inputDate;
            const startTime = moment(timeSelected, 'HH:mm:ss').format('HH:mm:ss');
            const dateTimeStringFirst = String(startDate + ' ' + startTime);
            const [dateStringFirst, timeStringFirst] = dateTimeStringFirst.split(' ');
            const [dayFirst, monthFirst, yearFirst] = dateStringFirst.split('/');
            const [hourFirst, minuteFirst, secondFirst] = timeStringFirst.split(':');
            const dateObjFirst = new Date(
                +yearFirst,
                +monthFirst - 1,
                +dayFirst,
                +hourFirst,
                +minuteFirst,
                +secondFirst
            );
            return dateObjFirst.toISOString();
        }
        return null;
    }

    regexForWhiteSpace(value) {
        var regx = /\s/g;
        if (regx.test(value)) {
          return true;
        }
        return false;
    }

    getTimeDiff(startDate, endDate) {
        var diff = endDate.getTime() - startDate.getTime();
        var days = Math.floor(diff / (60 * 60 * 24 * 1000));
        var hours = Math.floor(diff / (60 * 60 * 1000)) - (days * 24);
        var minutes = Math.floor(diff / (60 * 1000)) - ((days * 24 * 60) + (hours * 60));
        var seconds = Math.floor(diff / 1000) - ((days * 24 * 60 * 60) + (hours * 60 * 60) + (minutes * 60));
        return { day: days, hour: hours, minute: minutes, second: seconds };
      }
 
    

}