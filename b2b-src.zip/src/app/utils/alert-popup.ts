export class alertPopup {

    public static captchaVerified: any = {
        position: 'center',
        icon: 'success',
        title: '<div class="swltitle">Captcha verified!</div>',
        showCancelButton: false,
        allowEnterKey: false,
        allowOutsideClick: false,
    }

    public static captchaNotVerified: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Captcha not verified. Please try again!</div>',
        showConfirmButton: true
    }

    public static nullUser: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please Enter your User ID.</div>',
        showConfirmButton: true
    }

    public static nullPassword: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please enter your Password.</div>',
        showConfirmButton: true
    }

    public static passwordVerified: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please match the requested password policy</div>',
        showConfirmButton: true
    }

    public static interceptorError: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">System error occured. Please contact your system Admin.</div>',
        showConfirmButton: true
    }
    

    public static verifySecurityCodeError: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Link Expired. Please try resetting again or contact support.</div>',
        showConfirmButton: true
    }

     public static password: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please provide Password.</div>',
        showConfirmButton: true
    }

    public static confirmPassword: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please provide confirm Password.</div>',
        showConfirmButton: true
    }

    public static whiteSpacePassword: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">No space is allowed between Password characters.</div>',
        showConfirmButton: true
    }

    public static unauthorized: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Unauthorized.</div>',
        showConfirmButton: true
    }

    public static passwordMatch: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Password did not match. Please try again.</div>',
        showConfirmButton: true
    }

    
    public static userId: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please provide your user ID.</div>',
        showConfirmButton: true
    }

    public static passwordResetSuccessfully: any = {
        position: 'center',
        icon: 'success',
        title: '<div class="swltitle">Password Reset Successfully. Please try to logging in.</div>',
        showCancelButton: false,
        allowEnterKey: false,
        allowOutsideClick: false,
    }

    public static releaseOrderChecked: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please checked/select order to Proceed.</div>',
        showConfirmButton: true
    }

    public static mailEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Mail ID.</div>',
        showConfirmButton: true
    }

    public static validmail: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add correct Mail ID.</div>',
        showConfirmButton: true
    }

    public static productEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add product.</div>',
        showConfirmButton: true
    }

    public static quantityEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add quantity.</div>',
        showConfirmButton: true
    }

    public static materialNameEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Material Name.</div>',
        showConfirmButton: true
    }

    public static materialDescriptionEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Material Description.</div>',
        showConfirmButton: true
    }

    public static billingAddressEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Bill to Party Address.</div>',
        showConfirmButton: true
    }

    public static deliveryAddressEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Ship to Party Address.</div>',
        showConfirmButton: true
    }

    public static ackDeliveryDate: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Delivery date.</div>',
        showConfirmButton: true
    }

    public static ackReportingDate: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Reporting date.</div>',
        showConfirmButton: true
    }

    public static uploadFile: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please upload file.</div>',
        showConfirmButton: true
    }

    public static acknowledgementType: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Acknowledgement type.</div>',
        showConfirmButton: true
    }

    public static viewAs: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select view as.</div>',
        showConfirmButton: true
    }

    public static filterDataCode: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please type your code to proceed.</div>',
        showConfirmButton: true
    }

    public static confirmProcess: any = {
        icon: 'warning',
        title: '<div class="swltitle">Do you want to continue?</div>',
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonText: 'Yes',
        reverseButtons: true,
        allowEnterKey: false,
        allowOutsideClick: false,
    }

    public static firstNameEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add First Name.</div>',
        showConfirmButton: true
    }

    public static lastNameEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Last Name.</div>',
        showConfirmButton: true
    }

    public static empCodeEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Employee Code.</div>',
        showConfirmButton: true
    }
    
    public static contactNoEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Contact No.</div>',
        showConfirmButton: true
    }

    public static subjectEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Subject.</div>',
        showConfirmButton: true
    }

    public static custCodeEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Customer Code.</div>',
        showConfirmButton: true
    }

    public static salesOfficerEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Sales Officer.</div>',
        showConfirmButton: true
    }

    public static addressEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Address.</div>',
        showConfirmButton: true
    }

    public static regionEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please Select Region.</div>',
        showConfirmButton: true
    }

    public static roleEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please Select Role.</div>',
        showConfirmButton: true
    }


    public static validContact: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add correct Contact No.</div>',
        showConfirmButton: true
    }

    public static validQty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add correct Quantity.</div>',
        showConfirmButton: true
    }

    public static startDate: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select start date.</div>',
        showConfirmButton: true
    }

    public static toggleCodeTypeSelect: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Type.</div>',
        showConfirmButton: true
    }

    public static endDate: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select end date.</div>',
        showConfirmButton: true
    }

    public static dateValidation: any = {
        position: 'center',
        icon: 'error',
        title: "<div class='swltitle'>Start date can't be greater than end date</div>",
        showConfirmButton: true
    }

    public static todayStartDateValidation: any = {
        position: 'center',
        icon: 'error',
        title: "<div class='swltitle'>Start date can not be greater than today's date</div>",
        showConfirmButton: true
    }

    public static todayendateValidation: any = {
        position: 'center',
        icon: 'error',
        title: "<div class='swltitle'>End date can not be greater than today's date</div>",
        showConfirmButton: true
    }

    public static remarks: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add remarks.</div>',
        showConfirmButton: true
    }

    public static custType: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Customer Type.</div>',
        showConfirmButton: true
    }

    public static region: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Region.</div>',
        showConfirmButton: true
    }

    public static customerCode: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Customer code.</div>',
        showConfirmButton: true
    }

    public static emptyDescription: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add your Description.</div>',
        showConfirmButton: true
    }

    public static emptyAmendmentAction: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Action for Process.</div>',
        showConfirmButton: true
    }

    public static nonCCSValueEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Value.</div>',
        showConfirmButton: true
    }

    public static validCCSValueEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Valid Value.</div>',
        showConfirmButton: true
    }

    public static billToPartyIdEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Bill to Party.</div>',
        showConfirmButton: true
    }

    public static shipToPartyIdEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Ship to Party.</div>',
        showConfirmButton: true
    }

    public static gradeEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Grade.</div>',
        showConfirmButton: true
    }

    public static locationEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Location.</div>',
        showConfirmButton: true
    }

    public static addlDiscountEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Additional Discount.</div>',
        showConfirmButton: true
    }

    public static monthEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Month.</div>',
        showConfirmButton: true
    }

    public static productTypeEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please select Product Type.</div>',
        showConfirmButton: true
    }

    public static ccsQtyEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add CCS Qty.</div>',
        showConfirmButton: true
    }

    public static addlQtyEmpty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add Additional Qty.</div>',
        showConfirmButton: true
    }

    public static duplicateShipToParty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Ship To Party alredy Exist in table. Please Change the ID.</div>',
        showConfirmButton: true
    }

    public static validAddDis: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add valid value for Additional Discount.</div>',
        showConfirmButton: true
    }

    public static validCCSQty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add valid value for CCS Qty.</div>',
        showConfirmButton: true
    }

    public static validAddQty: any = {
        position: 'center',
        icon: 'error',
        title: '<div class="swltitle">Please add valid value for Additional Qty.</div>',
        showConfirmButton: true
    }

}