import { environment } from "src/environments/environment.prod";

export class ApiEndPoints {

    public static urls = {

        // For Global
        materialNameUrl: environment.baseServiceUrl + "b2bapi/user/lookup/list-masterial-master",
        roleMasterUrl: environment.baseServiceUrl + "b2bapi/user/lookup/list-role-master",
        regionMasterUrl: environment.baseServiceUrl + "b2bapi/user/lookup/list-region-master",
        customerTypeUrl: environment.baseServiceUrl + "b2bapi/user/get-customer-type",

        // For Login 
        loginUrl: environment.baseServiceUrl + "b2bapi/user/authenticate",

        // For Reset-Password 
        sendResetUrl: environment.baseServiceUrl + "b2bapi/user/send-reset-password-mail",
        resendResetUrl: environment.baseServiceUrl + "b2bapi/user/resend-reset-password-mail",
        validateResetUrl: environment.baseServiceUrl + "b2bapi/user/validate-reset-link",
        resetPasswordUrl: environment.baseServiceUrl + "b2bapi/user/reset-password",

        // For Menu
        menuUrl: environment.baseServiceUrl + "b2bapi/user/get-menu",

        // For Cust Name
        custNameUrl: environment.baseServiceUrl + "b2bapi/user/get-customer-name",

        // For Customer Onboarding
        allCustomerUrl: environment.baseServiceUrl + "b2bapi/user/get-customer-master",
        customerDetailsUrl: environment.baseServiceUrl + "b2bapi/user/get-customer-details",
        customerDetailsByIdUrl: environment.baseServiceUrl + "b2bapi/user/view-customer-details",
        raiseCustomerAmendmentUrl: environment.baseServiceUrl + "b2bapi/user/customer/raise-customer-amendment",
        businessOfficerDataUrl: environment.baseServiceUrl + "b2bapi/user/get-customer-onboarding-data",
        saveSODataUrl: environment.baseServiceUrl + "b2bapi/user/save-onboarding-so-data",
        saveOnboardingDataUrl: environment.baseServiceUrl + "b2bapi/user/save-customer-onboarding",
        sentMailToCustomerUrl: environment.baseServiceUrl + "b2bapi/user/send-customer-onboarding-mail",

        // For Amendment
        uploadFileAmendmentUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/upload-customer-amendment-file",
        raiseAmendmentUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/submit-customer-amendment-request",
        searchAmendmentUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/search-customer-amendment",
        processAmendmentUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/process-customer-amendment",
        custProfileDataUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/list-cust-so-pare",
        previousAmendmentDataUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/amendment-by-user",
        customerAmendmentDataUrl: environment.baseServiceUrl + "b2bapi/user/customer/amendment/view-customer-amendment",
        downloadCustomerOnboardingUrl: environment.baseServiceUrl + "b2bapi/user/download-customer-onboarding-excel-data",
        billToPartyUrl: environment.baseServiceUrl + "b2bapi/user/contribution/list-cust-code-or-name",

        // For Place Order
        // fetchPlaceOrderDetailsUrl: environment.baseServiceUrl + "b2bapi/user/view-place-order-details",
        savePlaceOrderDetailsUrl: environment.baseServiceUrl + "b2bapi/user/save-place-order-details",
        productItemsUrl: environment.baseServiceUrl + "b2bapi/user/view-product-items",
        customerAddressUrl: environment.baseServiceUrl + "b2bapi/user/view-address-details",
        placeOrderUrl: environment.baseServiceUrl + "b2bapi/user/save-place-order-details",
        getEmailCSAUrl: environment.baseServiceUrl + "b2bapi/user/view-payer-email",

        // For Release Order
        fetchReleaseOrderDetailsUrl: environment.baseServiceUrl + "b2bapi/user/view-release-order-details",
        saveReleaseOrderDetailsUrl: environment.baseServiceUrl + "b2bapi/user/save-release-order-details",

        // For Dispatch Management
        dispatchCountDetailsUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/get-dispatch-master",
        recentDeliveryDispatchDetailsUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/get-recent-deliveries",
        dispatchDetailsUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/get-dispatch-details",
        individualTripDetailsUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/get-location-details",
        downloadDispatchGraphReportUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/download-dispatch-excel-data",
        vehicleViewInMapUrl: environment.baseServiceEPODProdUrl + "vehicleTrackingService/vehicleTracking/shareTrip",
        fetchAckUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/get-pod-ack-master",
        ackSaveUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/save-pod-ack-data",
        downloadTableDataDispatchUrl: environment.baseServiceDispatchUrl + "b2bapi/integration/download-dispatch-details-excel",

        // For Logistical Complaints Management
        recentLogisticsComplaintsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-recent-logistic-complaint-details",
        saveTechnicalComplaintUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/save-customer-complaints",
        complaintsCountDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-logistic-complaint-info",
        avgResolvedTimeLogisticsComLineChartDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-logistic-complaint-line-chart-data",
        complaintsDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-logistic-complaint-details",
        logisticComplaintAuditTrailDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-logistic-complaint-audit-details",
        downloadComplaintUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-logistic-complaint-download-items",
        downloadExcelForLogisticComplaintsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/download-complaint-excel-data",
        downloadTableDataLogisticComplaintsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/download-complaint-details-excel",

        // For Technical Complaints Management
        technicalComplaintsCountDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/get-technical-complaint-info",
        avgResolvedTimeTechnicalComLineChartDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/fetch-technical-complaint-line-chart-data",
        recentTechnicalComplaintsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/fetch-recent-technical-complaint-details",
        technicalComplaintsDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/fetch-technical-complaint-details",
        downloadExcelTechnicalComplaintsUrl: environment.baseServiceComplaintUrl + "b2bapi/complaint/download-technical-complaint-details-excel",

        // For Purchase & Sales Management
        purchaseManagementCountDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-purchase-info",
        purchaseManagementDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-purchase-details",
        purchaseManagementLineBarChartUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-purchase-order-chart-data",
        topCustomersSalesUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-top-customer-details",
        downloadTableDataPurchaseManagementUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/download-purchase-details-excel-data",
        downloadPurchaseTrendValueQtyReportUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/download-chart-details-excel-data",
        targetRemainingUrl: environment.baseServiceUrl + "b2bapi/user/target/get-sales-target-data",
        gccGraphUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-purchase-order-gcc-chart-data",
        topCustomerDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-top-customer-details",
        downloadSalesComparisonGccWiseQtyValUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/download-gcc-chart-details-excel-data",
        purchaseManagementValueQtyChartUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/get-purchase-order-combo-chart-data",
        downloadAccAgeingChartDataUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/download-acount-ledger-ageing-details-excel-data",
        generateHistoricalDataUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/download-purchase-details-excel-data-request",
        downloadHistoricalDataListUrl: environment.baseServiceComplaintUrl + "b2bapi/all-purchase/fetch-download-purchase-details-excel-data-url",


        // For My Target
        customerByCSAUrl: environment.baseServiceUrl + "b2bapi/user/lookup/list-customer-by-payer",
        targetUploadUrl: environment.baseServiceUrl + "b2bapi/user/target/upload-sales-target",
        targetDetailsUrl: environment.baseServiceUrl + "b2bapi/user/target/search-sales-target",
        processSalesTargetUrl: environment.baseServiceUrl + "b2bapi/user/target/process-sales-target",

        // For Account Management
        accountsCountDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/get-account-ledger-info",
        salesPurchaseTrendLineChartUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/get-account-ledger-chart-data",
        accountManagementDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/get-account-ledger-details",
        downloadTableDataAccountManagementUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/download-acount-ledger-details-excel-data",
        recentTransactionsUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/get-recent-transaction-data",
        accountsAgeingChartDetailsUrl: environment.baseServiceComplaintUrl + "b2bapi/accounts/get-account-ledger-ageing-chart-data",

        // For User
        userListUrl: environment.baseServiceUrl + "b2bapi/user/search-employee",
        updateEmployeeActivationUrl: environment.baseServiceUrl + "b2bapi/user/update-employee-activation",
        createUserUrl: environment.baseServiceUrl + "b2bapi/user/create-employee",
        editUserUrl: environment.baseServiceUrl + "b2bapi/user/update-employee",

        // For View as
        viewAsValidationUrl: environment.baseServiceUrl + "b2bapi/user/validate/view-as-user",
        viewAsCustCsaUrl: environment.baseServiceUrl + "b2bapi/user/validate/view-as-user-dropdown",

        // For Reports
        fetchAmendmentReportUrl: environment.baseServiceUrl + "b2bapi/user/report/amendment-data",
        fetchCustomerOnboardedReportUrl: environment.baseServiceUrl + "b2bapi/user/report/sync-customer-data",
        fetchNotOperatedCustomerReportUrl: environment.baseServiceUrl + "b2bapi/user/report/inactive-customer-data",
        fetchPlaceOrderReportUrl: environment.baseServiceUrl + "b2bapi/user/report/place-order-data",
        downloadAmendmentReportUrl: environment.baseServiceUrl + "b2bapi/user/report/download-amendment-data",
        downloadCustomerOnboardedReportUrl: environment.baseServiceUrl + "b2bapi/user/report/download-sync-customer-data",
        downloadNotOperatedCustomerReportUrl: environment.baseServiceUrl + "b2bapi/user/report/download-inactive-customer-data",
        downloadPlaceOrderReportUrl: environment.baseServiceUrl + "b2bapi/user/report/download-place-order-data",

        // Upload Contribution
        uploadContributionCalculatorUrl: environment.baseServiceUrl + "b2bapi/user/contribution/upload-file",
        searchContributionDetailsUrl: environment.baseServiceUrl + "b2bapi/user/contribution/search-contribution-file-dtl",
        processContributionUrl: environment.baseServiceUrl + "b2bapi/user/contribution/process-contribution-file",
        getChildShipToPartyUrl: environment.baseServiceUrl + "b2bapi/user/contribution/list-ship-to-party",
        getContributionDataUrl: environment.baseServiceUrl + "b2bapi/user/contribution/get-contribution-data",
        getGradeUrl: environment.baseServiceUrl + "b2bapi/user/contribution/get-grade-list",
        getGradebyProductUrl: environment.baseServiceUrl + "b2bapi/user/contribution/get-grade-list-by-product",
        getLocationUrl: environment.baseServiceUrl + "b2bapi/user/contribution/get-locations",
        sendEmailUrl: environment.baseServiceUrl + "b2bapi/user/contribution/cc-send-mail",

    }
}