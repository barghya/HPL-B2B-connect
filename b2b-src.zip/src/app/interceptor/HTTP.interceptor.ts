import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize } from "rxjs/operators";
import { LoaderService } from '../utils/loader-service';
import { CommonService } from '../utils/common-service';
import { ApiEndPoints } from '../utils/api-endpoints';
import Swal from 'sweetalert2';
import { alertPopup } from '../utils/alert-popup';
import { Constants } from '../utils/constants';
import * as moment from 'moment';
import { Router } from '@angular/router';

@Injectable()

export class HttpRequestInterceptorService implements HttpInterceptor {

  sendEmailUrl = ApiEndPoints.urls.sendResetUrl;
  resendEmailUrl = ApiEndPoints.urls.resendResetUrl;
  validateResetUrl = ApiEndPoints.urls.validateResetUrl;
  resetPasswordUrl = ApiEndPoints.urls.resetPasswordUrl;
  user = JSON.parse(sessionStorage.getItem('user'));
  totalTime: any;


  inputJSON = {
    login_time: this.user?.loginTime,
    current_time: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
  };

  diff = this.commonService.getTimeDiff(new Date(this.inputJSON.login_time), new Date(this.inputJSON.current_time));;


  constructor(private router: Router, private loaderService: LoaderService, private commonService: CommonService) { }


  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // this.loaderService.show();
    
    const token = sessionStorage.getItem('jwttoken');
    this.totalTime = ((this.diff?.day * 24 * 60) + (this.diff?.hour * 60) + (this.diff?.minute) + (this.diff?.second / 60)).toFixed(2);

    if (token && ((request?.url !== this.sendEmailUrl && request?.url !== this.resendEmailUrl && request?.url !== this.validateResetUrl
      && request?.url !== this.resetPasswordUrl) && !request.url.includes(Constants.normalText.amazonUrl))) {
        
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      })
    }
    if (this.totalTime >= 120) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: "Your session has expired. Please log in.",
        showCancelButton: false,
        allowEnterKey: false,
        allowOutsideClick: false,
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(['/login']).then((succeeded) => {
            window.location.reload()
          });
          sessionStorage.clear();
        }
      })
    } 
    return next.handle(request).pipe(
      catchError(err => {
        if (err?.message) {
          const error = err?.message;
          if (err?.status == 403) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err?.error?.message,
              showConfirmButton: true
            })
          }else {
            Swal.fire(alertPopup.interceptorError);
          }
          return throwError(error);
        } else {
          const error = err?.error?.message;
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: error,
            showConfirmButton: true
          })
          return throwError(error);
        }

      }),
      finalize(() =>
        this.loaderService.hide(),
      )
    );
  }
}
