export const environment = {
  production: true,

  // For Dev
  // baseServiceUrl: "http://3.109.94.176:8084/",
  // baseServiceDispatchUrl: "http://3.109.94.176:8090/",
  // baseServiceComplaintUrl: "http://3.109.94.176:8085/",
  // baseServiceEPODProdUrl: "https://hplepod.hpl.co.in/",

  // For Dev With Domain Name
  baseServiceUrl: "http://b2buat.hpl.co.in:8084/",
  baseServiceDispatchUrl: "http://b2buat.hpl.co.in:8090/",
  baseServiceComplaintUrl: "http://b2buat.hpl.co.in:8085/",
  baseServiceEPODProdUrl: "https://hplepod.hpl.co.in/",

  // For UAT
  // baseServiceUrl: "http://3.109.94.176:8083/",
  // baseServiceDispatchUrl: "http://3.109.94.176:9190/",
  // baseServiceComplaintUrl: "http://3.109.94.176:8086/",
  // baseServiceEPODProdUrl: "https://hplepod.hpl.co.in/",

  // For PROD
  // baseServiceUrl: "https://app.hpl.co.in/",
  // baseServiceDispatchUrl: "https://app.hpl.co.in/",
  // baseServiceComplaintUrl: "https://app.hpl.co.in/",
  // baseServiceEPODProdUrl: "https://hplepod.hpl.co.in/",


  key: "253D3FB468A0E24677C28A624BE0F818"

};